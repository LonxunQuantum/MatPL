/*
We have made the following improvements based on NEP4
http://doc.lonxun.com/MatPL/models/nep/
*/

/*
    the open source code from https://github.com/brucefan1983/GPUMD
    the licnese of NEP_CPU is as follows:

    Copyright 2017 Zheyong Fan, Ville Vierimaa, Mikko Ervasti, and Ari Harju
    This file is part of GPUMD.
    GPUMD is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    GPUMD is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with GPUMD.  If not, see <http://www.gnu.org/licenses/>.
*/

#pragma once
#include "../utilities/common.cuh"
#include "../utilities/gpu_vector.cuh"
#include "box.cuh"
#include "pppm.cuh"
#include <tuple>
#include <utility> // for std::move


struct LMP_Data  {
  GPU_Vector<float> r12;
  GPU_Vector<int> type;
  GPU_Vector<int> ilist;
  GPU_Vector<int> numneigh;
  GPU_Vector<int> firstneigh;
  GPU_Vector<double> position;
};

struct NEP_Data {
  GPU_Vector<float> f12x; // 3-body or manybody partial forces
  GPU_Vector<float> f12y; // 3-body or manybody partial forces
  GPU_Vector<float> f12z; // 3-body or manybody partial forces
  GPU_Vector<float> Fp;
  GPU_Vector<float> sum_fxyz;
  GPU_Vector<int> NN_radial;    // radial neighbor list
  GPU_Vector<int> NL_radial;    // radial neighbor list
  GPU_Vector<int> NN_angular;   // angular neighbor list
  GPU_Vector<int> NL_angular;   // angular neighbor list
  GPU_Vector<float> parameters; // parameters to be optimized
  GPU_Vector<int> cell_count;
  GPU_Vector<int> cell_count_sum;
  GPU_Vector<int> cell_contents;
  GPU_Vector<float> r12;
  GPU_Vector<double> potential_per_atom;
  GPU_Vector<double> force_per_atom;
  GPU_Vector<double> virial_per_atom;
  GPU_Vector<double> total_virial;
  GPU_Vector<float> charge;
  GPU_Vector<float> charge_derivative;
  GPU_Vector<float> bec;
  GPU_Vector<float> D_real;
  GPU_Vector<int> num_kpoints;
  GPU_Vector<float> kx;
  GPU_Vector<float> ky;
  GPU_Vector<float> kz;
  GPU_Vector<float> G;
  GPU_Vector<float> S_real;
  GPU_Vector<float> S_imag;

  std::vector<int> cpu_NN_radial;
  std::vector<int> cpu_NN_angular;

  std::vector<double> cpu_potential_per_atom;
  std::vector<double> cpu_force_per_atom;
  std::vector<double> cpu_virial_per_atom;
  std::vector<double> cpu_total_virial;
  std::vector<float> cpu_charge;
  std::vector<float> cpu_bec;

};

class NEP
{
public:
  struct ParaMB {
    bool use_typewise_cutoff_zbl = false;
    float typewise_cutoff_zbl_factor = 0.0f;
    int charge_mode = 0;
    int version = 4; 
    int model_type = 0; // 0=potential, 1=dipole, 2=polarizability, 3=temperature-dependent free energy
    float rc_radial = 0.0f;     // radial cutoff
    float rc_angular = 0.0f;    // angular cutoff
    float rcinv_radial = 0.0f;  // inverse of the radial cutoff
    float rcinv_angular = 0.0f; // inverse of the angular cutoff
    int MN_radial = 200;
    int MN_angular = 100;
    int n_max_radial = 0;  // n_radial = 0, 1, 2, ..., n_max_radial
    int n_max_angular = 0; // n_angular = 0, 1, 2, ..., n_max_angular
    int L_max = 0;         // l = 0, 1, 2, ..., L_max
    int dim_angular;
    int num_L;
    int basis_size_radial = 8;  // for nep3
    int basis_size_angular = 8; // for nep3
    int num_types_sq = 0;       // for nep3
    int num_c_radial = 0;       // for nep3
    int num_types = 0;
    float q_scaler[140];
  };

  struct ANN {
    int dim = 0;                 // dimension of the descriptor
    int num_neurons1 = 0;        // number of neurons in the 1st hidden layer
    int num_para = 0;            // number of parameters
    int num_para_ann = 0;
    int num_c2 = 0;
    int num_c3 = 0;
    const float* w0[nep_inference::kElementCount]; // weight from the input layer to the hidden layer
    const float* b0[nep_inference::kElementCount]; // bias for the hidden layer
    const float* w1[nep_inference::kElementCount]; // weight from the hidden layer to the output layer
    const float* sqrt_epsilon_inf;
    const float* b1;             // bias for the output layer
    const float* c;
    // Keep this by-value kernel argument within CUDA's legacy 4 KiB limit.
    // GPU inference has no polarizability head; do not reserve pointers for it.
  };

  struct Charge_Para {
    int num_kpoints_max = 50000;
    float alpha = 0.0f;
    float alpha_factor = 0.0f;
  };

  struct ZBL {
    bool enabled = false;
    bool flexibled = false;
    float rc_inner = 1.0f;
    float rc_outer = 2.0f;
    float para[550];
    int atomic_numbers[NUM_ELEMENTS];
    int num_types;
  };

  struct ExpandedBox {
    int num_cells[3];
    double h[18];
  };

  NEP();
  void init_from_file(const char* file_potential, const bool is_rank_0, const int in_device_id);

  ~NEP(void);

  bool model_loaded = false;
  ParaMB paramb;
  ANN annmb;
  ZBL zbl;
  Charge_Para charge_para;
  PPPM_Data pppm_data;
  Box box;
  ExpandedBox ebox;
  NEP_Data nep_data;
  LMP_Data lmp_data;
  std::vector<int> map_atom_type_idx;
  std::vector<int> element_atomic_number_list;
  int atom_nums = 0;
  int atom_nlocal = 0;
  int atom_nums_all = 0;

  void update_potential(float* parameters, ANN& ann);
  // void update_potential_from_cpu(std::vector<float> parameters, ANN& ann);
  void rest_nep_data(int max_atom_nums);

  void checkMemoryUsage(int sgin=0);

  void inference(
    int N, //atom nums
    int* itype_cpu, //atoms' type,the len is [n_all]
    double* box_cpu, 
    double* position_cpu, // postion of atoms x, [n_all * 3]
    const char* kspace_method = "ewald",
    double total_charge = 0.0
    );
  double rc; // maximum cutoff distance
  bool is_gpumd_nep = false;
  bool has_dftd3 = false;
  bool rank_0 = false;
  int device_id;
  bool print_potential_info = false;
};
