/*
List of modified records by Wu Xingxing (email stars_sparkling@163.com)
1. Added network structure support for NEP4 model independent bias
    Modified force field reading;
    Modified the applyann_one_layer method;
2. Added handling of inconsistency between the atomic order of the input structure of LAMMPS and the atomic order in the force field
3. In order to adapt to multiple model biases, the function has been added with computefor_lamps() and the int model_index parameter has been added  
4. Support GPUMD NEP shared bias and PWMLFF NEP independent bias forcefield

We have made the following improvements based on NEP4
http://doc.lonxun.com/MatPL/models/nep/
*/

/*
the open source code from https://github.com/brucefan1983/NEP_CPU
the licnese of NEP_CPU is as follows:
    Copyright 2022 Zheyong Fan, Junjie Wang, Eric Lindgren
    This file is part of NEP_CPU.
    NEP_CPU is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NEP_CPU is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with NEP_CPU.  If not, see <http://www.gnu.org/licenses/>.
*/

/*----------------------------------------------------------------------------80
A CPU implementation of the neuroevolution potential (NEP)
Ref: Zheyong Fan et al., Neuroevolution machine learning potentials:
Combining high accuracy and low cost in atomistic simulations and application to
heat transport, Phys. Rev. B. 104, 104309 (2021).
------------------------------------------------------------------------------*/

#include "nep.h"
#include <algorithm>
#include <cmath>
#include <complex>
#include <fstream>
#include <iostream>
#include <iterator>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <vector>

#if defined(_OPENMP)
#include <omp.h>
#endif

namespace
{
const double Bohr = 0.5291772575069165;
const int MAX_NEURON = 200; // maximum number of neurons in the hidden layer
const int MN = 1000;       // maximum number of neighbors for one atom
const int NUM_OF_ABC = 24;  // 3 + 5 + 7 + 9 for L_max = 4
const int MAX_NUM_N = 20;   // n_max+1 = 19+1
const int MAX_DIM = MAX_NUM_N * 7;
const int MAX_DIM_ANGULAR = MAX_NUM_N * 6;
const double C3B[NUM_OF_ABC] = {
  0.238732414637843, 0.119366207318922, 0.119366207318922, 0.099471839432435, 0.596831036594608,
  0.596831036594608, 0.149207759148652, 0.149207759148652, 0.139260575205408, 0.104445431404056,
  0.104445431404056, 1.044454314040563, 1.044454314040563, 0.174075719006761, 0.174075719006761,
  0.011190581936149, 0.223811638722978, 0.223811638722978, 0.111905819361489, 0.111905819361489,
  1.566681471060845, 1.566681471060845, 0.195835183882606, 0.195835183882606};
const double C4B[5] = {
  -0.007499480826664, -0.134990654879954, 0.067495327439977, 0.404971964639861, -0.809943929279723};
const double C5B[3] = {0.026596810706114, 0.053193621412227, 0.026596810706114};
const double K_C_SP = 14.399645; // 1/(4*PI*epsilon_0)
const double PI = 3.141592653589793;
const double PI_HALF = 1.570796326794897;


const double COVALENT_RADIUS[94] = {
  0.426667, 0.613333, 1.6,     1.25333, 1.02667, 1.0,     0.946667, 0.84,
  0.853333, 0.893333, 1.86667, 1.66667, 1.50667, 1.38667, 1.46667, 1.36,
  1.32,     1.28,     2.34667, 2.05333, 1.77333, 1.62667, 1.61333, 1.46667,
  1.42667,  1.38667,  1.33333, 1.32,    1.34667, 1.45333, 1.49333, 1.45333,
  1.53333,  1.46667,  1.52,    1.56,    2.52,     2.22667, 1.96,     1.85333,
  1.76,     1.65333,  1.53333, 1.50667, 1.50667, 1.44,    1.53333,  1.64,
  1.70667,  1.68,     1.68,     1.64,     1.76,    1.74667, 2.78667, 2.34667,
  2.16,     1.96,     2.10667,  2.09333,  2.08,     2.06667, 2.01333, 2.02667,
  2.01333,  2.0,      1.98667,  1.98667, 1.97333,  2.04,    1.94667, 1.82667,
  1.74667,  1.64,     1.57333,  1.54667, 1.48,     1.49333, 1.50667, 1.76,
  1.73333,  1.73333,  1.81333,  1.74667, 1.84,    1.89333, 2.68,     2.41333,
  2.22667,  2.10667,  2.02667,  2.04,     2.05333, 2.06667
};

int countNonEmptyLines(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "open file error in coutline function: " << filename << std::endl;
        exit(1);
    }
    std::string line;
    int nonEmptyLineCount = 0;
    while (std::getline(file, line)) {
        if (!line.empty()) {
            nonEmptyLineCount++;
        }
    }
    file.close();
    return nonEmptyLineCount;
}


void apply_ann_one_layer(
  const int dim,
  const int num_neurons1,
  const double* w0,
  const double* b0,
  const double* w1,
  const double* b1,
  double* q,
  double& energy,
  double* energy_derivative,
  double* latent_space,
  const int atom_type_i,
  const int model_version)
{
  for (int n = 0; n < num_neurons1; ++n) {
    double w0_times_q = 0.0;
    for (int d = 0; d < dim; ++d) {
      w0_times_q += w0[n * dim + d] * q[d];
    }
    double x1 = tanh(w0_times_q - b0[n]);
    latent_space[n] = w1[n] * x1; // also try x1
    energy += w1[n] * x1;
    for (int d = 0; d < dim; ++d) {
      double y1 = (1.0 - x1 * x1) * w0[n * dim + d];
      energy_derivative[d] += w1[n] * y1;
    }
  }
  energy -= (model_version == 4 ? b1[atom_type_i] : b1[0]);
  // std::cout << "ann last bias " <<  b1[atom_type_i] <<" type " << atom_type_i << " b1[0] " << b1[0] << std::endl;
}


void apply_ann_one_layer_nep5(
  const int dim,
  const int num_neurons1,
  const double* w0,
  const double* b0,
  const double* w1,
  const double* b1,
  double* q,
  double& energy,
  double* energy_derivative,
  double* latent_space,
  const int atom_type_i,
  const int model_version)
{
  for (int n = 0; n < num_neurons1; ++n) {
    double w0_times_q = 0.0;
    for (int d = 0; d < dim; ++d) {
      w0_times_q += w0[n * dim + d] * q[d];
    }
    double x1 = tanh(w0_times_q - b0[n]);
    latent_space[n] = w1[n] * x1; // also try x1
    energy += w1[n] * x1;
    for (int d = 0; d < dim; ++d) {
      double y1 = (1.0 - x1 * x1) * w0[n * dim + d];
      energy_derivative[d] += w1[n] * y1;
    }
  }
  energy -= w1[num_neurons1] + b1[0]; // typewise bias + common bias
}

void apply_ann_one_layer_charge(
  const int dim,
  const int num_neurons1,
  const double* w0,
  const double* b0,
  const double* w1,
  const double* b1,
  double* q,
  double& energy,
  double* energy_derivative,
  double& charge,
  double* charge_derivative,
  const int model_version)
{
  for (int n = 0; n < num_neurons1; ++n) {
    double w0_times_q = 0.0;
    for (int d = 0; d < dim; ++d) {
      w0_times_q += w0[n * dim + d] * q[d];
    }
    double x1 = tanh(w0_times_q - b0[n]);
    const double energy_weight = w1[n];
    const double charge_weight = w1[n + num_neurons1];
    const double y0 = energy_weight * x1;
    const double y1 = charge_weight * x1;
    energy += y0;
    charge += y1;
    for (int d = 0; d < dim; ++d) {
      double derivative = (1.0 - x1 * x1) * w0[n * dim + d];
      energy_derivative[d] += energy_weight * derivative;
      charge_derivative[d] += charge_weight * derivative;
    }
  }
  energy -= (model_version == 5 ? w1[num_neurons1 * 2] + b1[0] : b1[0]);
}

void find_fc(double rc, double rcinv, double d12, double& fc)
{
  if (d12 < rc) {
    double x = d12 * rcinv;
    fc = 0.5 * cos(PI * x) + 0.5;
  } else {
    fc = 0.0;
  }
}

void find_fc_and_fcp(double rc, double rcinv, double d12, double& fc, double& fcp)
{
  if (d12 < rc) {
    double x = d12 * rcinv;
    fc = 0.5 * cos(PI * x) + 0.5;
    fcp = -PI_HALF * sin(PI * x);
    fcp *= rcinv;
  } else {
    fc = 0.0;
    fcp = 0.0;
  }
}

void find_fc_and_fcp_zbl(double r1, double r2, double d12, double& fc, double& fcp)
{
  if (d12 < r1) {
    fc = 1.0;
    fcp = 0.0;
  } else if (d12 < r2) {
    double pi_factor = PI / (r2 - r1);
    fc = cos(pi_factor * (d12 - r1)) * 0.5 + 0.5;
    fcp = -sin(pi_factor * (d12 - r1)) * pi_factor * 0.5;
  } else {
    fc = 0.0;
    fcp = 0.0;
  }
}

void find_phi_and_phip_zbl(double a, double b, double x, double& phi, double& phip)
{
  double tmp = a * exp(-b * x);
  phi += tmp;
  phip -= b * tmp;
}

void find_f_and_fp_zbl(
  double zizj,
  double a_inv,
  double rc_inner,
  double rc_outer,
  double d12,
  double d12inv,
  double& f,
  double& fp)
{
  double x = d12 * a_inv;
  f = fp = 0.0;
  double Zbl_para[8] = {0.18175, 3.1998, 0.50986, 0.94229, 0.28022, 0.4029, 0.02817, 0.20162};
  find_phi_and_phip_zbl(Zbl_para[0], Zbl_para[1], x, f, fp);
  find_phi_and_phip_zbl(Zbl_para[2], Zbl_para[3], x, f, fp);
  find_phi_and_phip_zbl(Zbl_para[4], Zbl_para[5], x, f, fp);
  find_phi_and_phip_zbl(Zbl_para[6], Zbl_para[7], x, f, fp);
  f *= zizj;
  fp *= zizj * a_inv;
  fp = fp * d12inv - f * d12inv * d12inv;
  f *= d12inv;
  double fc, fcp;
  find_fc_and_fcp_zbl(rc_inner, rc_outer, d12, fc, fcp);
  fp = fp * fc + f * fcp;
  f *= fc;
}

void find_f_and_fp_zbl(
  double* zbl_para,
  double zizj,
  double a_inv,
  double d12,
  double d12inv,
  double& f,
  double& fp)
{
  double x = d12 * a_inv;
  f = fp = 0.0f;
  find_phi_and_phip_zbl(zbl_para[2], zbl_para[3], x, f, fp);
  find_phi_and_phip_zbl(zbl_para[4], zbl_para[5], x, f, fp);
  find_phi_and_phip_zbl(zbl_para[6], zbl_para[7], x, f, fp);
  find_phi_and_phip_zbl(zbl_para[8], zbl_para[9], x, f, fp);
  f *= zizj;
  fp *= zizj * a_inv;
  fp = fp * d12inv - f * d12inv * d12inv;
  f *= d12inv;
  double fc, fcp;
  find_fc_and_fcp_zbl(zbl_para[0], zbl_para[1], d12, fc, fcp);
  fp = fp * fc + f * fcp;
  f *= fc;
}

void find_fn(const int n, const double rcinv, const double d12, const double fc12, double& fn)
{
  if (n == 0) {
    fn = fc12;
  } else if (n == 1) {
    double x = 2.0 * (d12 * rcinv - 1.0) * (d12 * rcinv - 1.0) - 1.0;
    fn = (x + 1.0) * 0.5 * fc12;
  } else {
    double x = 2.0 * (d12 * rcinv - 1.0) * (d12 * rcinv - 1.0) - 1.0;
    double t0 = 1.0;
    double t1 = x;
    double t2;
    for (int m = 2; m <= n; ++m) {
      t2 = 2.0 * x * t1 - t0;
      t0 = t1;
      t1 = t2;
    }
    fn = (t2 + 1.0) * 0.5 * fc12;
  }
}

void find_fn_and_fnp(
  const int n,
  const double rcinv,
  const double d12,
  const double fc12,
  const double fcp12,
  double& fn,
  double& fnp)
{
  if (n == 0) {
    fn = fc12;
    fnp = fcp12;
  } else if (n == 1) {
    double x = 2.0 * (d12 * rcinv - 1.0) * (d12 * rcinv - 1.0) - 1.0;
    fn = (x + 1.0) * 0.5;
    fnp = 2.0 * (d12 * rcinv - 1.0) * rcinv * fc12 + fn * fcp12;
    fn *= fc12;
  } else {
    double x = 2.0 * (d12 * rcinv - 1.0) * (d12 * rcinv - 1.0) - 1.0;
    double t0 = 1.0;
    double t1 = x;
    double t2;
    double u0 = 1.0;
    double u1 = 2.0 * x;
    double u2;
    for (int m = 2; m <= n; ++m) {
      t2 = 2.0 * x * t1 - t0;
      t0 = t1;
      t1 = t2;
      u2 = 2.0 * x * u1 - u0;
      u0 = u1;
      u1 = u2;
    }
    fn = (t2 + 1.0) * 0.5;
    fnp = n * u0 * 2.0 * (d12 * rcinv - 1.0) * rcinv;
    fnp = fnp * fc12 + fn * fcp12;
    fn *= fc12;
  }
}

void find_fn(const int n_max, const double rcinv, const double d12, const double fc12, double* fn)
{
  double x = 2.0 * (d12 * rcinv - 1.0) * (d12 * rcinv - 1.0) - 1.0;
  fn[0] = 1.0;
  fn[1] = x;
  for (int m = 2; m <= n_max; ++m) {
    fn[m] = 2.0 * x * fn[m - 1] - fn[m - 2];
  }
  for (int m = 0; m <= n_max; ++m) {
    fn[m] = (fn[m] + 1.0) * 0.5 * fc12;
  }
}

void find_fn_and_fnp(
  const int n_max,
  const double rcinv,
  const double d12,
  const double fc12,
  const double fcp12,
  double* fn,
  double* fnp)
{
  double x = 2.0 * (d12 * rcinv - 1.0) * (d12 * rcinv - 1.0) - 1.0;
  fn[0] = 1.0;
  fnp[0] = 0.0;
  fn[1] = x;
  fnp[1] = 1.0;
  double u0 = 1.0;
  double u1 = 2.0 * x;
  double u2;
  for (int m = 2; m <= n_max; ++m) {
    fn[m] = 2.0 * x * fn[m - 1] - fn[m - 2];
    fnp[m] = m * u1;
    u2 = 2.0 * x * u1 - u0;
    u0 = u1;
    u1 = u2;
  }
  for (int m = 0; m <= n_max; ++m) {
    fn[m] = (fn[m] + 1.0) * 0.5;
    fnp[m] *= 2.0 * (d12 * rcinv - 1.0) * rcinv;
    fnp[m] = fnp[m] * fc12 + fn[m] * fcp12;
    fn[m] *= fc12;
  }
}

void get_f12_1(
  const double d12inv,
  const double fn,
  const double fnp,
  const double Fp,
  const double* s,
  const double* r12,
  double* f12)
{
  double tmp = s[1] * r12[0];
  tmp += s[2] * r12[1];
  tmp *= 2.0;
  tmp += s[0] * r12[2];
  tmp *= Fp * fnp * d12inv * 2.0;
  for (int d = 0; d < 3; ++d) {
    f12[d] += tmp * r12[d];
  }
  tmp = Fp * fn * 2.0;
  f12[0] += tmp * 2.0 * s[1];
  f12[1] += tmp * 2.0 * s[2];
  f12[2] += tmp * s[0];
}

void get_f12_2(
  const double d12,
  const double d12inv,
  const double fn,
  const double fnp,
  const double Fp,
  const double* s,
  const double* r12,
  double* f12)
{
  double tmp = s[1] * r12[0] * r12[2];               // Re[Y21]
  tmp += s[2] * r12[1] * r12[2];                     // Im[Y21]
  tmp += s[3] * (r12[0] * r12[0] - r12[1] * r12[1]); // Re[Y22]
  tmp += s[4] * 2.0 * r12[0] * r12[1];               // Im[Y22]
  tmp *= 2.0;
  tmp += s[0] * (3.0 * r12[2] * r12[2] - d12 * d12); // Y20
  tmp *= Fp * fnp * d12inv * 2.0;
  for (int d = 0; d < 3; ++d) {
    f12[d] += tmp * r12[d];
  }
  tmp = Fp * fn * 4.0;
  f12[0] += tmp * (-s[0] * r12[0] + s[1] * r12[2] + 2.0 * s[3] * r12[0] + 2.0 * s[4] * r12[1]);
  f12[1] += tmp * (-s[0] * r12[1] + s[2] * r12[2] - 2.0 * s[3] * r12[1] + 2.0 * s[4] * r12[0]);
  f12[2] += tmp * (2.0 * s[0] * r12[2] + s[1] * r12[0] + s[2] * r12[1]);
}

void get_f12_4body(
  const double d12,
  const double d12inv,
  const double fn,
  const double fnp,
  const double Fp,
  const double* s,
  const double* r12,
  double* f12)
{
  double fn_factor = Fp * fn;
  double fnp_factor = Fp * fnp * d12inv;
  double y20 = (3.0 * r12[2] * r12[2] - d12 * d12);

  // derivative wrt s[0]
  double tmp0 = C4B[0] * 3.0 * s[0] * s[0] + C4B[1] * (s[1] * s[1] + s[2] * s[2]) +
                C4B[2] * (s[3] * s[3] + s[4] * s[4]);
  double tmp1 = tmp0 * y20 * fnp_factor;
  double tmp2 = tmp0 * fn_factor;
  f12[0] += tmp1 * r12[0] - tmp2 * 2.0 * r12[0];
  f12[1] += tmp1 * r12[1] - tmp2 * 2.0 * r12[1];
  f12[2] += tmp1 * r12[2] + tmp2 * 4.0 * r12[2];

  // derivative wrt s[1]
  tmp0 = C4B[1] * s[0] * s[1] * 2.0 - C4B[3] * s[3] * s[1] * 2.0 + C4B[4] * s[2] * s[4];
  tmp1 = tmp0 * r12[0] * r12[2] * fnp_factor;
  tmp2 = tmp0 * fn_factor;
  f12[0] += tmp1 * r12[0] + tmp2 * r12[2];
  f12[1] += tmp1 * r12[1];
  f12[2] += tmp1 * r12[2] + tmp2 * r12[0];

  // derivative wrt s[2]
  tmp0 = C4B[1] * s[0] * s[2] * 2.0 + C4B[3] * s[3] * s[2] * 2.0 + C4B[4] * s[1] * s[4];
  tmp1 = tmp0 * r12[1] * r12[2] * fnp_factor;
  tmp2 = tmp0 * fn_factor;
  f12[0] += tmp1 * r12[0];
  f12[1] += tmp1 * r12[1] + tmp2 * r12[2];
  f12[2] += tmp1 * r12[2] + tmp2 * r12[1];

  // derivative wrt s[3]
  tmp0 = C4B[2] * s[0] * s[3] * 2.0 + C4B[3] * (s[2] * s[2] - s[1] * s[1]);
  tmp1 = tmp0 * (r12[0] * r12[0] - r12[1] * r12[1]) * fnp_factor;
  tmp2 = tmp0 * fn_factor;
  f12[0] += tmp1 * r12[0] + tmp2 * 2.0 * r12[0];
  f12[1] += tmp1 * r12[1] - tmp2 * 2.0 * r12[1];
  f12[2] += tmp1 * r12[2];

  // derivative wrt s[4]
  tmp0 = C4B[2] * s[0] * s[4] * 2.0 + C4B[4] * s[1] * s[2];
  tmp1 = tmp0 * (2.0 * r12[0] * r12[1]) * fnp_factor;
  tmp2 = tmp0 * fn_factor;
  f12[0] += tmp1 * r12[0] + tmp2 * 2.0 * r12[1];
  f12[1] += tmp1 * r12[1] + tmp2 * 2.0 * r12[0];
  f12[2] += tmp1 * r12[2];
}

void get_f12_5body(
  const double d12,
  const double d12inv,
  const double fn,
  const double fnp,
  const double Fp,
  const double* s,
  const double* r12,
  double* f12)
{
  double fn_factor = Fp * fn;
  double fnp_factor = Fp * fnp * d12inv;
  double s1_sq_plus_s2_sq = s[1] * s[1] + s[2] * s[2];

  // derivative wrt s[0]
  double tmp0 = C5B[0] * 4.0 * s[0] * s[0] * s[0] + C5B[1] * s1_sq_plus_s2_sq * 2.0 * s[0];
  double tmp1 = tmp0 * r12[2] * fnp_factor;
  double tmp2 = tmp0 * fn_factor;
  f12[0] += tmp1 * r12[0];
  f12[1] += tmp1 * r12[1];
  f12[2] += tmp1 * r12[2] + tmp2;

  // derivative wrt s[1]
  tmp0 = C5B[1] * s[0] * s[0] * s[1] * 2.0 + C5B[2] * s1_sq_plus_s2_sq * s[1] * 4.0;
  tmp1 = tmp0 * r12[0] * fnp_factor;
  tmp2 = tmp0 * fn_factor;
  f12[0] += tmp1 * r12[0] + tmp2;
  f12[1] += tmp1 * r12[1];
  f12[2] += tmp1 * r12[2];

  // derivative wrt s[2]
  tmp0 = C5B[1] * s[0] * s[0] * s[2] * 2.0 + C5B[2] * s1_sq_plus_s2_sq * s[2] * 4.0;
  tmp1 = tmp0 * r12[1] * fnp_factor;
  tmp2 = tmp0 * fn_factor;
  f12[0] += tmp1 * r12[0];
  f12[1] += tmp1 * r12[1] + tmp2;
  f12[2] += tmp1 * r12[2];
}

void get_f12_3(
  const double d12,
  const double d12inv,
  const double fn,
  const double fnp,
  const double Fp,
  const double* s,
  const double* r12,
  double* f12)
{
  double d12sq = d12 * d12;
  double x2 = r12[0] * r12[0];
  double y2 = r12[1] * r12[1];
  double z2 = r12[2] * r12[2];
  double xy = r12[0] * r12[1];
  double xz = r12[0] * r12[2];
  double yz = r12[1] * r12[2];

  double tmp = s[1] * (5.0 * z2 - d12sq) * r12[0];
  tmp += s[2] * (5.0 * z2 - d12sq) * r12[1];
  tmp += s[3] * (x2 - y2) * r12[2];
  tmp += s[4] * 2.0 * xy * r12[2];
  tmp += s[5] * r12[0] * (x2 - 3.0 * y2);
  tmp += s[6] * r12[1] * (3.0 * x2 - y2);
  tmp *= 2.0;
  tmp += s[0] * (5.0 * z2 - 3.0 * d12sq) * r12[2];
  tmp *= Fp * fnp * d12inv * 2.0;
  for (int d = 0; d < 3; ++d) {
    f12[d] += tmp * r12[d];
  }

  // x
  tmp = s[1] * (4.0 * z2 - 3.0 * x2 - y2);
  tmp += s[2] * (-2.0 * xy);
  tmp += s[3] * 2.0 * xz;
  tmp += s[4] * (2.0 * yz);
  tmp += s[5] * (3.0 * (x2 - y2));
  tmp += s[6] * (6.0 * xy);
  tmp *= 2.0;
  tmp += s[0] * (-6.0 * xz);
  f12[0] += tmp * Fp * fn * 2.0;
  // y
  tmp = s[1] * (-2.0 * xy);
  tmp += s[2] * (4.0 * z2 - 3.0 * y2 - x2);
  tmp += s[3] * (-2.0 * yz);
  tmp += s[4] * (2.0 * xz);
  tmp += s[5] * (-6.0 * xy);
  tmp += s[6] * (3.0 * (x2 - y2));
  tmp *= 2.0;
  tmp += s[0] * (-6.0 * yz);
  f12[1] += tmp * Fp * fn * 2.0;
  // z
  tmp = s[1] * (8.0 * xz);
  tmp += s[2] * (8.0 * yz);
  tmp += s[3] * (x2 - y2);
  tmp += s[4] * (2.0 * xy);
  tmp *= 2.0;
  tmp += s[0] * (9.0 * z2 - 3.0 * d12sq);
  f12[2] += tmp * Fp * fn * 2.0;
}

void get_f12_4(
  const double x,
  const double y,
  const double z,
  const double r,
  const double rinv,
  const double fn,
  const double fnp,
  const double Fp,
  const double* s,
  double* f12)
{
  const double r2 = r * r;
  const double x2 = x * x;
  const double y2 = y * y;
  const double z2 = z * z;
  const double xy = x * y;
  const double xz = x * z;
  const double yz = y * z;
  const double xyz = x * yz;
  const double x2my2 = x2 - y2;

  double tmp = s[1] * (7.0 * z2 - 3.0 * r2) * xz; // Y41_real
  tmp += s[2] * (7.0 * z2 - 3.0 * r2) * yz;       // Y41_imag
  tmp += s[3] * (7.0 * z2 - r2) * x2my2;          // Y42_real
  tmp += s[4] * (7.0 * z2 - r2) * 2.0 * xy;       // Y42_imag
  tmp += s[5] * (x2 - 3.0 * y2) * xz;             // Y43_real
  tmp += s[6] * (3.0 * x2 - y2) * yz;             // Y43_imag
  tmp += s[7] * (x2my2 * x2my2 - 4.0 * x2 * y2);  // Y44_real
  tmp += s[8] * (4.0 * xy * x2my2);               // Y44_imag
  tmp *= 2.0;
  tmp += s[0] * ((35.0 * z2 - 30.0 * r2) * z2 + 3.0 * r2 * r2); // Y40
  tmp *= Fp * fnp * rinv * 2.0;
  f12[0] += tmp * x;
  f12[1] += tmp * y;
  f12[2] += tmp * z;

  // x
  tmp = s[1] * z * (7.0 * z2 - 3.0 * r2 - 6.0 * x2);  // Y41_real
  tmp += s[2] * (-6.0 * xyz);                         // Y41_imag
  tmp += s[3] * 4.0 * x * (3.0 * z2 - x2);            // Y42_real
  tmp += s[4] * 2.0 * y * (7.0 * z2 - r2 - 2.0 * x2); // Y42_imag
  tmp += s[5] * 3.0 * z * x2my2;                      // Y43_real
  tmp += s[6] * 6.0 * xyz;                            // Y43_imag
  tmp += s[7] * 4.0 * x * (x2 - 3.0 * y2);            // Y44_real
  tmp += s[8] * 4.0 * y * (3.0 * x2 - y2);            // Y44_imag
  tmp *= 2.0;
  tmp += s[0] * 12.0 * x * (r2 - 5.0 * z2); // Y40
  f12[0] += tmp * Fp * fn * 2.0;
  // y
  tmp = s[1] * (-6.0 * xyz);                          // Y41_real
  tmp += s[2] * z * (7.0 * z2 - 3.0 * r2 - 6.0 * y2); // Y41_imag
  tmp += s[3] * 4.0 * y * (y2 - 3.0 * z2);            // Y42_real
  tmp += s[4] * 2.0 * x * (7.0 * z2 - r2 - 2.0 * y2); // Y42_imag
  tmp += s[5] * (-6.0 * xyz);                         // Y43_real
  tmp += s[6] * 3.0 * z * x2my2;                      // Y43_imag
  tmp += s[7] * 4.0 * y * (y2 - 3.0 * x2);            // Y44_real
  tmp += s[8] * 4.0 * x * (x2 - 3.0 * y2);            // Y44_imag
  tmp *= 2.0;
  tmp += s[0] * 12.0 * y * (r2 - 5.0 * z2); // Y40
  f12[1] += tmp * Fp * fn * 2.0;
  // z
  tmp = s[1] * 3.0 * x * (5.0 * z2 - r2);  // Y41_real
  tmp += s[2] * 3.0 * y * (5.0 * z2 - r2); // Y41_imag
  tmp += s[3] * 12.0 * z * x2my2;          // Y42_real
  tmp += s[4] * 24.0 * xyz;                // Y42_imag
  tmp += s[5] * x * (x2 - 3.0 * y2);       // Y43_real
  tmp += s[6] * y * (3.0 * x2 - y2);       // Y43_imag
  tmp *= 2.0;
  tmp += s[0] * 16.0 * z * (5.0 * z2 - 3.0 * r2); // Y40
  f12[2] += tmp * Fp * fn * 2.0;
}

void accumulate_f12(
  const int n,
  const int n_max_angular_plus_1,
  const double d12,
  const double* r12,
  double fn,
  double fnp,
  const double* Fp,
  const double* sum_fxyz,
  double* f12)
{
  const double d12inv = 1.0 / d12;
  // l = 1
  fnp = fnp * d12inv - fn * d12inv * d12inv;
  fn = fn * d12inv;
  double s1[3] = {
    sum_fxyz[n * NUM_OF_ABC + 0] * C3B[0], sum_fxyz[n * NUM_OF_ABC + 1] * C3B[1],
    sum_fxyz[n * NUM_OF_ABC + 2] * C3B[2]};
  get_f12_1(d12inv, fn, fnp, Fp[n], s1, r12, f12);
  // l = 2
  fnp = fnp * d12inv - fn * d12inv * d12inv;
  fn = fn * d12inv;
  double s2[5] = {
    sum_fxyz[n * NUM_OF_ABC + 3] * C3B[3], sum_fxyz[n * NUM_OF_ABC + 4] * C3B[4],
    sum_fxyz[n * NUM_OF_ABC + 5] * C3B[5], sum_fxyz[n * NUM_OF_ABC + 6] * C3B[6],
    sum_fxyz[n * NUM_OF_ABC + 7] * C3B[7]};
  get_f12_2(d12, d12inv, fn, fnp, Fp[n_max_angular_plus_1 + n], s2, r12, f12);
  // l = 3
  fnp = fnp * d12inv - fn * d12inv * d12inv;
  fn = fn * d12inv;
  double s3[7] = {sum_fxyz[n * NUM_OF_ABC + 8] * C3B[8],   sum_fxyz[n * NUM_OF_ABC + 9] * C3B[9],
                  sum_fxyz[n * NUM_OF_ABC + 10] * C3B[10], sum_fxyz[n * NUM_OF_ABC + 11] * C3B[11],
                  sum_fxyz[n * NUM_OF_ABC + 12] * C3B[12], sum_fxyz[n * NUM_OF_ABC + 13] * C3B[13],
                  sum_fxyz[n * NUM_OF_ABC + 14] * C3B[14]};
  get_f12_3(d12, d12inv, fn, fnp, Fp[2 * n_max_angular_plus_1 + n], s3, r12, f12);
  // l = 4
  fnp = fnp * d12inv - fn * d12inv * d12inv;
  fn = fn * d12inv;
  double s4[9] = {sum_fxyz[n * NUM_OF_ABC + 15] * C3B[15], sum_fxyz[n * NUM_OF_ABC + 16] * C3B[16],
                  sum_fxyz[n * NUM_OF_ABC + 17] * C3B[17], sum_fxyz[n * NUM_OF_ABC + 18] * C3B[18],
                  sum_fxyz[n * NUM_OF_ABC + 19] * C3B[19], sum_fxyz[n * NUM_OF_ABC + 20] * C3B[20],
                  sum_fxyz[n * NUM_OF_ABC + 21] * C3B[21], sum_fxyz[n * NUM_OF_ABC + 22] * C3B[22],
                  sum_fxyz[n * NUM_OF_ABC + 23] * C3B[23]};
  get_f12_4(
    r12[0], r12[1], r12[2], d12, d12inv, fn, fnp, Fp[3 * n_max_angular_plus_1 + n], s4, f12);
}

void accumulate_f12_with_4body(
  const int n,
  const int n_max_angular_plus_1,
  const double d12,
  const double* r12,
  double fn,
  double fnp,
  const double* Fp,
  const double* sum_fxyz,
  double* f12)
{
  const double d12inv = 1.0 / d12;
  // l = 1
  fnp = fnp * d12inv - fn * d12inv * d12inv;
  fn = fn * d12inv;
  double s1[3] = {
    sum_fxyz[n * NUM_OF_ABC + 0] * C3B[0], sum_fxyz[n * NUM_OF_ABC + 1] * C3B[1],
    sum_fxyz[n * NUM_OF_ABC + 2] * C3B[2]};
  get_f12_1(d12inv, fn, fnp, Fp[n], s1, r12, f12);
  // l = 2
  fnp = fnp * d12inv - fn * d12inv * d12inv;
  fn = fn * d12inv;
  double s2[5] = {
    sum_fxyz[n * NUM_OF_ABC + 3], sum_fxyz[n * NUM_OF_ABC + 4], sum_fxyz[n * NUM_OF_ABC + 5],
    sum_fxyz[n * NUM_OF_ABC + 6], sum_fxyz[n * NUM_OF_ABC + 7]};
  get_f12_4body(d12, d12inv, fn, fnp, Fp[4 * n_max_angular_plus_1 + n], s2, r12, f12);
  s2[0] *= C3B[3];
  s2[1] *= C3B[4];
  s2[2] *= C3B[5];
  s2[3] *= C3B[6];
  s2[4] *= C3B[7];
  get_f12_2(d12, d12inv, fn, fnp, Fp[n_max_angular_plus_1 + n], s2, r12, f12);
  // l = 3
  fnp = fnp * d12inv - fn * d12inv * d12inv;
  fn = fn * d12inv;
  double s3[7] = {sum_fxyz[n * NUM_OF_ABC + 8] * C3B[8],   sum_fxyz[n * NUM_OF_ABC + 9] * C3B[9],
                  sum_fxyz[n * NUM_OF_ABC + 10] * C3B[10], sum_fxyz[n * NUM_OF_ABC + 11] * C3B[11],
                  sum_fxyz[n * NUM_OF_ABC + 12] * C3B[12], sum_fxyz[n * NUM_OF_ABC + 13] * C3B[13],
                  sum_fxyz[n * NUM_OF_ABC + 14] * C3B[14]};
  get_f12_3(d12, d12inv, fn, fnp, Fp[2 * n_max_angular_plus_1 + n], s3, r12, f12);
  // l = 4
  fnp = fnp * d12inv - fn * d12inv * d12inv;
  fn = fn * d12inv;
  double s4[9] = {sum_fxyz[n * NUM_OF_ABC + 15] * C3B[15], sum_fxyz[n * NUM_OF_ABC + 16] * C3B[16],
                  sum_fxyz[n * NUM_OF_ABC + 17] * C3B[17], sum_fxyz[n * NUM_OF_ABC + 18] * C3B[18],
                  sum_fxyz[n * NUM_OF_ABC + 19] * C3B[19], sum_fxyz[n * NUM_OF_ABC + 20] * C3B[20],
                  sum_fxyz[n * NUM_OF_ABC + 21] * C3B[21], sum_fxyz[n * NUM_OF_ABC + 22] * C3B[22],
                  sum_fxyz[n * NUM_OF_ABC + 23] * C3B[23]};
  get_f12_4(
    r12[0], r12[1], r12[2], d12, d12inv, fn, fnp, Fp[3 * n_max_angular_plus_1 + n], s4, f12);
}

void accumulate_f12_with_5body(
  const int n,
  const int n_max_angular_plus_1,
  const double d12,
  const double* r12,
  double fn,
  double fnp,
  const double* Fp,
  const double* sum_fxyz,
  double* f12)
{
  const double d12inv = 1.0 / d12;
  // l = 1
  fnp = fnp * d12inv - fn * d12inv * d12inv;
  fn = fn * d12inv;
  double s1[3] = {
    sum_fxyz[n * NUM_OF_ABC + 0], sum_fxyz[n * NUM_OF_ABC + 1], sum_fxyz[n * NUM_OF_ABC + 2]};
  get_f12_5body(d12, d12inv, fn, fnp, Fp[5 * n_max_angular_plus_1 + n], s1, r12, f12);
  s1[0] *= C3B[0];
  s1[1] *= C3B[1];
  s1[2] *= C3B[2];
  get_f12_1(d12inv, fn, fnp, Fp[n], s1, r12, f12);
  // l = 2
  fnp = fnp * d12inv - fn * d12inv * d12inv;
  fn = fn * d12inv;
  double s2[5] = {
    sum_fxyz[n * NUM_OF_ABC + 3], sum_fxyz[n * NUM_OF_ABC + 4], sum_fxyz[n * NUM_OF_ABC + 5],
    sum_fxyz[n * NUM_OF_ABC + 6], sum_fxyz[n * NUM_OF_ABC + 7]};
  get_f12_4body(d12, d12inv, fn, fnp, Fp[4 * n_max_angular_plus_1 + n], s2, r12, f12);
  s2[0] *= C3B[3];
  s2[1] *= C3B[4];
  s2[2] *= C3B[5];
  s2[3] *= C3B[6];
  s2[4] *= C3B[7];
  get_f12_2(d12, d12inv, fn, fnp, Fp[n_max_angular_plus_1 + n], s2, r12, f12);
  // l = 3
  fnp = fnp * d12inv - fn * d12inv * d12inv;
  fn = fn * d12inv;
  double s3[7] = {sum_fxyz[n * NUM_OF_ABC + 8] * C3B[8],   sum_fxyz[n * NUM_OF_ABC + 9] * C3B[9],
                  sum_fxyz[n * NUM_OF_ABC + 10] * C3B[10], sum_fxyz[n * NUM_OF_ABC + 11] * C3B[11],
                  sum_fxyz[n * NUM_OF_ABC + 12] * C3B[12], sum_fxyz[n * NUM_OF_ABC + 13] * C3B[13],
                  sum_fxyz[n * NUM_OF_ABC + 14] * C3B[14]};
  get_f12_3(d12, d12inv, fn, fnp, Fp[2 * n_max_angular_plus_1 + n], s3, r12, f12);
  // l = 4
  fnp = fnp * d12inv - fn * d12inv * d12inv;
  fn = fn * d12inv;
  double s4[9] = {sum_fxyz[n * NUM_OF_ABC + 15] * C3B[15], sum_fxyz[n * NUM_OF_ABC + 16] * C3B[16],
                  sum_fxyz[n * NUM_OF_ABC + 17] * C3B[17], sum_fxyz[n * NUM_OF_ABC + 18] * C3B[18],
                  sum_fxyz[n * NUM_OF_ABC + 19] * C3B[19], sum_fxyz[n * NUM_OF_ABC + 20] * C3B[20],
                  sum_fxyz[n * NUM_OF_ABC + 21] * C3B[21], sum_fxyz[n * NUM_OF_ABC + 22] * C3B[22],
                  sum_fxyz[n * NUM_OF_ABC + 23] * C3B[23]};
  get_f12_4(
    r12[0], r12[1], r12[2], d12, d12inv, fn, fnp, Fp[3 * n_max_angular_plus_1 + n], s4, f12);
}

void accumulate_s(const double d12, double x12, double y12, double z12, const double fn, double* s)
{
  double d12inv = 1.0 / d12;
  x12 *= d12inv;
  y12 *= d12inv;
  z12 *= d12inv;
  double x12sq = x12 * x12;
  double y12sq = y12 * y12;
  double z12sq = z12 * z12;
  double x12sq_minus_y12sq = x12sq - y12sq;
  s[0] += z12 * fn;                                                            // Y10
  s[1] += x12 * fn;                                                            // Y11_real
  s[2] += y12 * fn;                                                            // Y11_imag
  s[3] += (3.0 * z12sq - 1.0) * fn;                                            // Y20
  s[4] += x12 * z12 * fn;                                                      // Y21_real
  s[5] += y12 * z12 * fn;                                                      // Y21_imag
  s[6] += x12sq_minus_y12sq * fn;                                              // Y22_real
  s[7] += 2.0 * x12 * y12 * fn;                                                // Y22_imag
  s[8] += (5.0 * z12sq - 3.0) * z12 * fn;                                      // Y30
  s[9] += (5.0 * z12sq - 1.0) * x12 * fn;                                      // Y31_real
  s[10] += (5.0 * z12sq - 1.0) * y12 * fn;                                     // Y31_imag
  s[11] += x12sq_minus_y12sq * z12 * fn;                                       // Y32_real
  s[12] += 2.0 * x12 * y12 * z12 * fn;                                         // Y32_imag
  s[13] += (x12 * x12 - 3.0 * y12 * y12) * x12 * fn;                           // Y33_real
  s[14] += (3.0 * x12 * x12 - y12 * y12) * y12 * fn;                           // Y33_imag
  s[15] += ((35.0 * z12sq - 30.0) * z12sq + 3.0) * fn;                         // Y40
  s[16] += (7.0 * z12sq - 3.0) * x12 * z12 * fn;                               // Y41_real
  s[17] += (7.0 * z12sq - 3.0) * y12 * z12 * fn;                               // Y41_iamg
  s[18] += (7.0 * z12sq - 1.0) * x12sq_minus_y12sq * fn;                       // Y42_real
  s[19] += (7.0 * z12sq - 1.0) * x12 * y12 * 2.0 * fn;                         // Y42_imag
  s[20] += (x12sq - 3.0 * y12sq) * x12 * z12 * fn;                             // Y43_real
  s[21] += (3.0 * x12sq - y12sq) * y12 * z12 * fn;                             // Y43_imag
  s[22] += (x12sq_minus_y12sq * x12sq_minus_y12sq - 4.0 * x12sq * y12sq) * fn; // Y44_real
  s[23] += (4.0 * x12 * y12 * x12sq_minus_y12sq) * fn;                         // Y44_imag
}

void find_q(const int n_max_angular_plus_1, const int n, const double* s, double* q)
{
  q[n] = C3B[0] * s[0] * s[0] + 2.0 * (C3B[1] * s[1] * s[1] + C3B[2] * s[2] * s[2]);
  q[n_max_angular_plus_1 + n] =
    C3B[3] * s[3] * s[3] + 2.0 * (C3B[4] * s[4] * s[4] + C3B[5] * s[5] * s[5] +
                                  C3B[6] * s[6] * s[6] + C3B[7] * s[7] * s[7]);
  q[2 * n_max_angular_plus_1 + n] =
    C3B[8] * s[8] * s[8] +
    2.0 * (C3B[9] * s[9] * s[9] + C3B[10] * s[10] * s[10] + C3B[11] * s[11] * s[11] +
           C3B[12] * s[12] * s[12] + C3B[13] * s[13] * s[13] + C3B[14] * s[14] * s[14]);
  q[3 * n_max_angular_plus_1 + n] =
    C3B[15] * s[15] * s[15] +
    2.0 * (C3B[16] * s[16] * s[16] + C3B[17] * s[17] * s[17] + C3B[18] * s[18] * s[18] +
           C3B[19] * s[19] * s[19] + C3B[20] * s[20] * s[20] + C3B[21] * s[21] * s[21] +
           C3B[22] * s[22] * s[22] + C3B[23] * s[23] * s[23]);
}

void find_q_with_4body(const int n_max_angular_plus_1, const int n, const double* s, double* q)
{
  find_q(n_max_angular_plus_1, n, s, q);
  q[4 * n_max_angular_plus_1 + n] =
    C4B[0] * s[3] * s[3] * s[3] + C4B[1] * s[3] * (s[4] * s[4] + s[5] * s[5]) +
    C4B[2] * s[3] * (s[6] * s[6] + s[7] * s[7]) + C4B[3] * s[6] * (s[5] * s[5] - s[4] * s[4]) +
    C4B[4] * s[4] * s[5] * s[7];
}

void find_q_with_5body(const int n_max_angular_plus_1, const int n, const double* s, double* q)
{
  find_q_with_4body(n_max_angular_plus_1, n, s, q);
  double s0_sq = s[0] * s[0];
  double s1_sq_plus_s2_sq = s[1] * s[1] + s[2] * s[2];
  q[5 * n_max_angular_plus_1 + n] = C5B[0] * s0_sq * s0_sq + C5B[1] * s0_sq * s1_sq_plus_s2_sq +
                                    C5B[2] * s1_sq_plus_s2_sq * s1_sq_plus_s2_sq;
}

void find_descriptor(
  const bool calculating_potential,
  const bool calculating_descriptor,
  const bool calculating_latent_space,
  const bool calculating_polarizability,
  NEP_CPU::ParaMB& paramb,
  NEP_CPU::ANN& annmb,
  const int N,
  const int* g_NN_radial,
  const int* g_NL_radial,
  const int* g_NN_angular,
  const int* g_NL_angular,
  const int* g_type,
  const double* g_x12_radial,
  const double* g_y12_radial,
  const double* g_z12_radial,
  const double* g_x12_angular,
  const double* g_y12_angular,
  const double* g_z12_angular,
  double* g_Fp,
  double* g_sum_fxyz,
  double* g_potential,
  double* g_charge,
  double* g_charge_derivative,
  double* g_descriptor,
  double* g_latent_space,
  double* g_virial)
{
#if defined(_OPENMP)
#pragma omp parallel for
#endif
  for (int n1 = 0; n1 < N; ++n1) {
    int t1 = g_type[n1];
    double q[MAX_DIM] = {0.0};

    for (int i1 = 0; i1 < g_NN_radial[n1]; ++i1) {
      int index = i1 * N + n1;
      int n2 = g_NL_radial[index];
      int t2 = g_type[n2];
      double r12[3] = {g_x12_radial[index], g_y12_radial[index], g_z12_radial[index]};
      double d12 = sqrt(r12[0] * r12[0] + r12[1] * r12[1] + r12[2] * r12[2]);
      // printf("feat n1 %d t1 %d n2 %d t2 %d d12 %f = %f %f %f\n",n1, t1, n2, t2, d12, r12[0], r12[1], r12[2]);
      double fc12;
      find_fc(paramb.rc_radial, paramb.rcinv_radial, d12, fc12);
      double fn12[MAX_NUM_N];
      // if (n1 ==0){
      //   printf("n1 %d t1 %d n2 %d t2 %d r12 %f fc %f\n", n1, t1, n2, t2, d12, fc12);
      // }
      if (paramb.version == 2) {
        find_fn(paramb.n_max_radial, paramb.rcinv_radial, d12, fc12, fn12);
        for (int n = 0; n <= paramb.n_max_radial; ++n) {
          double c = (paramb.num_types == 1)
                       ? 1.0
                       : annmb.c[(n * paramb.num_types + t1) * paramb.num_types + t2];
          q[n] += fn12[n] * c;
        }
      } else {
        find_fn(paramb.basis_size_radial, paramb.rcinv_radial, d12, fc12, fn12);
        for (int n = 0; n <= paramb.n_max_radial; ++n) {
          double gn12 = 0.0;
          for (int k = 0; k <= paramb.basis_size_radial; ++k) {
            int c_index = (n * (paramb.basis_size_radial + 1) + k) * paramb.num_types_sq;
            c_index += t1 * paramb.num_types + t2;
            gn12 += fn12[k] * annmb.c[c_index];
          }
          q[n] += gn12;
        }
      }
    }

    for (int n = 0; n <= paramb.n_max_angular; ++n) {
      double s[NUM_OF_ABC] = {0.0};
      for (int i1 = 0; i1 < g_NN_angular[n1]; ++i1) {
        int index = i1 * N + n1;
        int n2 = g_NL_angular[index];
        double r12[3] = {g_x12_angular[index], g_y12_angular[index], g_z12_angular[index]};
        double d12 = sqrt(r12[0] * r12[0] + r12[1] * r12[1] + r12[2] * r12[2]);
        double fc12;
        find_fc(paramb.rc_angular, paramb.rcinv_angular, d12, fc12);
        int t2 = g_type[n2];
        if (paramb.version == 2) {
          double fn;
          find_fn(n, paramb.rcinv_angular, d12, fc12, fn);
          fn *=
            (paramb.num_types == 1)
              ? 1.0
              : annmb.c
                  [((paramb.n_max_radial + 1 + n) * paramb.num_types + t1) * paramb.num_types + t2];
          accumulate_s(d12, r12[0], r12[1], r12[2], fn, s);
        } else {
          double fn12[MAX_NUM_N];
          find_fn(paramb.basis_size_angular, paramb.rcinv_angular, d12, fc12, fn12);
          double gn12 = 0.0;
          for (int k = 0; k <= paramb.basis_size_angular; ++k) {
            int c_index = (n * (paramb.basis_size_angular + 1) + k) * paramb.num_types_sq;
            c_index += t1 * paramb.num_types + t2 + paramb.num_c_radial;
            gn12 += fn12[k] * annmb.c[c_index];
          }
          accumulate_s(d12, r12[0], r12[1], r12[2], gn12, s);
        }
      }
      if (paramb.num_L == paramb.L_max) {
        find_q(paramb.n_max_angular + 1, n, s, q + (paramb.n_max_radial + 1));
      } else if (paramb.num_L == paramb.L_max + 1) {
        find_q_with_4body(paramb.n_max_angular + 1, n, s, q + (paramb.n_max_radial + 1));
      } else {
        find_q_with_5body(paramb.n_max_angular + 1, n, s, q + (paramb.n_max_radial + 1));
      }
      for (int abc = 0; abc < NUM_OF_ABC; ++abc) {
        g_sum_fxyz[(n * NUM_OF_ABC + abc) * N + n1] = s[abc];
      }
    }

    if (calculating_descriptor) {
      for (int d = 0; d < annmb.dim; ++d) {
        g_descriptor[d * N + n1] = q[d] * paramb.q_scaler[d];
      }
    }

    if (calculating_potential || calculating_latent_space || calculating_polarizability) {
      for (int d = 0; d < annmb.dim; ++d) {
        // if (n1==0) {
        // printf("n1 %d q[%d]=%f scaler[%d]=%f\n", n1, d, q[d], d, paramb.q_scaler[d]);
        // }
        q[d] = q[d] * paramb.q_scaler[d];
      }

      double F = 0.0, Fp[MAX_DIM] = {0.0}, latent_space[MAX_NEURON] = {0.0};

      if (calculating_polarizability) {
        apply_ann_one_layer(
          annmb.dim, annmb.num_neurons1, annmb.w0_pol[t1], annmb.b0_pol[t1], annmb.w1_pol[t1],
          annmb.b1_pol, q, F, Fp, latent_space, t1, paramb.version);
        g_virial[n1] = F;
        g_virial[n1 + N * 4] = F;
        g_virial[n1 + N * 8] = F;

        for (int d = 0; d < annmb.dim; ++d) {
          Fp[d] = 0.0;
        }
        for (int d = 0; d < annmb.num_neurons1; ++d) {
          latent_space[d] = 0.0;
        }
      }

      double charge_value = 0.0;
      double charge_derivative[MAX_DIM] = {0.0};
      if (paramb.charge_mode == 2) {
        apply_ann_one_layer_charge(
          annmb.dim, annmb.num_neurons1, annmb.w0[t1], annmb.b0[t1], annmb.w1[t1], annmb.b1, q, F, Fp,
          charge_value, charge_derivative, paramb.version);
      } else if (paramb.version == 4) {
        apply_ann_one_layer(
          annmb.dim, annmb.num_neurons1, annmb.w0[t1], annmb.b0[t1], annmb.w1[t1], annmb.b1, q, F, Fp,
          latent_space, t1, paramb.version);
      } else if (paramb.version == 5) {
        apply_ann_one_layer_nep5(
          annmb.dim, annmb.num_neurons1, annmb.w0[t1], annmb.b0[t1], annmb.w1[t1], annmb.b1, q, F, Fp,
          latent_space, t1, paramb.version);        
      }

      if (calculating_latent_space) {
        for (int n = 0; n < annmb.num_neurons1; ++n) {
          g_latent_space[n * N + n1] = latent_space[n];
        }
      }

      if (calculating_potential) {
        g_potential[n1] += F;
      }
      if (paramb.charge_mode == 2 && g_charge && g_charge_derivative) {
        g_charge[n1] = charge_value;
      }
      // printf("e[%d]=%f\n", n1, F);
      for (int d = 0; d < annmb.dim; ++d) {
        g_Fp[d * N + n1] = Fp[d] * paramb.q_scaler[d];
        if (paramb.charge_mode == 2 && g_charge_derivative) {
          g_charge_derivative[d * N + n1] = charge_derivative[d] * paramb.q_scaler[d];
        }
      }
    }
  }
}

void shift_total_charge(const int N, std::vector<double>& charge, const double total_charge)
{
  double sum_charge = 0.0;
  for (int n = 0; n < N; ++n) {
    sum_charge += charge[n];
  }
  const double charge_correction = (total_charge - sum_charge) / N;
  for (int n = 0; n < N; ++n) {
    charge[n] += charge_correction;
  }
}

void zero_total_charge(const int N, std::vector<double>& charge)
{
  shift_total_charge(N, charge, 0.0);
}

void zero_mean_D_real(const int N, std::vector<double>& D_real)
{
  double sum_D = 0.0;
  for (int n = 0; n < N; ++n) {
    sum_D += D_real[n];
  }
  const double mean_D = sum_D / N;
  for (int n = 0; n < N; ++n) {
    D_real[n] -= mean_D;
  }
}

void find_bec_diagonal(const int N, const std::vector<double>& charge, std::vector<double>& bec)
{
  for (int n = 0; n < N; ++n) {
    bec[n + N * 0] = charge[n];
    bec[n + N * 1] = 0.0;
    bec[n + N * 2] = 0.0;
    bec[n + N * 3] = 0.0;
    bec[n + N * 4] = charge[n];
    bec[n + N * 5] = 0.0;
    bec[n + N * 6] = 0.0;
    bec[n + N * 7] = 0.0;
    bec[n + N * 8] = charge[n];
  }
}

void scale_bec(const int N, const double sqrt_epsilon_inf, std::vector<double>& bec)
{
  for (int n = 0; n < N; ++n) {
    for (int d = 0; d < 9; ++d) {
      bec[n + N * d] *= sqrt_epsilon_inf;
    }
  }
}

void find_bec_radial(
  NEP_CPU::ParaMB& paramb,
  NEP_CPU::ANN& annmb,
  const int N,
  const int* g_NN,
  const int* g_NL,
  const int* g_type,
  const double* g_x12,
  const double* g_y12,
  const double* g_z12,
  const double* g_charge_derivative,
  std::vector<double>& bec)
{
  for (int n1 = 0; n1 < N; ++n1) {
    int t1 = g_type[n1];
    for (int i1 = 0; i1 < g_NN[n1]; ++i1) {
      int index = i1 * N + n1;
      int n2 = g_NL[index];
      int t2 = g_type[n2];
      double r12[3] = {g_x12[index], g_y12[index], g_z12[index]};
      double d12 = sqrt(r12[0] * r12[0] + r12[1] * r12[1] + r12[2] * r12[2]);
      double d12inv = 1.0 / d12;
      double fc12, fcp12;
      find_fc_and_fcp(paramb.rc_radial, paramb.rcinv_radial, d12, fc12, fcp12);
      double fn12[MAX_NUM_N];
      double fnp12[MAX_NUM_N];
      double f12[3] = {0.0};
      find_fn_and_fnp(paramb.basis_size_radial, paramb.rcinv_radial, d12, fc12, fcp12, fn12, fnp12);
      for (int n = 0; n <= paramb.n_max_radial; ++n) {
        double gnp12 = 0.0;
        for (int k = 0; k <= paramb.basis_size_radial; ++k) {
          int c_index = (n * (paramb.basis_size_radial + 1) + k) * paramb.num_types_sq;
          c_index += t1 * paramb.num_types + t2;
          gnp12 += fnp12[k] * annmb.c[c_index];
        }
        double tmp12 = g_charge_derivative[n1 + n * N] * gnp12 * d12inv;
        for (int d = 0; d < 3; ++d) {
          f12[d] += tmp12 * r12[d];
        }
      }

      double bec_values[9] = {
        0.5 * r12[0] * f12[0], 0.5 * r12[0] * f12[1], 0.5 * r12[0] * f12[2],
        0.5 * r12[1] * f12[0], 0.5 * r12[1] * f12[1], 0.5 * r12[1] * f12[2],
        0.5 * r12[2] * f12[0], 0.5 * r12[2] * f12[1], 0.5 * r12[2] * f12[2]};
      for (int d = 0; d < 9; ++d) {
        bec[n1 + N * d] += bec_values[d];
        bec[n2 + N * d] -= bec_values[d];
      }
    }
  }
}

void find_bec_angular(
  NEP_CPU::ParaMB& paramb,
  NEP_CPU::ANN& annmb,
  const int N,
  const int* g_NN,
  const int* g_NL,
  const int* g_type,
  const double* g_x12,
  const double* g_y12,
  const double* g_z12,
  const double* g_charge_derivative,
  const double* g_sum_fxyz,
  std::vector<double>& bec)
{
  for (int n1 = 0; n1 < N; ++n1) {
    double Fp[MAX_DIM_ANGULAR] = {0.0};
    double sum_fxyz[NUM_OF_ABC * MAX_NUM_N];
    for (int d = 0; d < paramb.dim_angular; ++d) {
      Fp[d] = g_charge_derivative[(paramb.n_max_radial + 1 + d) * N + n1];
    }
    for (int d = 0; d < (paramb.n_max_angular + 1) * NUM_OF_ABC; ++d) {
      sum_fxyz[d] = g_sum_fxyz[d * N + n1];
    }
    int t1 = g_type[n1];
    for (int i1 = 0; i1 < g_NN[n1]; ++i1) {
      int index = i1 * N + n1;
      int n2 = g_NL[index];
      int t2 = g_type[n2];
      double r12[3] = {g_x12[index], g_y12[index], g_z12[index]};
      double d12 = sqrt(r12[0] * r12[0] + r12[1] * r12[1] + r12[2] * r12[2]);
      double f12[3] = {0.0};
      double fc12, fcp12;
      find_fc_and_fcp(paramb.rc_angular, paramb.rcinv_angular, d12, fc12, fcp12);
      double fn12[MAX_NUM_N];
      double fnp12[MAX_NUM_N];
      find_fn_and_fnp(paramb.basis_size_angular, paramb.rcinv_angular, d12, fc12, fcp12, fn12, fnp12);
      for (int n = 0; n <= paramb.n_max_angular; ++n) {
        double gn12 = 0.0;
        double gnp12 = 0.0;
        for (int k = 0; k <= paramb.basis_size_angular; ++k) {
          int c_index = (n * (paramb.basis_size_angular + 1) + k) * paramb.num_types_sq;
          c_index += t1 * paramb.num_types + t2 + paramb.num_c_radial;
          gn12 += fn12[k] * annmb.c[c_index];
          gnp12 += fnp12[k] * annmb.c[c_index];
        }
        if (paramb.num_L == paramb.L_max) {
          accumulate_f12(n, paramb.n_max_angular + 1, d12, r12, gn12, gnp12, Fp, sum_fxyz, f12);
        } else if (paramb.num_L == paramb.L_max + 1) {
          accumulate_f12_with_4body(n, paramb.n_max_angular + 1, d12, r12, gn12, gnp12, Fp, sum_fxyz, f12);
        } else {
          accumulate_f12_with_5body(n, paramb.n_max_angular + 1, d12, r12, gn12, gnp12, Fp, sum_fxyz, f12);
        }
      }
      double bec_values[9] = {
        0.5 * r12[0] * f12[0], 0.5 * r12[0] * f12[1], 0.5 * r12[0] * f12[2],
        0.5 * r12[1] * f12[0], 0.5 * r12[1] * f12[1], 0.5 * r12[1] * f12[2],
        0.5 * r12[2] * f12[0], 0.5 * r12[2] * f12[1], 0.5 * r12[2] * f12[2]};
      for (int d = 0; d < 9; ++d) {
        bec[n1 + N * d] += bec_values[d];
        bec[n2 + N * d] -= bec_values[d];
      }
    }
  }
}

void cross_product(const double a[3], const double b[3], double c[3])
{
  c[0] = a[1] * b[2] - a[2] * b[1];
  c[1] = a[2] * b[0] - a[0] * b[2];
  c[2] = a[0] * b[1] - a[1] * b[0];
}

double get_area_vector(const double* a, const double* b)
{
  double s1 = a[1] * b[2] - a[2] * b[1];
  double s2 = a[2] * b[0] - a[0] * b[2];
  double s3 = a[0] * b[1] - a[1] * b[0];
  return sqrt(s1 * s1 + s2 * s2 + s3 * s3);
}

void find_k_and_G(
  const int num_kpoints_max,
  const double alpha,
  const double alpha_factor,
  const std::vector<double>& box,
  std::vector<int>& num_kpoints,
  std::vector<double>& kx,
  std::vector<double>& ky,
  std::vector<double>& kz,
  std::vector<double>& G)
{
  const double det = box[0] * (box[4] * box[8] - box[5] * box[7]) +
                     box[1] * (box[5] * box[6] - box[3] * box[8]) +
                     box[2] * (box[3] * box[7] - box[4] * box[6]);
  const double a1[3] = {box[0], box[3], box[6]};
  const double a2[3] = {box[1], box[4], box[7]};
  const double a3[3] = {box[2], box[5], box[8]};
  double b1[3] = {0.0};
  double b2[3] = {0.0};
  double b3[3] = {0.0};
  cross_product(a2, a3, b1);
  cross_product(a3, a1, b2);
  cross_product(a1, a2, b3);

  const double two_pi = 2.0 * PI;
  const double two_pi_over_det = two_pi / det;
  for (int d = 0; d < 3; ++d) {
    b1[d] *= two_pi_over_det;
    b2[d] *= two_pi_over_det;
    b3[d] *= two_pi_over_det;
  }

  const double volume_k = two_pi * two_pi * two_pi / std::abs(det);
  const int n1_max = int(alpha * two_pi * get_area_vector(b2, b3) / volume_k);
  const int n2_max = int(alpha * two_pi * get_area_vector(b3, b1) / volume_k);
  const int n3_max = int(alpha * two_pi * get_area_vector(b1, b2) / volume_k);
  const double ksq_max = two_pi * two_pi * alpha * alpha;

  int nk = 0;
  for (int n1 = 0; n1 <= n1_max; ++n1) {
    for (int n2 = -n2_max; n2 <= n2_max; ++n2) {
      for (int n3 = -n3_max; n3 <= n3_max; ++n3) {
        const int nsq = n1 * n1 + n2 * n2 + n3 * n3;
        if (nsq == 0 || (n1 == 0 && n2 < 0) || (n1 == 0 && n2 == 0 && n3 < 0)) {
          continue;
        }
        const double kx_value = n1 * b1[0] + n2 * b2[0] + n3 * b3[0];
        const double ky_value = n1 * b1[1] + n2 * b2[1] + n3 * b3[1];
        const double kz_value = n1 * b1[2] + n2 * b2[2] + n3 * b3[2];
        const double ksq = kx_value * kx_value + ky_value * ky_value + kz_value * kz_value;
        if (ksq < ksq_max) {
          if (nk < num_kpoints_max) {
            kx[nk] = kx_value;
            ky[nk] = ky_value;
            kz[nk] = kz_value;
            G[nk] = 2.0 * std::abs(two_pi_over_det) / ksq * exp(-ksq * alpha_factor);
          }
          ++nk;
        }
      }
    }
  }
  num_kpoints[0] = std::min(nk, num_kpoints_max);
}

void find_structure_factor(
  const int N,
  const int num_kpoints,
  const std::vector<double>& charge,
  const std::vector<double>& position,
  const std::vector<double>& kx,
  const std::vector<double>& ky,
  const std::vector<double>& kz,
  std::vector<double>& S_real,
  std::vector<double>& S_imag)
{
  for (int nk = 0; nk < num_kpoints; ++nk) {
    double real_sum = 0.0;
    double imag_sum = 0.0;
    for (int n = 0; n < N; ++n) {
      const double kr = kx[nk] * position[n] + ky[nk] * position[n + N] + kz[nk] * position[n + 2 * N];
      real_sum += charge[n] * cos(kr);
      imag_sum -= charge[n] * sin(kr);
    }
    S_real[nk] = real_sum;
    S_imag[nk] = imag_sum;
  }
}

void find_force_charge_reciprocal_space(
  const int N,
  const int num_kpoints,
  const double alpha_factor,
  const std::vector<double>& charge,
  const std::vector<double>& position,
  const std::vector<double>& kx,
  const std::vector<double>& ky,
  const std::vector<double>& kz,
  const std::vector<double>& G,
  const std::vector<double>& S_real,
  const std::vector<double>& S_imag,
  std::vector<double>& D_real,
  std::vector<double>& force,
  std::vector<double>& virial,
  std::vector<double>& total_virial,
  std::vector<double>& potential)
{
  for (int n = 0; n < N; ++n) {
    const double q = charge[n];
    double temp_virial_sum[6] = {0.0};
    double temp_force_sum[3] = {0.0};
    double temp_D_real_sum = 0.0;
    for (int nk = 0; nk < num_kpoints; ++nk) {
      const double kr = kx[nk] * position[n] + ky[nk] * position[n + N] + kz[nk] * position[n + 2 * N];
      const double sin_kr = sin(kr);
      const double cos_kr = cos(kr);
      const double imag_term = G[nk] * (S_real[nk] * sin_kr + S_imag[nk] * cos_kr);
      const double GSE = G[nk] * (S_real[nk] * cos_kr - S_imag[nk] * sin_kr);
      const double qGSE = q * GSE;
      const double ksq = kx[nk] * kx[nk] + ky[nk] * ky[nk] + kz[nk] * kz[nk];
      const double alpha_k_factor = 2.0 * alpha_factor + 2.0 / ksq;
      temp_virial_sum[0] += qGSE * (1.0 - alpha_k_factor * kx[nk] * kx[nk]);
      temp_virial_sum[1] += qGSE * (1.0 - alpha_k_factor * ky[nk] * ky[nk]);
      temp_virial_sum[2] += qGSE * (1.0 - alpha_k_factor * kz[nk] * kz[nk]);
      temp_virial_sum[3] -= qGSE * (alpha_k_factor * kx[nk] * ky[nk]);
      temp_virial_sum[4] -= qGSE * (alpha_k_factor * ky[nk] * kz[nk]);
      temp_virial_sum[5] -= qGSE * (alpha_k_factor * kz[nk] * kx[nk]);
      temp_D_real_sum += GSE;
      temp_force_sum[0] += kx[nk] * imag_term;
      temp_force_sum[1] += ky[nk] * imag_term;
      temp_force_sum[2] += kz[nk] * imag_term;
    }
    const double virial_xx = K_C_SP * temp_virial_sum[0];
    const double virial_yy = K_C_SP * temp_virial_sum[1];
    const double virial_zz = K_C_SP * temp_virial_sum[2];
    const double virial_xy = K_C_SP * temp_virial_sum[3];
    const double virial_yz = K_C_SP * temp_virial_sum[4];
    const double virial_zx = K_C_SP * temp_virial_sum[5];
    if (!virial.empty()) {
      virial[n + 0 * N] += virial_xx;
      virial[n + 1 * N] += virial_xy;
      virial[n + 2 * N] += virial_zx;
      virial[n + 3 * N] += virial_xy;
      virial[n + 4 * N] += virial_yy;
      virial[n + 5 * N] += virial_yz;
      virial[n + 6 * N] += virial_zx;
      virial[n + 7 * N] += virial_yz;
      virial[n + 8 * N] += virial_zz;
    }
    total_virial[0] += virial_xx;
    total_virial[1] += virial_xy;
    total_virial[2] += virial_zx;
    total_virial[4] += virial_yy;
    total_virial[5] += virial_yz;
    total_virial[8] += virial_zz;
    D_real[n] = 2.0 * K_C_SP * temp_D_real_sum;
    potential[n] += 0.5 * q * D_real[n];
    const double charge_factor = K_C_SP * 2.0 * q;
    force[n] += charge_factor * temp_force_sum[0];
    force[n + N] += charge_factor * temp_force_sum[1];
    force[n + 2 * N] += charge_factor * temp_force_sum[2];
  }
}

double get_area(const int d, const double* cpu_h);
double get_volume(const double* cpu_h);
void get_inverse(double* cpu_h);

int get_best_pppm_K_cpu(const int m)
{
  int n = 16;
  while (n < m) {
    n *= 2;
  }
  return n;
}

const double PPPM_SINC_COEFF[6] = {
  1.0, -1.6666667e-1, 8.3333333e-3, -1.9841270e-4, 2.7557319e-6, -2.5052108e-8};
const double PPPM_G_COEFF[5] = {
  1.0000000e+00, -1.6666667e+00, 7.7777778e-01, -8.9947090e-02, 7.0546737e-04};
const double PPPM_W_COEFF[5][5] = {
  {2.6041667e-03, -2.0833333e-02, 6.2500000e-02, -8.3333333e-02, 4.1666667e-02},
  {1.9791667e-01, -4.5833333e-01, 2.5000000e-01, 1.6666667e-01, -1.6666667e-01},
  {5.9895833e-01, 0.0000000e+00, -6.2500000e-01, 0.0000000e+00, 2.5000000e-01},
  {1.9791667e-01, 4.5833333e-01, 2.5000000e-01, -1.6666667e-01, -1.6666667e-01},
  {2.6041667e-03, 2.0833333e-02, 6.2500000e-02, 8.3333333e-02, 4.1666667e-02}};

struct PPPM_Para_CPU {
  int K0K1K2 = 0;
  int K0K1 = 0;
  int K[3] = {0, 0, 0};
  int K_half[3] = {0, 0, 0};
  double alpha = 0.0;
  double alpha_factor = 0.0;
  double two_pi_over_V = 0.0;
  double b[3][3];
  double two_pi_over_K[3];
};

double pppm_sinc_cpu(const double x)
{
  double y = 0.0;
  if (x * x <= 1.0) {
    double term = 1.0;
    for (int i = 0; i < 6; ++i) {
      y += PPPM_SINC_COEFF[i] * term;
      term *= x * x;
    }
  } else {
    y = sin(x) / x;
  }
  return y;
}

int pppm_mesh_index_cpu(const int K, const int n)
{
  int y = n;
  if (n >= K) {
    y = n - K;
  } else if (n < 0) {
    y = n + K;
  }
  return y;
}

void pppm_find_para_cpu(
  const int N,
  const double alpha,
  const double alpha_factor,
  const std::vector<double>& box,
  PPPM_Para_CPU& para,
  double h[18])
{
  for (int d = 0; d < 9; ++d) {
    h[d] = box[d];
  }
  get_inverse(h);
  const double two_pi = 2.0 * PI;
  const double mesh_spacing = 1.0;
  const double volume = get_volume(box.data());
  para.alpha = alpha;
  para.alpha_factor = alpha_factor;
  para.two_pi_over_V = two_pi / volume;
  for (int d = 0; d < 3; ++d) {
    const double box_thickness = volume / get_area(d, box.data());
    para.K[d] = get_best_pppm_K_cpu(int(box_thickness / mesh_spacing));
    para.K_half[d] = para.K[d] / 2;
    para.two_pi_over_K[d] = two_pi / para.K[d];
  }
  para.K0K1 = para.K[0] * para.K[1];
  para.K0K1K2 = para.K0K1 * para.K[2];
  for (int d = 0; d < 3; ++d) {
    para.b[0][d] = two_pi * h[9 + d];
    para.b[1][d] = two_pi * h[12 + d];
    para.b[2][d] = two_pi * h[15 + d];
  }
  (void)N;
}

void pppm_find_k_and_G_cpu(
  const PPPM_Para_CPU& para,
  std::vector<double>& kx,
  std::vector<double>& ky,
  std::vector<double>& kz,
  std::vector<double>& G)
{
  for (int n = 0; n < para.K0K1K2; ++n) {
    int nk[3];
    nk[2] = n / para.K0K1;
    nk[1] = (n - nk[2] * para.K0K1) / para.K[0];
    nk[0] = n % para.K[0];
    double denominator[3] = {0.0};
    for (int d = 0; d < 3; ++d) {
      if (nk[d] >= para.K_half[d]) {
        nk[d] -= para.K[d];
      }
      double t = sin(0.5 * para.two_pi_over_K[d] * nk[d]);
      t *= t;
      t = (((PPPM_G_COEFF[4] * t + PPPM_G_COEFF[3]) * t + PPPM_G_COEFF[2]) * t
           + PPPM_G_COEFF[1]) * t + PPPM_G_COEFF[0];
      denominator[d] = t * t;
    }
    const double kx_value = nk[0] * para.b[0][0] + nk[1] * para.b[1][0] + nk[2] * para.b[2][0];
    const double ky_value = nk[0] * para.b[0][1] + nk[1] * para.b[1][1] + nk[2] * para.b[2][1];
    const double kz_value = nk[0] * para.b[0][2] + nk[1] * para.b[1][2] + nk[2] * para.b[2][2];
    kx[n] = kx_value;
    ky[n] = ky_value;
    kz[n] = kz_value;
    const double ksq = kx_value * kx_value + ky_value * ky_value + kz_value * kz_value;
    double numerator = pppm_sinc_cpu(0.5 * para.two_pi_over_K[0] * nk[0]);
    numerator *= pppm_sinc_cpu(0.5 * para.two_pi_over_K[1] * nk[1]);
    numerator *= pppm_sinc_cpu(0.5 * para.two_pi_over_K[2] * nk[2]);
    numerator = numerator * numerator * numerator * numerator * numerator;
    numerator *= numerator;
    if (ksq == 0.0) {
      G[n] = 0.0;
    } else {
      double G_opt = numerator * para.two_pi_over_V / ksq * exp(-ksq * para.alpha_factor);
      G_opt /= denominator[0] * denominator[1] * denominator[2];
      G[n] = G_opt;
    }
  }
}

void pppm_find_weights_cpu(const double sx, const double sy, const double sz, int& ix, int& iy, int& iz, double Wx[5], double Wy[5], double Wz[5])
{
  ix = int(sx + 0.5);
  iy = int(sy + 0.5);
  iz = int(sz + 0.5);
  const double dx = sx - ix;
  const double dy = sy - iy;
  const double dz = sz - iz;
  for (int d = 0; d < 5; ++d) {
    Wx[d] = (((PPPM_W_COEFF[d][4] * dx + PPPM_W_COEFF[d][3]) * dx + PPPM_W_COEFF[d][2]) * dx
             + PPPM_W_COEFF[d][1]) * dx + PPPM_W_COEFF[d][0];
    Wy[d] = (((PPPM_W_COEFF[d][4] * dy + PPPM_W_COEFF[d][3]) * dy + PPPM_W_COEFF[d][2]) * dy
             + PPPM_W_COEFF[d][1]) * dy + PPPM_W_COEFF[d][0];
    Wz[d] = (((PPPM_W_COEFF[d][4] * dz + PPPM_W_COEFF[d][3]) * dz + PPPM_W_COEFF[d][2]) * dz
             + PPPM_W_COEFF[d][1]) * dz + PPPM_W_COEFF[d][0];
  }
}

void pppm_forward_dft_cpu(
  const PPPM_Para_CPU& para,
  const std::vector<std::complex<double>>& in,
  std::vector<std::complex<double>>& out)
{
  std::vector<std::complex<double>> tmp_x(para.K0K1K2);
  std::vector<std::complex<double>> tmp_y(para.K0K1K2);
  for (int iz = 0; iz < para.K[2]; ++iz) {
    for (int iy = 0; iy < para.K[1]; ++iy) {
      for (int nk0 = 0; nk0 < para.K[0]; ++nk0) {
        std::complex<double> sum(0.0, 0.0);
        for (int ix = 0; ix < para.K[0]; ++ix) {
          const double phase = para.two_pi_over_K[0] * nk0 * ix;
          sum += in[ix + para.K[0] * (iy + para.K[1] * iz)]
               * std::complex<double>(cos(phase), -sin(phase));
        }
        tmp_x[nk0 + para.K[0] * (iy + para.K[1] * iz)] = sum;
      }
    }
  }
  for (int iz = 0; iz < para.K[2]; ++iz) {
    for (int nk0 = 0; nk0 < para.K[0]; ++nk0) {
      for (int nk1 = 0; nk1 < para.K[1]; ++nk1) {
        std::complex<double> sum(0.0, 0.0);
        for (int iy = 0; iy < para.K[1]; ++iy) {
          const double phase = para.two_pi_over_K[1] * nk1 * iy;
          sum += tmp_x[nk0 + para.K[0] * (iy + para.K[1] * iz)]
               * std::complex<double>(cos(phase), -sin(phase));
        }
        tmp_y[nk0 + para.K[0] * (nk1 + para.K[1] * iz)] = sum;
      }
    }
  }
  for (int nk0 = 0; nk0 < para.K[0]; ++nk0) {
    for (int nk1 = 0; nk1 < para.K[1]; ++nk1) {
      for (int nk2 = 0; nk2 < para.K[2]; ++nk2) {
        std::complex<double> sum(0.0, 0.0);
        for (int iz = 0; iz < para.K[2]; ++iz) {
          const double phase = para.two_pi_over_K[2] * nk2 * iz;
          sum += tmp_y[nk0 + para.K[0] * (nk1 + para.K[1] * iz)]
               * std::complex<double>(cos(phase), -sin(phase));
        }
        out[nk0 + para.K[0] * (nk1 + para.K[1] * nk2)] = sum;
      }
    }
  }
}

void pppm_inverse_dft_cpu(
  const PPPM_Para_CPU& para,
  const std::vector<std::complex<double>>& in,
  std::vector<std::complex<double>>& out)
{
  std::vector<std::complex<double>> tmp_x(para.K0K1K2);
  std::vector<std::complex<double>> tmp_y(para.K0K1K2);
  for (int nk2 = 0; nk2 < para.K[2]; ++nk2) {
    for (int nk1 = 0; nk1 < para.K[1]; ++nk1) {
      for (int ix = 0; ix < para.K[0]; ++ix) {
        std::complex<double> sum(0.0, 0.0);
        for (int nk0 = 0; nk0 < para.K[0]; ++nk0) {
          const double phase = para.two_pi_over_K[0] * nk0 * ix;
          sum += in[nk0 + para.K[0] * (nk1 + para.K[1] * nk2)]
               * std::complex<double>(cos(phase), sin(phase));
        }
        tmp_x[ix + para.K[0] * (nk1 + para.K[1] * nk2)] = sum;
      }
    }
  }
  for (int nk2 = 0; nk2 < para.K[2]; ++nk2) {
    for (int ix = 0; ix < para.K[0]; ++ix) {
      for (int iy = 0; iy < para.K[1]; ++iy) {
        std::complex<double> sum(0.0, 0.0);
        for (int nk1 = 0; nk1 < para.K[1]; ++nk1) {
          const double phase = para.two_pi_over_K[1] * nk1 * iy;
          sum += tmp_x[ix + para.K[0] * (nk1 + para.K[1] * nk2)]
               * std::complex<double>(cos(phase), sin(phase));
        }
        tmp_y[ix + para.K[0] * (iy + para.K[1] * nk2)] = sum;
      }
    }
  }
  for (int ix = 0; ix < para.K[0]; ++ix) {
    for (int iy = 0; iy < para.K[1]; ++iy) {
      for (int iz = 0; iz < para.K[2]; ++iz) {
        std::complex<double> sum(0.0, 0.0);
        for (int nk2 = 0; nk2 < para.K[2]; ++nk2) {
          const double phase = para.two_pi_over_K[2] * nk2 * iz;
          sum += tmp_y[ix + para.K[0] * (iy + para.K[1] * nk2)]
               * std::complex<double>(cos(phase), sin(phase));
        }
        out[ix + para.K[0] * (iy + para.K[1] * iz)] = sum;
      }
    }
  }
}

void pppm_find_force_charge_cpu(
  const int N,
  const double alpha,
  const double alpha_factor,
  const std::vector<double>& box,
  const std::vector<double>& charge,
  const std::vector<double>& position,
  std::vector<double>& D_real,
  std::vector<double>& force,
  std::vector<double>& virial,
  std::vector<double>& total_virial,
  std::vector<double>& potential)
{
  PPPM_Para_CPU para;
  double h[18] = {0.0};
  pppm_find_para_cpu(N, alpha, alpha_factor, box, para, h);
  std::vector<double> kx(para.K0K1K2, 0.0);
  std::vector<double> ky(para.K0K1K2, 0.0);
  std::vector<double> kz(para.K0K1K2, 0.0);
  std::vector<double> G(para.K0K1K2, 0.0);
  pppm_find_k_and_G_cpu(para, kx, ky, kz, G);

  std::vector<std::complex<double>> mesh(para.K0K1K2, std::complex<double>(0.0, 0.0));
  for (int n = 0; n < N; ++n) {
    const double x = position[n];
    const double y = position[n + N];
    const double z = position[n + 2 * N];
    const double sx = (h[9] * x + h[10] * y + h[11] * z) * para.K[0];
    const double sy = (h[12] * x + h[13] * y + h[14] * z) * para.K[1];
    const double sz = (h[15] * x + h[16] * y + h[17] * z) * para.K[2];
    int ix, iy, iz;
    double Wx[5], Wy[5], Wz[5];
    pppm_find_weights_cpu(sx, sy, sz, ix, iy, iz, Wx, Wy, Wz);
    for (int n0 = -2; n0 <= 2; ++n0) {
      const int neighbor0 = pppm_mesh_index_cpu(para.K[0], ix + n0);
      for (int n1 = -2; n1 <= 2; ++n1) {
        const int neighbor1 = pppm_mesh_index_cpu(para.K[1], iy + n1);
        for (int n2 = -2; n2 <= 2; ++n2) {
          const int neighbor2 = pppm_mesh_index_cpu(para.K[2], iz + n2);
          const int idx = neighbor0 + para.K[0] * (neighbor1 + para.K[1] * neighbor2);
          const double W = Wx[n0 + 2] * Wy[n1 + 2] * Wz[n2 + 2];
          mesh[idx] += std::complex<double>(charge[n] * W, 0.0);
        }
      }
    }
  }

  std::vector<std::complex<double>> mesh_fft(para.K0K1K2);
  pppm_forward_dft_cpu(para, mesh, mesh_fft);

  std::vector<std::complex<double>> mesh_G(para.K0K1K2);
  std::vector<std::complex<double>> mesh_x(para.K0K1K2);
  std::vector<std::complex<double>> mesh_y(para.K0K1K2);
  std::vector<std::complex<double>> mesh_z(para.K0K1K2);
  std::vector<std::complex<double>> mesh_virial_fft[6];
  std::vector<std::complex<double>> mesh_virial[6];
  for (int d = 0; d < 6; ++d) {
    mesh_virial_fft[d].assign(para.K0K1K2, std::complex<double>(0.0, 0.0));
    mesh_virial[d].assign(para.K0K1K2, std::complex<double>(0.0, 0.0));
  }

  for (int i = 0; i < para.K0K1K2; ++i) {
    mesh_G[i] = mesh_fft[i] * G[i];
    mesh_x[i] = std::complex<double>(mesh_fft[i].imag() * kx[i] * G[i], -mesh_fft[i].real() * kx[i] * G[i]);
    mesh_y[i] = std::complex<double>(mesh_fft[i].imag() * ky[i] * G[i], -mesh_fft[i].real() * ky[i] * G[i]);
    mesh_z[i] = std::complex<double>(mesh_fft[i].imag() * kz[i] * G[i], -mesh_fft[i].real() * kz[i] * G[i]);
    const double ksq = kx[i] * kx[i] + ky[i] * ky[i] + kz[i] * kz[i];
    if (ksq != 0.0) {
      const double alpha_k_factor = 2.0 * para.alpha_factor + 2.0 / ksq;
      const std::complex<double> GS = mesh_fft[i] * G[i];
      double B = 1.0 - alpha_k_factor * kx[i] * kx[i];
      mesh_virial_fft[0][i] = GS * B;
      B = 1.0 - alpha_k_factor * ky[i] * ky[i];
      mesh_virial_fft[1][i] = GS * B;
      B = 1.0 - alpha_k_factor * kz[i] * kz[i];
      mesh_virial_fft[2][i] = GS * B;
      B = -alpha_k_factor * kx[i] * ky[i];
      mesh_virial_fft[3][i] = GS * B;
      B = -alpha_k_factor * ky[i] * kz[i];
      mesh_virial_fft[4][i] = GS * B;
      B = -alpha_k_factor * kz[i] * kx[i];
      mesh_virial_fft[5][i] = GS * B;
    }
  }

  pppm_inverse_dft_cpu(para, mesh_G, mesh_G);
  pppm_inverse_dft_cpu(para, mesh_x, mesh_x);
  pppm_inverse_dft_cpu(para, mesh_y, mesh_y);
  pppm_inverse_dft_cpu(para, mesh_z, mesh_z);
  for (int d = 0; d < 6; ++d) {
    pppm_inverse_dft_cpu(para, mesh_virial_fft[d], mesh_virial[d]);
  }

  for (int n = 0; n < N; ++n) {
    const double x = position[n];
    const double y = position[n + N];
    const double z = position[n + 2 * N];
    const double q = K_C_SP * charge[n];
    const double sx = (h[9] * x + h[10] * y + h[11] * z) * para.K[0];
    const double sy = (h[12] * x + h[13] * y + h[14] * z) * para.K[1];
    const double sz = (h[15] * x + h[16] * y + h[17] * z) * para.K[2];
    int ix, iy, iz;
    double Wx[5], Wy[5], Wz[5];
    pppm_find_weights_cpu(sx, sy, sz, ix, iy, iz, Wx, Wy, Wz);
    double D_sum = 0.0;
    double E[3] = {0.0};
    double V[6] = {0.0};
    for (int n0 = -2; n0 <= 2; ++n0) {
      const int neighbor0 = pppm_mesh_index_cpu(para.K[0], ix + n0);
      for (int n1 = -2; n1 <= 2; ++n1) {
        const int neighbor1 = pppm_mesh_index_cpu(para.K[1], iy + n1);
        for (int n2 = -2; n2 <= 2; ++n2) {
          const int neighbor2 = pppm_mesh_index_cpu(para.K[2], iz + n2);
          const int idx = neighbor0 + para.K[0] * (neighbor1 + para.K[1] * neighbor2);
          const double W = Wx[n0 + 2] * Wy[n1 + 2] * Wz[n2 + 2];
          D_sum += W * mesh_G[idx].real();
          E[0] += W * mesh_x[idx].real();
          E[1] += W * mesh_y[idx].real();
          E[2] += W * mesh_z[idx].real();
          for (int d = 0; d < 6; ++d) {
            V[d] += W * mesh_virial[d][idx].real();
          }
        }
      }
    }
    D_real[n] = 2.0 * K_C_SP * D_sum;
    potential[n] += 0.5 * charge[n] * D_real[n];
    force[n] += 2.0 * q * E[0];
    force[n + N] += 2.0 * q * E[1];
    force[n + 2 * N] += 2.0 * q * E[2];

    const double virial_xx = q * V[0];
    const double virial_yy = q * V[1];
    const double virial_zz = q * V[2];
    const double virial_xy = q * V[3];
    const double virial_yz = q * V[4];
    const double virial_zx = q * V[5];
    if (!virial.empty()) {
      virial[n + 0 * N] += virial_xx;
      virial[n + 1 * N] += virial_xy;
      virial[n + 2 * N] += virial_zx;
      virial[n + 3 * N] += virial_xy;
      virial[n + 4 * N] += virial_yy;
      virial[n + 5 * N] += virial_yz;
      virial[n + 6 * N] += virial_zx;
      virial[n + 7 * N] += virial_yz;
      virial[n + 8 * N] += virial_zz;
    }
    total_virial[0] += virial_xx;
    total_virial[1] += virial_xy;
    total_virial[2] += virial_zx;
    total_virial[4] += virial_yy;
    total_virial[5] += virial_yz;
    total_virial[8] += virial_zz;
  }
}

void find_force_radial(
  const bool is_dipole,
  NEP_CPU::ParaMB& paramb,
  NEP_CPU::ANN& annmb,
  const int N,
  const int* g_NN,
  const int* g_NL,
  const int* g_type,
  const double* g_x12,
  const double* g_y12,
  const double* g_z12,
  const double* g_Fp,
  const double* g_charge_derivative,
  const double* g_D_real,
  double* g_fx,
  double* g_fy,
  double* g_fz,
  double* g_virial,
  double g_total_virial[9])
{
  for (int n1 = 0; n1 < N; ++n1) {
    int t1 = g_type[n1];
    for (int i1 = 0; i1 < g_NN[n1]; ++i1) {
      int index = i1 * N + n1;
      int n2 = g_NL[index];
      int t2 = g_type[n2];
      double r12[3] = {g_x12[index], g_y12[index], g_z12[index]};
      double d12 = sqrt(r12[0] * r12[0] + r12[1] * r12[1] + r12[2] * r12[2]);
      double d12inv = 1.0 / d12;
      double f12[3] = {0.0};
      double fc12, fcp12;
      find_fc_and_fcp(paramb.rc_radial, paramb.rcinv_radial, d12, fc12, fcp12);
      double fn12[MAX_NUM_N];
      double fnp12[MAX_NUM_N];
      if (paramb.version == 2) {
        find_fn_and_fnp(paramb.n_max_radial, paramb.rcinv_radial, d12, fc12, fcp12, fn12, fnp12);
        for (int n = 0; n <= paramb.n_max_radial; ++n) {
          double tmp12 = g_Fp[n1 + n * N] * fnp12[n] * d12inv;
          tmp12 *= (paramb.num_types == 1)
                     ? 1.0
                     : annmb.c[(n * paramb.num_types + t1) * paramb.num_types + t2];
          for (int d = 0; d < 3; ++d) {
            f12[d] += tmp12 * r12[d];
          }
        }
      } else {
        find_fn_and_fnp(
          paramb.basis_size_radial, paramb.rcinv_radial, d12, fc12, fcp12, fn12, fnp12);
        for (int n = 0; n <= paramb.n_max_radial; ++n) {
          double gnp12 = 0.0;
          for (int k = 0; k <= paramb.basis_size_radial; ++k) {
            int c_index = (n * (paramb.basis_size_radial + 1) + k) * paramb.num_types_sq;
            c_index += t1 * paramb.num_types + t2;
            gnp12 += fnp12[k] * annmb.c[c_index];
          }
          double descriptor_derivative = g_Fp[n1 + n * N];
          if (paramb.charge_mode == 2 && g_charge_derivative && g_D_real) {
            descriptor_derivative += g_charge_derivative[n1 + n * N] * g_D_real[n1];
          }
          double tmp12 = descriptor_derivative * gnp12 * d12inv;
          for (int d = 0; d < 3; ++d) {
            f12[d] += tmp12 * r12[d];
          }
        }
      }

      if (g_fx) {
        g_fx[n1] += f12[0];
        g_fx[n2] -= f12[0];
      }

      if (g_fy) {
        g_fy[n1] += f12[1];
        g_fy[n2] -= f12[1];
      }

      if (g_fz) {
        g_fz[n1] += f12[2];
        g_fz[n2] -= f12[2];
      }
      
      if (g_virial) {
          if(!is_dipole) {
          g_virial[n2 + 0 * N] -= r12[0] * f12[0];
          g_virial[n2 + 1 * N] -= r12[0] * f12[1];
          g_virial[n2 + 2 * N] -= r12[0] * f12[2];
          g_virial[n2 + 3 * N] -= r12[1] * f12[0];
          g_virial[n2 + 4 * N] -= r12[1] * f12[1];
          g_virial[n2 + 5 * N] -= r12[1] * f12[2];
          g_virial[n2 + 6 * N] -= r12[2] * f12[0];
          g_virial[n2 + 7 * N] -= r12[2] * f12[1];
          g_virial[n2 + 8 * N] -= r12[2] * f12[2];
          } else {
          double r12_square = r12[0] * r12[0] + r12[1] * r12[1] + r12[2] * r12[2];
          g_virial[n2 + 0 * N] -= r12_square * f12[0];
          g_virial[n2 + 1 * N] -= r12_square * f12[1];
          g_virial[n2 + 2 * N] -= r12_square * f12[2];
        }
      }
      g_total_virial[0] -= r12[0] * f12[0]; // xx
      g_total_virial[1] -= r12[0] * f12[1]; // xy
      g_total_virial[2] -= r12[0] * f12[2]; // xz
      g_total_virial[4] -= r12[1] * f12[1]; // yy
      g_total_virial[5] -= r12[1] * f12[2]; // yz
      g_total_virial[8] -= r12[2] * f12[2]; // zz
    }
  }
}

void find_force_angular(
  const bool is_dipole,
  NEP_CPU::ParaMB& paramb,
  NEP_CPU::ANN& annmb,
  const int N,
  const int* g_NN_angular,
  const int* g_NL_angular,
  const int* g_type,
  const double* g_x12,
  const double* g_y12,
  const double* g_z12,
  const double* g_Fp,
  const double* g_charge_derivative,
  const double* g_D_real,
  const double* g_sum_fxyz,
  double* g_fx,
  double* g_fy,
  double* g_fz,
  double* g_virial,
  double g_total_virial[9])
{
  for (int n1 = 0; n1 < N; ++n1) {

    double Fp[MAX_DIM_ANGULAR] = {0.0};
    double sum_fxyz[NUM_OF_ABC * MAX_NUM_N];
    for (int d = 0; d < paramb.dim_angular; ++d) {
      double descriptor_derivative = g_Fp[(paramb.n_max_radial + 1 + d) * N + n1];
      if (paramb.charge_mode == 2 && g_charge_derivative && g_D_real) {
        descriptor_derivative += g_charge_derivative[(paramb.n_max_radial + 1 + d) * N + n1] * g_D_real[n1];
      }
      Fp[d] = descriptor_derivative;
    }
    for (int d = 0; d < (paramb.n_max_angular + 1) * NUM_OF_ABC; ++d) {
      sum_fxyz[d] = g_sum_fxyz[d * N + n1];
    }

    int t1 = g_type[n1];

    for (int i1 = 0; i1 < g_NN_angular[n1]; ++i1) {
      int index = i1 * N + n1;
      int n2 = g_NL_angular[n1 + N * i1];
      double r12[3] = {g_x12[index], g_y12[index], g_z12[index]};
      double d12 = sqrt(r12[0] * r12[0] + r12[1] * r12[1] + r12[2] * r12[2]);
      double f12[3] = {0.0};
      double fc12, fcp12;
      find_fc_and_fcp(paramb.rc_angular, paramb.rcinv_angular, d12, fc12, fcp12);
      int t2 = g_type[n2];

      if (paramb.version == 2) {
        for (int n = 0; n <= paramb.n_max_angular; ++n) {
          double fn;
          double fnp;
          find_fn_and_fnp(n, paramb.rcinv_angular, d12, fc12, fcp12, fn, fnp);
          const double c =
            (paramb.num_types == 1)
              ? 1.0
              : annmb.c
                  [((paramb.n_max_radial + 1 + n) * paramb.num_types + t1) * paramb.num_types + t2];
          fn *= c;
          fnp *= c;
          accumulate_f12(n, paramb.n_max_angular + 1, d12, r12, fn, fnp, Fp, sum_fxyz, f12);
        }
      } else {
        double fn12[MAX_NUM_N];
        double fnp12[MAX_NUM_N];
        find_fn_and_fnp(
          paramb.basis_size_angular, paramb.rcinv_angular, d12, fc12, fcp12, fn12, fnp12);
        for (int n = 0; n <= paramb.n_max_angular; ++n) {
          double gn12 = 0.0;
          double gnp12 = 0.0;
          for (int k = 0; k <= paramb.basis_size_angular; ++k) {
            int c_index = (n * (paramb.basis_size_angular + 1) + k) * paramb.num_types_sq;
            c_index += t1 * paramb.num_types + t2 + paramb.num_c_radial;
            gn12 += fn12[k] * annmb.c[c_index];
            gnp12 += fnp12[k] * annmb.c[c_index];
          }
          if (paramb.num_L == paramb.L_max) {
            accumulate_f12(n, paramb.n_max_angular + 1, d12, r12, gn12, gnp12, Fp, sum_fxyz, f12);
          } else if (paramb.num_L == paramb.L_max + 1) {
            accumulate_f12_with_4body(
              n, paramb.n_max_angular + 1, d12, r12, gn12, gnp12, Fp, sum_fxyz, f12);
          } else {
            accumulate_f12_with_5body(
              n, paramb.n_max_angular + 1, d12, r12, gn12, gnp12, Fp, sum_fxyz, f12);
          }
        }
      }
      // printf("angular_in n1=%d, n2=%d, r12=%f, f12[0]=%f, f12[1]=%f, f12[2]=%f\n",n1, n2, d12, f12[0],f12[1],f12[2]);
      if (g_fx) {
        g_fx[n1] += f12[0];
        g_fx[n2] -= f12[0];
      }

      if (g_fy) {
        g_fy[n1] += f12[1];
        g_fy[n2] -= f12[1];
      }

      if (g_fz) {
        g_fz[n1] += f12[2];
        g_fz[n2] -= f12[2];
      }

      if (g_virial) {
          if(!is_dipole) {
          g_virial[n2 + 0 * N] -= r12[0] * f12[0];
          g_virial[n2 + 1 * N] -= r12[0] * f12[1];
          g_virial[n2 + 2 * N] -= r12[0] * f12[2];
          g_virial[n2 + 3 * N] -= r12[1] * f12[0];
          g_virial[n2 + 4 * N] -= r12[1] * f12[1];
          g_virial[n2 + 5 * N] -= r12[1] * f12[2];
          g_virial[n2 + 6 * N] -= r12[2] * f12[0];
          g_virial[n2 + 7 * N] -= r12[2] * f12[1];
          g_virial[n2 + 8 * N] -= r12[2] * f12[2];
          } else {
          double r12_square = r12[0] * r12[0] + r12[1] * r12[1] + r12[2] * r12[2];
          g_virial[n2 + 0 * N] -= r12_square * f12[0];
          g_virial[n2 + 1 * N] -= r12_square * f12[1];
          g_virial[n2 + 2 * N] -= r12_square * f12[2];
        }
      }
      g_total_virial[0] -= r12[0] * f12[0]; // xx
      g_total_virial[1] -= r12[0] * f12[1]; // xy
      g_total_virial[2] -= r12[0] * f12[2]; // xz
      g_total_virial[4] -= r12[1] * f12[1]; // yy
      g_total_virial[5] -= r12[1] * f12[2]; // yz
      g_total_virial[8] -= r12[2] * f12[2]; // zz
    }
  }
}

void find_force_ZBL(
  NEP_CPU::ParaMB paramb,
  const int N,
  const NEP_CPU::ZBL& zbl,
  const int* g_NN,
  const int* g_NL,
  const int* g_type,
  const double* g_x12,
  const double* g_y12,
  const double* g_z12,
  double* g_fx,
  double* g_fy,
  double* g_fz,
  double* g_virial,
  double* g_pe,
  double g_total_virial[9])
{
  for (int n1 = 0; n1 < N; ++n1) {
    int type1 = g_type[n1];
    int zi = zbl.atomic_numbers[type1];
    double pow_zi = pow(zi, 0.23);
    for (int i1 = 0; i1 < g_NN[n1]; ++i1) {
      int index = i1 * N + n1;
      int n2 = g_NL[index];
      double r12[3] = {g_x12[index], g_y12[index], g_z12[index]};
      double d12sq = r12[0] * r12[0] + r12[1] * r12[1] + r12[2] * r12[2];
      // double max_rc_outer = 2.5; This restriction has been removed in the latest version of GPUMD.
      // if (d12sq >= max_rc_outer * max_rc_outer) {
      //   continue;
      // }
      double d12 = sqrt(d12sq);
      double d12inv = 1.0 / d12;
      double f, fp;
      int type2 = g_type[n2];
      int zj = zbl.atomic_numbers[type2];
      double a_inv = (pow_zi + pow(zj, 0.23)) * 2.134563;
      double zizj = K_C_SP * zi * zj;
  
      if (zbl.flexibled) {
        int t1, t2;
        if (type1 < type2) {
          t1 = type1;
          t2 = type2;
        } else {
          t1 = type2;
          t2 = type1;
        }
        int zbl_index = t1 * zbl.num_types - (t1 * (t1 - 1)) / 2 + (t2 - t1);
        double ZBL_para[10];
        for (int i = 0; i < 10; ++i) {
          ZBL_para[i] = zbl.para[10 * zbl_index + i];
        }
        find_f_and_fp_zbl(ZBL_para, zizj, a_inv, d12, d12inv, f, fp);
      } else {
        double rc_inner = zbl.rc_inner;
        double rc_outer = zbl.rc_outer;
        if (paramb.use_typewise_cutoff_zbl) {
          // zi and zj start from 1, so need to minus 1 here
          rc_outer = std::min((COVALENT_RADIUS[zi - 1] + COVALENT_RADIUS[zj - 1]) * paramb.typewise_cutoff_zbl_factor, rc_outer);
          rc_inner = 0.0f;
        }
        find_f_and_fp_zbl(zizj, a_inv, rc_inner, rc_outer, d12, d12inv, f, fp);
      }

      double f2 = fp * d12inv * 0.5;
      double f12[3] = {r12[0] * f2, r12[1] * f2, r12[2] * f2};
      g_fx[n1] += f12[0];
      g_fy[n1] += f12[1];
      g_fz[n1] += f12[2];
      g_fx[n2] -= f12[0];
      g_fy[n2] -= f12[1];
      g_fz[n2] -= f12[2];
      if (g_virial){
      g_virial[n2 + 0 * N] -= r12[0] * f12[0];
      g_virial[n2 + 1 * N] -= r12[0] * f12[1];
      g_virial[n2 + 2 * N] -= r12[0] * f12[2];
      g_virial[n2 + 3 * N] -= r12[1] * f12[0];
      g_virial[n2 + 4 * N] -= r12[1] * f12[1];
      g_virial[n2 + 5 * N] -= r12[1] * f12[2];
      g_virial[n2 + 6 * N] -= r12[2] * f12[0];
      g_virial[n2 + 7 * N] -= r12[2] * f12[1];
      g_virial[n2 + 8 * N] -= r12[2] * f12[2];
      }
      g_total_virial[0] -= r12[0] * f12[0]; // xx
      g_total_virial[1] -= r12[0] * f12[1]; // xy
      g_total_virial[2] -= r12[0] * f12[2]; // xz
      g_total_virial[4] -= r12[1] * f12[1]; // yy
      g_total_virial[5] -= r12[1] * f12[2]; // yz
      g_total_virial[8] -= r12[2] * f12[2]; // zz
      
      g_pe[n1] += f * 0.5;
    }
  }
}

double get_area_one_direction(const double* a, const double* b)
{
  double s1 = a[1] * b[2] - a[2] * b[1];
  double s2 = a[2] * b[0] - a[0] * b[2];
  double s3 = a[0] * b[1] - a[1] * b[0];
  return sqrt(s1 * s1 + s2 * s2 + s3 * s3);
}

double get_area(const int d, const double* cpu_h)
{
  double area;
  double a[3] = {cpu_h[0], cpu_h[3], cpu_h[6]};
  double b[3] = {cpu_h[1], cpu_h[4], cpu_h[7]};
  double c[3] = {cpu_h[2], cpu_h[5], cpu_h[8]};
  if (d == 0) {
    area = get_area_one_direction(b, c);
  } else if (d == 1) {
    area = get_area_one_direction(c, a);
  } else {
    area = get_area_one_direction(a, b);
  }
  return area;
}

double get_det(const double* cpu_h)
{
  return cpu_h[0] * (cpu_h[4] * cpu_h[8] - cpu_h[5] * cpu_h[7]) +
         cpu_h[1] * (cpu_h[5] * cpu_h[6] - cpu_h[3] * cpu_h[8]) +
         cpu_h[2] * (cpu_h[3] * cpu_h[7] - cpu_h[4] * cpu_h[6]);
}

double get_volume(const double* cpu_h) { return abs(get_det(cpu_h)); }

void get_inverse(double* cpu_h)
{
  cpu_h[9] = cpu_h[4] * cpu_h[8] - cpu_h[5] * cpu_h[7];
  cpu_h[10] = cpu_h[2] * cpu_h[7] - cpu_h[1] * cpu_h[8];
  cpu_h[11] = cpu_h[1] * cpu_h[5] - cpu_h[2] * cpu_h[4];
  cpu_h[12] = cpu_h[5] * cpu_h[6] - cpu_h[3] * cpu_h[8];
  cpu_h[13] = cpu_h[0] * cpu_h[8] - cpu_h[2] * cpu_h[6];
  cpu_h[14] = cpu_h[2] * cpu_h[3] - cpu_h[0] * cpu_h[5];
  cpu_h[15] = cpu_h[3] * cpu_h[7] - cpu_h[4] * cpu_h[6];
  cpu_h[16] = cpu_h[1] * cpu_h[6] - cpu_h[0] * cpu_h[7];
  cpu_h[17] = cpu_h[0] * cpu_h[4] - cpu_h[1] * cpu_h[3];
  double det = get_det(cpu_h);
  for (int n = 9; n < 18; n++) {
    cpu_h[n] /= det;
  }
}

void get_expanded_box(const double rc, const double* box, int* num_cells, double* ebox)
{
  double volume = get_volume(box);
  // printf("=========vlume %f =======\n", volume);
  double thickness_x = volume / get_area(0, box);
  double thickness_y = volume / get_area(1, box);
  double thickness_z = volume / get_area(2, box);
  num_cells[0] = int(ceil(2.0 * rc / thickness_x));
  num_cells[1] = int(ceil(2.0 * rc / thickness_y));
  num_cells[2] = int(ceil(2.0 * rc / thickness_z));

  ebox[0] = box[0] * num_cells[0];
  ebox[3] = box[3] * num_cells[0];
  ebox[6] = box[6] * num_cells[0];
  ebox[1] = box[1] * num_cells[1];
  ebox[4] = box[4] * num_cells[1];
  ebox[7] = box[7] * num_cells[1];
  ebox[2] = box[2] * num_cells[2];
  ebox[5] = box[5] * num_cells[2];
  ebox[8] = box[8] * num_cells[2];

  get_inverse(ebox);

  // printf("===ebox[0-8]  %f %f %f %f %f %f %f %f %f  ===\n", ebox[0], ebox[1], ebox[2], ebox[3], ebox[4], ebox[5], ebox[6], ebox[7], ebox[8]);
  // printf("===ebox[9-17] %f %f %f %f %f %f %f %f %f  ===\n", ebox[9], ebox[10], ebox[11], ebox[12], ebox[13], ebox[14], ebox[15], ebox[16], ebox[17]);

}

void applyMicOne(double& x12)
{
  while (x12 < -0.5)
    x12 += 1.0;
  while (x12 > +0.5)
    x12 -= 1.0;
}

void apply_mic_small_box(const double* ebox, double& x12, double& y12, double& z12)
{
  double sx12 = ebox[9] * x12 + ebox[10] * y12 + ebox[11] * z12;
  double sy12 = ebox[12] * x12 + ebox[13] * y12 + ebox[14] * z12;
  double sz12 = ebox[15] * x12 + ebox[16] * y12 + ebox[17] * z12;
  applyMicOne(sx12);
  applyMicOne(sy12);
  applyMicOne(sz12);
  x12 = ebox[0] * sx12 + ebox[1] * sy12 + ebox[2] * sz12;
  y12 = ebox[3] * sx12 + ebox[4] * sy12 + ebox[5] * sz12;
  z12 = ebox[6] * sx12 + ebox[7] * sy12 + ebox[8] * sz12;
}

void find_neighbor(
  const double rc_radial,
  const double rc_angular,
  const int N,
  const int MN,
  const std::vector<double>& box,
  const std::vector<double>& position,
  int* num_cells,
  double* ebox,
  std::vector<int>& g_NN_radial,
  std::vector<int>& g_NL_radial,
  std::vector<int>& g_NN_angular,
  std::vector<int>& g_NL_angular,
  std::vector<double>& r12)
{
  get_expanded_box(rc_radial, box.data(), num_cells, ebox);

  const int size_x12 = N * MN;
  const double* g_x = position.data();
  const double* g_y = position.data() + N;
  const double* g_z = position.data() + N * 2;
  double* g_x12_radial = r12.data();
  double* g_y12_radial = r12.data() + size_x12;
  double* g_z12_radial = r12.data() + size_x12 * 2;
  double* g_x12_angular = r12.data() + size_x12 * 3;
  double* g_y12_angular = r12.data() + size_x12 * 4;
  double* g_z12_angular = r12.data() + size_x12 * 5;

#if defined(_OPENMP)
#pragma omp parallel for
#endif
  for (int n1 = 0; n1 < N; ++n1) {
    double x1 = g_x[n1];
    double y1 = g_y[n1];
    double z1 = g_z[n1];
    int count_radial = 0;
    int count_angular = 0;
    for (int n2 = 0; n2 < N; ++n2) {
      for (int ia = 0; ia < num_cells[0]; ++ia) {
        for (int ib = 0; ib < num_cells[1]; ++ib) {
          for (int ic = 0; ic < num_cells[2]; ++ic) {
            if (ia == 0 && ib == 0 && ic == 0 && n1 == n2) {
              continue; // exclude self
            }
            double delta[3];
            delta[0] = box[0] * ia + box[1] * ib + box[2] * ic;
            delta[1] = box[3] * ia + box[4] * ib + box[5] * ic;
            delta[2] = box[6] * ia + box[7] * ib + box[8] * ic;

            double x12 = g_x[n2] + delta[0] - x1;
            double y12 = g_y[n2] + delta[1] - y1;
            double z12 = g_z[n2] + delta[2] - z1;

            apply_mic_small_box(ebox, x12, y12, z12);

            double distance_square = x12 * x12 + y12 * y12 + z12 * z12;
            if (distance_square < rc_radial * rc_radial) {
              // if (n1 == 0 or n1 == 10) {
              //   printf("radial n1 = %d, n2 = %d, r12 = %f %f\n", n1, n2, distance_square, sqrt(distance_square));
              // }
              g_NL_radial[count_radial * N + n1] = n2;
              g_x12_radial[count_radial * N + n1] = x12;
              g_y12_radial[count_radial * N + n1] = y12;
              g_z12_radial[count_radial * N + n1] = z12;
              count_radial++;
            }
            if (distance_square < rc_angular * rc_angular) {
              // if (n1 == 0 or n1 == 10) {
              //   printf("angular n1 = %d, n2 = %d, r12 = %f %f\n", n1, n2, distance_square, sqrt(distance_square));
              // }
              g_NL_angular[count_angular * N + n1] = n2;
              g_x12_angular[count_angular * N + n1] = x12;
              g_y12_angular[count_angular * N + n1] = y12;
              g_z12_angular[count_angular * N + n1] = z12;
              count_angular++;
            }
          }
        }
      }
    }

    g_NN_radial[n1] = count_radial;
    g_NN_angular[n1] = count_angular;
  }
  // std::abort();
}

void find_neighbor_with_atomtype(
  const double rc_radial,
  const double rc_angular,
  const int N,
  const int MN,
  const std::vector<int>& atom_type_map,
  const std::vector<double>& box,
  const std::vector<double>& position,
  int* num_cells,
  double* ebox,
  std::vector<int>& g_NN_radial,
  std::vector<int>& g_NL_radial,
  std::vector<int>& g_NLT_radial,
  std::vector<int>& g_NN_angular,
  std::vector<int>& g_NL_angular,
  std::vector<int>& g_NLT_angular,
  // std::vector<double>& r12,
  std::vector<double>& r12_radial,
  std::vector<double>& r12_angular,
  bool do_inference = false
  )
{
  get_expanded_box(rc_radial, box.data(), num_cells, ebox);

  const double* g_x = position.data();
  const double* g_y = position.data() + N;
  const double* g_z = position.data() + N * 2;

  double* g_r12_radial = r12_radial.data();
  double* g_x12_radial = r12_radial.data();
  double* g_y12_radial = r12_radial.data();
  double* g_z12_radial = r12_radial.data();

  double* g_r12_angular= r12_angular.data();
  double* g_x12_angular= r12_angular.data();
  double* g_y12_angular= r12_angular.data();
  double* g_z12_angular= r12_angular.data();

#if defined(_OPENMP)
#pragma omp parallel for
#endif
  for (int n1 = 0; n1 < N; ++n1) {
    //ct position
    // double x1 = g_x[n1];
    // double y1 = g_y[n1];
    // double z1 = g_z[n1];

    if (atom_type_map[n1] == -1) continue;

    // fraction postion
    double x1 = g_x[n1] * box[0] + g_y[n1] * box[1] + g_z[n1] * box[2];
    double y1 = g_x[n1] * box[3] + g_y[n1] * box[4] + g_z[n1] * box[5];
    double z1 = g_x[n1] * box[6] + g_y[n1] * box[7] + g_z[n1] * box[8];

    int count_radial = 0;
    int count_angular = 0;
    for (int n2 = 0; n2 < N; ++n2) {
      if (atom_type_map[n2] == -1) continue;
      for (int ia = 0; ia < num_cells[0]; ++ia) {
        for (int ib = 0; ib < num_cells[1]; ++ib) {
          for (int ic = 0; ic < num_cells[2]; ++ic) {
            if (ia == 0 && ib == 0 && ic == 0 && n1 == n2) {
              continue; // exclude self
            }
            double delta[3];
            delta[0] = box[0] * ia + box[1] * ib + box[2] * ic;
            delta[1] = box[3] * ia + box[4] * ib + box[5] * ic;
            delta[2] = box[6] * ia + box[7] * ib + box[8] * ic;

            //ct position
            // double x12 = g_x[n2] + delta[0] - x1;
            // double y12 = g_y[n2] + delta[1] - y1;
            // double z12 = g_z[n2] + delta[2] - z1;
            
            // fraction postion
            double x12 = g_x[n2] * box[0] + g_y[n2] * box[1] + g_z[n2] * box[2] + delta[0] - x1;
            double y12 = g_x[n2] * box[3] + g_y[n2] * box[4] + g_z[n2] * box[5] + delta[1] - y1;
            double z12 = g_x[n2] * box[6] + g_y[n2] * box[7] + g_z[n2] * box[8] + delta[2] - z1;

            apply_mic_small_box(ebox, x12, y12, z12);
            double distance_square = x12 * x12 + y12 * y12 + z12 * z12;
            if (do_inference) {
              if (distance_square < rc_radial * rc_radial) {
                g_NL_radial[ n1*MN   +   count_radial  ] = n2;
                g_r12_radial[n1*MN*4 + 4*count_radial  ] = sqrt(distance_square);
                g_x12_radial[n1*MN*4 + 4*count_radial+1] = x12;
                g_y12_radial[n1*MN*4 + 4*count_radial+2] = y12;
                g_z12_radial[n1*MN*4 + 4*count_radial+3] = z12;
                count_radial++;
              }
              if (distance_square < rc_angular * rc_angular) {
                g_NL_angular[ n1*MN   +   count_angular  ] = n2;
                g_r12_angular[n1*MN*4 + 4*count_angular  ] = sqrt(distance_square);
                g_x12_angular[n1*MN*4 + 4*count_angular+1] = x12;
                g_y12_angular[n1*MN*4 + 4*count_angular+2] = y12;
                g_z12_angular[n1*MN*4 + 4*count_angular+3] = z12;
                count_angular++;
              }
            } else {// for pwmlff nep training
              if (distance_square < rc_radial * rc_radial) {
                g_NLT_radial[n1*MN   +   count_radial  ] = atom_type_map[n2];
                g_NL_radial[ n1*MN   +   count_radial  ] = n2+1;
                g_r12_radial[n1*MN*4 + 4*count_radial  ] = sqrt(distance_square);
                g_x12_radial[n1*MN*4 + 4*count_radial+1] = x12;
                g_y12_radial[n1*MN*4 + 4*count_radial+2] = y12;
                g_z12_radial[n1*MN*4 + 4*count_radial+3] = z12;
                count_radial++;
              }
              if (distance_square < rc_angular * rc_angular) {
                g_NLT_angular[n1*MN   +   count_angular  ] = atom_type_map[n2];
                g_NL_angular[ n1*MN   +   count_angular  ] = n2+1;
                g_r12_angular[n1*MN*4 + 4*count_angular  ] = sqrt(distance_square);
                g_x12_angular[n1*MN*4 + 4*count_angular+1] = x12;
                g_y12_angular[n1*MN*4 + 4*count_angular+2] = y12;
                g_z12_angular[n1*MN*4 + 4*count_angular+3] = z12;
                count_angular++;
              }
            }
          }
        }
      }
    }
    g_NN_radial[n1] = count_radial;
    g_NN_angular[n1] = count_angular;
  }
}

std::vector<std::string> get_tokens(std::ifstream& input)
{
  std::string line;
  std::getline(input, line);
  std::istringstream iss(line);
  std::vector<std::string> tokens{
    std::istream_iterator<std::string>{iss}, std::istream_iterator<std::string>{}};
  return tokens;
}

void print_tokens(const std::vector<std::string>& tokens)
{
  std::cout << "Line:";
  for (const auto& token : tokens) {
    std::cout << " " << token;
  }
  std::cout << std::endl;
}

int get_int_from_token(const std::string& token, const char* filename, const int line)
{
  int value = 0;
  try {
    value = std::stoi(token);
  } catch (const std::exception& e) {
    std::cout << "Standard exception:\n";
    std::cout << "    File:          " << filename << std::endl;
    std::cout << "    Line:          " << line << std::endl;
    std::cout << "    Error message: " << e.what() << std::endl;
    exit(1);
  }
  return value;
}

double get_double_from_token(const std::string& token, const char* filename, const int line)
{
  double value = 0;
  try {
    value = std::stod(token);
  } catch (const std::exception& e) {
    std::cout << "Standard exception:\n";
    std::cout << "    File:          " << filename << std::endl;
    std::cout << "    Line:          " << line << std::endl;
    std::cout << "    Error message: " << e.what() << std::endl;
    exit(1);
  }
  return value;
}
} // namespace

NEP_CPU::NEP_CPU() {

}


void NEP_CPU::init_from_file(const std::string& potential_filename, const bool is_rank_0)
{
  model_loaded = false;
  paramb = ParaMB{};
  annmb = ANN{};
  zbl = ZBL{};
  int neplinenums = countNonEmptyLines(potential_filename);

  std::ifstream input(potential_filename);
  if (!input.is_open()) {
    std::cout << "Failed to open " << potential_filename << std::endl;
    exit(1);
  }

  // nep 1 C
  std::vector<std::string> tokens = get_tokens(input);
  element_atomic_number_list = nep_inference::parse_elements(tokens);
  if (tokens[0] == "nep") {
    paramb.model_type = 0;
    paramb.version = 2;
    zbl.enabled = false;
  } else if (tokens[0] == "nep_zbl") {
    paramb.model_type = 0;
    paramb.version = 2;
    zbl.enabled = true;
  } else if (tokens[0] == "nep_dipole") {
    paramb.model_type = 1;
    paramb.version = 2;
    zbl.enabled = false;
  } else if (tokens[0] == "nep_polarizability") {
    paramb.model_type = 2;
    paramb.version = 2;
    zbl.enabled = false;
  } else if (tokens[0] == "nep3") {
    paramb.model_type = 0;
    paramb.version = 3;
    zbl.enabled = false;
  } else if (tokens[0] == "nep3_zbl") {
    paramb.model_type = 0;
    paramb.version = 3;
    zbl.enabled = true;
  } else if (tokens[0] == "nep3_dipole") {
    paramb.model_type = 1;
    paramb.version = 3;
    zbl.enabled = false;
  } else if (tokens[0] == "nep3_polarizability") {
    paramb.model_type = 2;
    paramb.version = 3;
    zbl.enabled = false;
  } else if (tokens[0] == "nep4") {
    paramb.model_type = 0;
    paramb.version = 4;
    zbl.enabled = false;
  } else if (tokens[0] == "nep4_zbl") {
    paramb.model_type = 0;
    paramb.version = 4;
    zbl.enabled = true;
  } else if (tokens[0] == "nep4_charge2") {
    paramb.model_type = 0;
    paramb.charge_mode = 2;
    paramb.version = 4;
    zbl.enabled = false;
  } else if (tokens[0] == "nep4_zbl_charge2") {
    paramb.model_type = 0;
    paramb.charge_mode = 2;
    paramb.version = 4;
    zbl.enabled = true;
  } else if (tokens[0] == "nep5_charge2") {
    paramb.model_type = 0;
    paramb.charge_mode = 2;
    paramb.version = 5;
    zbl.enabled = false;
  } else if (tokens[0] == "nep5_zbl_charge2") {
    paramb.model_type = 0;
    paramb.charge_mode = 2;
    paramb.version = 5;
    zbl.enabled = true;
  } else if (tokens[0] == "nep4_dipole") {
    paramb.model_type = 1;
    paramb.version = 4;
    zbl.enabled = false;
  } else if (tokens[0] == "nep4_polarizability") {
    paramb.model_type = 2;
    paramb.version = 4;
    zbl.enabled = false;
  } else if (tokens[0] == "nep5") {
    paramb.model_type = 0;
    paramb.version = 5;
    zbl.enabled = false;
  } else if (tokens[0] == "nep5_zbl") {
    paramb.model_type = 0;
    paramb.version = 5;
    zbl.enabled = true;
  }

  paramb.num_types = static_cast<int>(element_atomic_number_list.size());
  element_list.resize(paramb.num_types);
  element_atomic_number_list.resize(paramb.num_types);
  for (int n = 0; n < paramb.num_types; ++n) {
    element_list[n] = tokens[2 + n];
    const int atomic_number = element_atomic_number_list[n];
    zbl.atomic_numbers[n] = atomic_number;
  }

  // zbl 1.6 3.2 0.7  inner outer factor, factor is optional
  if (zbl.enabled) {
    tokens = get_tokens(input);
    if (tokens.size() != 3 && tokens.size() != 4) {
      std::cout << "This line should be zbl rc_inner rc_outer [zbl_factor]." << std::endl;
      exit(1);
    }
    zbl.rc_inner = get_double_from_token(tokens[1], __FILE__, __LINE__);
    zbl.rc_outer = get_double_from_token(tokens[2], __FILE__, __LINE__);
    if (zbl.rc_inner == 0 && zbl.rc_outer == 0) {
      nep_inference::validate_flexible_zbl(paramb.num_types);
      zbl.flexibled = true;
      // printf("    has the flexible ZBL potential\n");
    } else {
      if (tokens.size() == 4) {
        paramb.typewise_cutoff_zbl_factor = get_double_from_token(tokens[3], __FILE__, __LINE__);
        paramb.use_typewise_cutoff_zbl = true;
        // printf("    has the universal ZBL with typewise cutoff with a factor of %g.\n", \
          paramb.typewise_cutoff_zbl_factor);
      }
    }
  }

  // cutoff 4.2 3.7 80 47
  tokens = get_tokens(input);
  if (tokens.size() != 3 && tokens.size() != 5) {
    print_tokens(tokens);
    std::cout << "This line should be cutoff rc_radial rc_angular [MN_radial] [MN_angular].\n";
    exit(1);
  }
  paramb.rc_radial = get_double_from_token(tokens[1], __FILE__, __LINE__);
  paramb.rc_angular = get_double_from_token(tokens[2], __FILE__, __LINE__);
  if (paramb.charge_mode == 2) {
    charge_para.alpha = PI / paramb.rc_radial;
    charge_para.alpha_factor = 0.25 / (charge_para.alpha * charge_para.alpha);
  }

  // n_max 10 8
  tokens = get_tokens(input);
  if (tokens.size() != 3) {
    print_tokens(tokens);
    std::cout << "This line should be n_max n_max_radial n_max_angular." << std::endl;
    exit(1);
  }
  paramb.n_max_radial = get_int_from_token(tokens[1], __FILE__, __LINE__);
  paramb.n_max_angular = get_int_from_token(tokens[2], __FILE__, __LINE__);

  // basis_size 10 8
  if (paramb.version >= 3) {
    tokens = get_tokens(input);
    if (tokens.size() != 3) {
      print_tokens(tokens);
      std::cout << "This line should be basis_size basis_size_radial basis_size_angular."
                << std::endl;
      exit(1);
    }
    paramb.basis_size_radial = get_int_from_token(tokens[1], __FILE__, __LINE__);
    paramb.basis_size_angular = get_int_from_token(tokens[2], __FILE__, __LINE__);
  }

  // l_max
  tokens = get_tokens(input);
  if (paramb.version == 2) {
    if (tokens.size() != 2) {
      print_tokens(tokens);
      std::cout << "This line should be l_max l_max_3body." << std::endl;
      exit(1);
    }
  } else {
    if (tokens.size() != 4) {
      print_tokens(tokens);
      std::cout << "This line should be l_max l_max_3body l_max_4body l_max_5body." << std::endl;
      exit(1);
    }
  }

  paramb.L_max = get_int_from_token(tokens[1], __FILE__, __LINE__);
  paramb.num_L = paramb.L_max;

  if (paramb.version >= 3) {
    int L_max_4body = get_int_from_token(tokens[2], __FILE__, __LINE__);
    int L_max_5body = get_int_from_token(tokens[3], __FILE__, __LINE__);
    if (L_max_4body == 2) {
      paramb.num_L += 1;
    }
    if (L_max_5body == 1) {
      paramb.num_L += 1;
    }
  }

  paramb.dim_angular = (paramb.n_max_angular + 1) * paramb.num_L;

  // ANN
  tokens = get_tokens(input);
  if (tokens.size() != 3) {
    print_tokens(tokens);
    std::cout << "This line should be ANN num_neurons 0." << std::endl;
    exit(1);
  }
  annmb.num_neurons1 = get_int_from_token(tokens[1], __FILE__, __LINE__);
  annmb.dim = (paramb.n_max_radial + 1) + paramb.dim_angular;

  // calculated parameters:
  paramb.rcinv_radial = 1.0f / paramb.rc_radial;
  paramb.rcinv_angular = 1.0f / paramb.rc_angular;
  paramb.num_types_sq = paramb.num_types * paramb.num_types;

  annmb.num_c2   = paramb.num_types_sq * (paramb.n_max_radial + 1) * (paramb.basis_size_radial + 1);
  annmb.num_c3   = paramb.num_types_sq * (paramb.n_max_angular + 1) * (paramb.basis_size_angular + 1);
  
  if (paramb.charge_mode == 2) {
    annmb.num_para_ann = (annmb.dim + 3) * annmb.num_neurons1 * paramb.num_types + 2;
    if (paramb.version == 5) {
      annmb.num_para_ann += paramb.num_types;
    }
  } else if (paramb.version == 3) {
    annmb.num_para_ann = (annmb.dim + 2) * annmb.num_neurons1 + 1;
  } else if (paramb.version == 4) {
    annmb.num_para_ann = (annmb.dim + 2) * annmb.num_neurons1 * paramb.num_types;
  } else{
    annmb.num_para_ann = ((annmb.dim + 2) * annmb.num_neurons1 + 1) * paramb.num_types + 1;
  }
  int tmp = 0;
  tmp = annmb.num_para_ann + annmb.num_c2 + annmb.num_c3 + 6 + annmb.dim;

  int num_type_zbl = 0;
  if (zbl.enabled && zbl.flexibled) {
    num_type_zbl = (paramb.num_types * (paramb.num_types + 1)) / 2;
    neplinenums -= (1 + 10*num_type_zbl);// zbl 0 0; fixed zbl
  } else if (zbl.enabled) {
    neplinenums  -= 1; // zbl a b
  }

  bool is_gpumd_nep = false;
  if (paramb.charge_mode == 2) {
    is_gpumd_nep = (paramb.version == 4);
  } else if (paramb.num_types == 1) {
    is_gpumd_nep = false;
  } else if (paramb.version == 4) {
    if (neplinenums  == (tmp + 1)) {
      is_gpumd_nep = true;
      if (is_rank_0) {
        printf("    the input nep4 potential file is from GPUMD.\n");
      }
    } else if (neplinenums  == (tmp + paramb.num_types)) {
      if(is_rank_0) {
        printf("    the input nep4 potential file is from MatPL.\n");
      }
    } else {
    printf("    parameter parsing error, the number of nep parameters [MatPL %d, GPUMD %d] does not match the text lines %d.\n", tmp, (tmp-paramb.num_types+1), neplinenums);
    exit(1);
    }
  }

  if (paramb.charge_mode == 2) {
    annmb.num_para = annmb.num_para_ann;
  } else if (paramb.version == 4 ){
    annmb.num_para = annmb.num_para_ann + paramb.num_types;
  } else {
    annmb.num_para = annmb.num_para_ann;
  }
  
  // annmb.num_para = (annmb.dim + 2) * annmb.num_neurons1 * (paramb.version == 4 ? paramb.num_types : 1) + (paramb.version == 4 ? paramb.num_types : 1);
  
  if (paramb.model_type == 2) {
    annmb.num_para *= 2;
  }
  int num_para_descriptor =annmb.num_c2 + annmb.num_c3;
  annmb.num_para += num_para_descriptor;
  paramb.num_c_radial =
    paramb.num_types_sq * (paramb.n_max_radial + 1) * (paramb.basis_size_radial + 1);

  if (paramb.version == 2) {
    paramb.num_c_radial =
      (paramb.num_types == 1) ? 0 : paramb.num_types_sq * (paramb.n_max_radial + 1);
  }

  // NN and descriptor parameters
  parameters.resize(annmb.num_para);
  for (int n = 0; n < annmb.num_para; ++n) {
    if (is_gpumd_nep == true && paramb.charge_mode != 2 && (n >= annmb.num_para_ann + 1) && (n < annmb.num_para_ann + paramb.num_types)) {
      parameters[n] = parameters[annmb.num_para_ann];
      if (is_rank_0) {
        printf("    Copy the last bias parameters[%d]=%f to parameters[%d]=%f \n", annmb.num_para_ann, parameters[annmb.num_para_ann], n, parameters[n]);
      }    
    } else {
      tokens = get_tokens(input);
      parameters[n] = get_double_from_token(tokens[0], __FILE__, __LINE__);
    }
  }
  update_potential(parameters.data(), annmb);
  for (int d = 0; d < annmb.dim; ++d) {
    tokens = get_tokens(input);
    paramb.q_scaler[d] = get_double_from_token(tokens[0], __FILE__, __LINE__);
  }

  // flexible zbl potential parameters if (zbl.flexibled)
  if (zbl.flexibled) {
    // int num_type_zbl = (paramb.num_types * (paramb.num_types + 1)) / 2;
    for (int d = 0; d < 10 * num_type_zbl; ++d) {
      tokens = get_tokens(input);
      zbl.para[d] = get_double_from_token(tokens[0], __FILE__, __LINE__);
    }
    zbl.num_types = paramb.num_types;
  }
  input.close();

  // only report for rank_0
  if (is_rank_0) {

    if (paramb.num_types == 1) {
      std::cout << "    Use the NEP" << paramb.version << " potential with " << paramb.num_types
                << " atom type.\n";
    } else { 
      std::cout << "    Use the NEP" << paramb.version << " potential with " << paramb.num_types
                << " atom types.\n";
    }

    for (int n = 0; n < paramb.num_types; ++n) {
      std::cout << "    type " << n << "( " << element_list[n]
                << " with Z = " << zbl.atomic_numbers[n] << ").\n";
    }

    if (zbl.enabled) {
      if (zbl.flexibled) {
        std::cout << "    has flexible ZBL.\n";
      } else {
        if (tokens.size() == 4) {
          printf("    has the universal ZBL with typewise cutoff with a factor of %g.\n", paramb.typewise_cutoff_zbl_factor);
        } else {
          printf("    has the universal ZBL with inner cutoff %g A and outer cutoff %g A.\n", zbl.rc_inner, zbl.rc_outer);
        }
      }
    }
    std::cout << "    radial cutoff = " << paramb.rc_radial << " A.\n";
    std::cout << "    angular cutoff = " << paramb.rc_angular << " A.\n";
    std::cout << "    n_max_radial = " << paramb.n_max_radial << ".\n";
    std::cout << "    n_max_angular = " << paramb.n_max_angular << ".\n";
    if (paramb.version >= 3) {
      std::cout << "    basis_size_radial = " << paramb.basis_size_radial << ".\n";
      std::cout << "    basis_size_angular = " << paramb.basis_size_angular << ".\n";
    }
    std::cout << "    l_max_3body = " << paramb.L_max << ".\n";
    std::cout << "    l_max_4body = " << (paramb.num_L >= 5 ? 2 : 0) << ".\n";
    std::cout << "    l_max_5body = " << (paramb.num_L >= 6 ? 1 : 0) << ".\n";
    std::cout << "    ANN = " << annmb.dim << "-" << annmb.num_neurons1 << "-1.\n";
    if (is_gpumd_nep) {
      std::cout << "    the input nep potential file is from GPUMD.\n";
      if (paramb.charge_mode == 2) {
        std::cout << "    number of neural network parameters = "
                  << annmb.num_para - num_para_descriptor << ".\n";
        std::cout << "    number of descriptor parameters = " << num_para_descriptor << ".\n";
        std::cout << "    total number of parameters = " << annmb.num_para << ".\n";
      } else {
        std::cout << "    number of neural network parameters = "
                  << annmb.num_para - num_para_descriptor - paramb.num_types + 1 << ".\n";
        std::cout << "    number of descriptor parameters = " << num_para_descriptor << ".\n";
        std::cout << "    total number of parameters = " << annmb.num_para - paramb.num_types + 1 << ".\n";
      }

    } else {
      std::cout << "    the input nep potential file is from MatPL.\n";
    
      std::cout << "    number of neural network parameters = "
                << annmb.num_para - num_para_descriptor << ".\n";
      std::cout << "    number of descriptor parameters = " << num_para_descriptor << ".\n";
      std::cout << "    total number of parameters = " << annmb.num_para << ".\n";
    }
  }
  model_loaded = true;
}

NEP_CPU::NEP_CPU(const std::string& potential_filename) { init_from_file(potential_filename, true); }


void NEP_CPU::update_potential(double* parameters, ANN& ann)
{
  double* pointer = parameters;
  if (paramb.charge_mode == 2) {
    const int num_outputs = 2;
    for (int t = 0; t < paramb.num_types; ++t) {
      ann.w0[t] = pointer;
      pointer += ann.num_neurons1 * ann.dim;
      ann.b0[t] = pointer;
      pointer += ann.num_neurons1;
      ann.w1[t] = pointer;
      pointer += ann.num_neurons1 * num_outputs;
      if (paramb.version == 5) {
        pointer += 1;
      }
    }
    ann.sqrt_epsilon_inf = pointer;
    pointer += 1;
    ann.b1 = pointer;
    pointer += 1;
    ann.c = pointer;
    return;
  }
  for (int t = 0; t < paramb.num_types; ++t) {
    if (t > 0 && paramb.version == 3) { // Use the same set of NN parameters for NEP2 and NEP_CPU
      pointer -= (ann.dim + 2) * ann.num_neurons1;
    }
    ann.w0[t] = pointer;
    pointer += ann.num_neurons1 * ann.dim;
    ann.b0[t] = pointer;
    pointer += ann.num_neurons1;
    ann.w1[t] = pointer;
    pointer += ann.num_neurons1;
    if (paramb.version == 5) {
      pointer += 1; // one extra bias for NEP5 stored in ann.w1[t]
    }
  }

  ann.b1 = pointer;
  pointer += (paramb.version == 4 ? paramb.num_types : 1); // the nep4 bias toghers
  // for (int ii = 0; ii < paramb.num_types; ++ii){
  //   std::cout << "last bias " << ann.b1[ii]<< " type " << ii << std::endl;
  // }
  if (paramb.model_type == 2) {
    for (int t = 0; t < paramb.num_types; ++t) {
      if (t > 0 && paramb.version != 4) { // Use the same set of NN parameters for NEP2 and NEP_CPU
        pointer -= (ann.dim + 2) * ann.num_neurons1;
      }
      ann.w0_pol[t] = pointer;
      pointer += ann.num_neurons1 * ann.dim;
      ann.b0_pol[t] = pointer;
      pointer += ann.num_neurons1;
      ann.w1_pol[t] = pointer;
      pointer += ann.num_neurons1;
    }
    ann.b1_pol = pointer;
    pointer += 1;
  }

  ann.c = pointer;
}

void NEP_CPU::allocate_memory(const int N)
{
  if (num_atoms < N) {
    NN_radial.resize(N);
    NL_radial.resize(N * MN);
    NN_angular.resize(N);
    NL_angular.resize(N * MN);
    r12.resize(N * MN * 6);
    Fp.resize(N * annmb.dim);
    if (paramb.charge_mode == 2) {
      charge.resize(N);
      charge_derivative.resize(N * annmb.dim);
      bec.resize(N * 9);
      D_real.resize(N);
      num_kpoints.resize(1);
      kx.resize(charge_para.num_kpoints_max);
      ky.resize(charge_para.num_kpoints_max);
      kz.resize(charge_para.num_kpoints_max);
      G.resize(charge_para.num_kpoints_max);
      S_real.resize(charge_para.num_kpoints_max);
      S_imag.resize(charge_para.num_kpoints_max);
    }
    sum_fxyz.resize(N * (paramb.n_max_angular + 1) * NUM_OF_ABC);
    num_atoms = N;
  }
}

void NEP_CPU::compute(
  const std::vector<int>& type,
  const std::vector<double>& box,
  const std::vector<double>& position,
  std::vector<double>& potential,
  std::vector<double>& force,
  std::vector<double>& virial,
  std::vector<double>& total_virial,
  const std::string& kspace_method,
  double total_charge)
{
  nep_inference::validate_sizes(type.size(), box.size(), position.size());
  nep_inference::validate_types(type.data(), type.size(), element_atomic_number_list,
      model_loaded, zbl.enabled && paramb.use_typewise_cutoff_zbl);
  if (paramb.model_type != 0) {
    std::cout << "Cannot compute potential using a non-potential NEP model.\n";
    exit(1);
  }

  const int N = type.size();
  const int size_x12 = N * MN;

  if (N * 3 != position.size()) {
    std::cout << "Type and position sizes are inconsistent.\n";
    exit(1);
  }
  if (N != potential.size()) {
    std::cout << "Type and potential sizes are inconsistent.\n";
    exit(1);
  }
  if (N * 3 != force.size()) {
    std::cout << "Type and force sizes are inconsistent.\n";
    exit(1);
  }

  allocate_memory(N);
  if (paramb.charge_mode == 2) {
    charge.assign(N, 0.0);
    charge_derivative.assign(N * annmb.dim, 0.0);
    bec.assign(N * 9, 0.0);
    D_real.assign(N, 0.0);
  }

  for (int n = 0; n < potential.size(); ++n) {
    potential[n] = 0.0;
  }
  for (int n = 0; n < force.size(); ++n) {
    force[n] = 0.0;
  }
  for (int n = 0; n < virial.size(); ++n) {
    virial[n] = 0.0;
  }
  for (int n = 0; n < 9; ++n) {
    total_virial[n] = 0.0;
  }

  // for (int i = 0; i < N; i++) {
  //   printf("p[%d]= %f %f %f \n",i, position[i], position[N+i], position[2*N+i]);
  // }

  find_neighbor(
    paramb.rc_radial, paramb.rc_angular, N, MN, box, position, num_cells, ebox, 
    NN_radial, NL_radial, NN_angular, NL_angular, 
    r12);
  // for (int i=0; i < N; i++){
  //   printf("atom %d neighbors %d, neighbor list is: \n", i, NN_radial[i]);
  //   for (int j=0; j < NN_radial[i]; j++){
  //     printf("%d ",NL_radial[j * N + i]);
  //   }
  //   printf("\n");
  // }
  find_descriptor(
    true, false, false, false, paramb, annmb, N, NN_radial.data(), NL_radial.data(),
    NN_angular.data(), NL_angular.data(), type.data(), r12.data(), r12.data() + size_x12,
    r12.data() + size_x12 * 2, r12.data() + size_x12 * 3, r12.data() + size_x12 * 4,
    r12.data() + size_x12 * 5,
    Fp.data(), sum_fxyz.data(), potential.data(),
    paramb.charge_mode == 2 ? charge.data() : nullptr,
    paramb.charge_mode == 2 ? charge_derivative.data() : nullptr,
    nullptr, nullptr, nullptr);

  if (paramb.charge_mode == 2) {
    std::fill(bec.begin(), bec.begin() + N * 9, 0.0);
    std::fill(D_real.begin(), D_real.begin() + N, 0.0);
    std::vector<double> charge_shifted(charge.begin(), charge.begin() + N);
    const double screened_total_charge = total_charge / annmb.sqrt_epsilon_inf[0];
    shift_total_charge(N, charge_shifted, screened_total_charge);
    charge = charge_shifted;
    find_bec_diagonal(N, charge_shifted, bec);
    find_bec_radial(
      paramb, annmb, N, NN_radial.data(), NL_radial.data(), type.data(),
      r12.data(), r12.data() + size_x12, r12.data() + size_x12 * 2,
      charge_derivative.data(), bec);
    find_bec_angular(
      paramb, annmb, N, NN_angular.data(), NL_angular.data(), type.data(),
      r12.data() + size_x12 * 3, r12.data() + size_x12 * 4, r12.data() + size_x12 * 5,
      charge_derivative.data(), sum_fxyz.data(), bec);
    scale_bec(N, annmb.sqrt_epsilon_inf[0], bec);
    if (kspace_method == "pppm") {
      pppm_find_force_charge_cpu(
        N, charge_para.alpha, charge_para.alpha_factor, box, charge_shifted, position,
        D_real, force, virial, total_virial, potential);
    } else if (kspace_method == "ewald") {
      find_k_and_G(
        charge_para.num_kpoints_max, charge_para.alpha, charge_para.alpha_factor,
        box, num_kpoints, kx, ky, kz, G);
      find_structure_factor(N, num_kpoints[0], charge_shifted, position, kx, ky, kz, S_real, S_imag);
      find_force_charge_reciprocal_space(
        N, num_kpoints[0], charge_para.alpha_factor, charge_shifted, position, kx, ky, kz, G,
        S_real, S_imag, D_real, force, virial, total_virial, potential);
    } else {
      std::cout << "Unsupported CPU NEP kspace method: " << kspace_method << std::endl;
      exit(1);
    }
    zero_mean_D_real(N, D_real);
  } else {
    charge.clear();
    bec.clear();
  }

  find_force_radial(
    false, paramb, annmb, N, NN_radial.data(), NL_radial.data(), type.data(), r12.data(),
    r12.data() + size_x12, r12.data() + size_x12 * 2, Fp.data(),
    paramb.charge_mode == 2 ? charge_derivative.data() : nullptr,
    paramb.charge_mode == 2 ? D_real.data() : nullptr,
    force.data(), force.data() + N, force.data() + N * 2, nullptr, total_virial.data());
  // for (int ii = 0; ii < N; ii++) {
  // printf("radial force f[%d]=%f %f %f\n", ii, force[ii], force[ii + N], force[ii + N * 2]);
  // }
  // for (int ii = 0; ii < N; ii++) {
  //   printf("radial force[%d]=%f %f %f\n", ii, force[ii], force[ii+ N], force[ii+ N*2]);
  // }

  find_force_angular(
    false, paramb, annmb, N, NN_angular.data(), NL_angular.data(), type.data(),
    r12.data() + size_x12 * 3, r12.data() + size_x12 * 4, r12.data() + size_x12 * 5, Fp.data(),
    paramb.charge_mode == 2 ? charge_derivative.data() : nullptr,
    paramb.charge_mode == 2 ? D_real.data() : nullptr,
    sum_fxyz.data(),
    force.data(), force.data() + N, force.data() + N * 2, nullptr, total_virial.data());

  // for (int ii = 0; ii < N; ii++) {
  // printf("angular force f[%d]=%f %f %f\n", ii, force[ii], force[ii + N], force[ii + N * 2]);
  // }
  if (zbl.enabled) {
    find_force_ZBL(
      paramb, N, zbl, NN_angular.data(), NL_angular.data(), type.data(), r12.data() + size_x12 * 3,
      r12.data() + size_x12 * 4, r12.data() + size_x12 * 5, force.data(), force.data() + N,
      force.data() + N * 2, nullptr, potential.data(), total_virial.data());
  }
  // for (int ii = 0; ii < N; ii++) {
  // printf("zbl e[%d]=%f\n", ii, potential[ii]);
  // }
  // for (int ii = 0; ii < N; ii++) {
  // printf("zbl force f[%d]=%f %f %f\n", ii, force[ii], force[ii + N], force[ii + N * 2]);
  // }
  total_virial[3] = total_virial[1]; //yx
  total_virial[6] = total_virial[2]; //zx
  total_virial[7] = total_virial[5]; //zy
}

void NEP_CPU::find_neigh(
  const double rc_radial,
  const double rc_angular,
  const int MN,
  const std::vector<int>& atom_type_map,
  const std::vector<double>& box,
  const std::vector<double>& position)
{
  int N = atom_type_map.size();
  // NN_radial.resize(N, 0);
  // NL_radial.resize(N * MN, 0);
  // NLT_radial.resize(N * MN, -1);
  // NN_angular.resize(N);
  // NL_angular.resize(N * MN, 0);
  // NLT_angular.resize(N * MN, -1);
  // // r12.resize(N * MN * 6);
  // r12_radial.resize(N * MN * 4, 0);
  // r12_angular.resize(N * MN * 4, 0);

  NN_radial.assign(N, 0);
  NL_radial.assign(N * MN, 0);
  NLT_radial.assign(N * MN, -1);
  NN_angular.assign(N, 0);
  NL_angular.assign(N * MN, 0);
  NLT_angular.assign(N * MN, -1);
  // r12.assign(N * MN * 6);
  r12_radial.assign(N * MN * 4, 0);
  r12_angular.assign(N * MN * 4, 0);
  
  find_neighbor_with_atomtype(
    rc_radial, rc_angular, N, MN, atom_type_map, box, position, num_cells, ebox, NN_radial, NL_radial, NLT_radial, NN_angular, NL_angular, NLT_angular, r12_radial, r12_angular);
}
