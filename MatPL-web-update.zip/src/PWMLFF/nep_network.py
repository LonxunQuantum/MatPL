import os
import sys
import importlib
import pathlib
import random
import glob
import re
import torch
import time
import torch.nn as nn
import torch.distributed as dist
import torch.nn.parallel
import torch.optim as optim
import torch.utils.data
import torch.utils.data.distributed
from src.feature.nep_find_neigh.findneigh import FindNeigh
import numpy as np
import pandas as pd
from src.model.nep_net import NEP
from src.utils.nep_distributed import training_device_type, training_backend
from src.model.nep_fused_fitting import prepare_fitting_jit
from src.pre_data.nep_data_loader import calculate_neighbor_num_max_min, calculate_neighbor_scaler, UniDataset, variable_length_collate_fn, variable_length_collate_fn_nolimit, calculate_batch, type_map, NepTestData
from src.pre_data.nep_lmdb_dataset import (
    DistributedAtomBatchSampler,
    DistributedFrameBatchSampler,
    LmdbEnergyStatistics,
    LmdbNatomsCache,
    NepLmdbDataset,
    parse_lmdb_batch_size,
    select_stat_indices,
)
from src.PWMLFF.nep_mods.nep_trainer import train_KF, train, valid, save_checkpoint, predict
from src.user.input_param import InputParam
from src.utils.file_operation import write_arrays_to_file, write_force_ei
from src.utils.nep_to_gpumd import extract_model
from src.aux.inference_plot import inference_plot
import concurrent.futures
import multiprocessing
from datetime import timedelta
from src.utils.debug_operation import check_cuda_memory, check_cpu_memory
from src.utils.learning_rate import (
    calculate_lr_scale,
    calculate_warmup_lr,
    is_epoch_before_restart,
    resolve_optimizer_peak_lr,
)
from src.loss.loss import adjust_lr
from src.optimizer.GKF import GKFOptimizer
from src.optimizer.LKF import LKFOptimizer

# 动态添加路径
codepath = str(pathlib.Path(__file__).parent.resolve())
sys.path.append(codepath)
sys.path.append(codepath + '/../model')
sys.path.append(codepath + '/..')
sys.path.append(codepath + '/../aux')
sys.path.append(codepath + '/../..')


def _open_nep_log(path, mode):
    return open(path, mode, encoding="utf-8")


def _require_lmdb_training_batches(
        batch_sampler, dataset_size, batch_mode, batch_value, world_size):
    """Fail before model setup when ranks cannot receive one complete batch."""
    if len(batch_sampler) > 0:
        return
    batch_description = (
        str(batch_value)
        if batch_mode == "frames"
        else "mix:{}".format(batch_value)
    )
    raise ValueError(
        "LMDB training data with {} frames cannot form a complete batch "
        "for optimizer.batch_size={} on each of {} ranks; reduce batch_size "
        "or the number of ranks".format(
            dataset_size, batch_description, world_size
        )
    )


def _calculate_lmdb_neighbor_scaler(
        dataloader,
        n_max_radial,
        basis_size_radial,
        n_max_angular,
        basis_size_angular,
        lmax_3,
        lmax_4,
        lmax_5,
        device,
        num_workers=0):
    """Return all-reduce identities when this rank has no stat frames."""
    if len(dataloader) > 0:
        return calculate_neighbor_scaler(
            dataloader,
            n_max_radial,
            basis_size_radial,
            n_max_angular,
            basis_size_angular,
            lmax_3,
            lmax_4,
            lmax_5,
            device,
            num_workers=num_workers,
        )

    angular_channels = lmax_3 + int(lmax_4 > 0) + int(lmax_5 > 0)
    descriptor_size = (
        n_max_radial + 1 + (n_max_angular + 1) * angular_channels
    )
    dtype = dataloader.dataset.dtype
    local_max = torch.full(
        (descriptor_size,), -torch.inf, dtype=dtype, device=device
    )
    local_min = torch.full(
        (descriptor_size,), torch.inf, dtype=dtype, device=device
    )
    return local_max, local_min, 0, 0, 0, 0


def _periodic_nep_checkpoint_paths(primary_path):
    directory = os.path.dirname(primary_path)
    model_name = os.path.basename(primary_path)
    pattern = os.path.join(directory, f"epoch_*_{model_name}")
    candidates = []
    for path in glob.glob(pattern):
        match = re.match(
            rf"^epoch_(\d+)_{re.escape(model_name)}$",
            os.path.basename(path))
        if match is not None:
            candidates.append((int(match.group(1)), path))
    return [path for _, path in sorted(candidates, reverse=True)]


def _load_nep_checkpoint(path, map_location):
    try:
        checkpoint = torch.load(
            path, map_location=map_location, weights_only=False)
    except Exception as exc:
        raise RuntimeError(
            f"'{path}' is not a valid PyTorch NEP checkpoint. "
            "It may be a nep.txt model or an incomplete/corrupted file."
        ) from exc
    if not isinstance(checkpoint, dict) or \
            not isinstance(checkpoint.get("state_dict"), dict):
        raise RuntimeError(
            f"'{path}' is not a valid PyTorch NEP checkpoint: "
            "missing the state_dict mapping.")
    return checkpoint


def load_nep_checkpoint_with_fallback(
        primary_path, map_location, allow_periodic_fallback=False):
    """Load a NEP checkpoint, optionally recovering from periodic snapshots."""
    try:
        return _load_nep_checkpoint(primary_path, map_location), primary_path
    except RuntimeError as primary_error:
        if not allow_periodic_fallback:
            raise
        fallback_errors = []
        for fallback_path in _periodic_nep_checkpoint_paths(primary_path):
            try:
                checkpoint = _load_nep_checkpoint(
                    fallback_path, map_location)
                print(
                    f"WARNING: Cannot load primary NEP checkpoint "
                    f"'{primary_path}'. Recovering from periodic checkpoint "
                    f"'{fallback_path}'.")
                return checkpoint, fallback_path
            except RuntimeError as fallback_error:
                fallback_errors.append(str(fallback_error))
        details = "\n".join(fallback_errors)
        if details:
            details = f" Periodic checkpoint errors:\n{details}"
        raise RuntimeError(
            f"Cannot recover NEP training from '{primary_path}' and no "
            f"valid periodic checkpoint was found.{details}"
        ) from primary_error


def restore_nep_optimizer_state(
        checkpoint, optimizer, reset_epoch,
        allow_optimizer_param_group_mismatch=False):
    """Restore moments/history while keeping the current optimizer configuration."""
    if checkpoint is None or reset_epoch:
        return False

    optimizer_state = checkpoint.get("optimizer")
    if optimizer_state is None:
        return False
    current_groups = optimizer.state_dict()["param_groups"]
    saved_groups = optimizer_state.get("param_groups", [])
    layout_mismatch = (
        [len(group.get("params", [])) for group in saved_groups]
        != [len(group["params"]) for group in current_groups]
    )
    if layout_mismatch and allow_optimizer_param_group_mismatch:
        return False
    try:
        if layout_mismatch:
            raise ValueError("checkpoint optimizer parameter groups do not match")
        # Keep saved parameter IDs for mapping moments to the new model, but use
        # current group options BEFORE load_state_dict so PyTorch also casts
        # state tensors according to the current optimizer configuration.
        state = dict(optimizer_state, param_groups=[
            dict(current, params=saved["params"])
            for current, saved in zip(current_groups, saved_groups)
        ])
        optimizer.load_state_dict(state)
    except (KeyError, TypeError, ValueError, RuntimeError) as exc:
        raise RuntimeError(
            "Failed to restore the NEP optimizer state from checkpoint"
        ) from exc
    return True


def initialize_nep_learning_rate(
        optimizer, scheduler, optimizer_param, optimizer_peak_lr,
        completed_updates, warmup_updates, lr_completed_updates=None):
    """Set the next update's LR from current settings and completed work."""
    if lr_completed_updates is None:
        lr_completed_updates = completed_updates
    if scheduler is not None:
        # The fresh scheduler already holds the JSON period and minimum LR.
        # Warmup does not advance its clock; never load checkpoint configuration.
        scheduler.step(max(0, lr_completed_updates - warmup_updates))
    if lr_completed_updates < warmup_updates:
        current_lr = calculate_warmup_lr(
            lr_completed_updates, warmup_updates,
            optimizer_param.stop_lr, optimizer_peak_lr)
    elif scheduler is not None:
        current_lr = scheduler.get_last_lr()[0]
    else:
        current_lr = adjust_lr(
            completed_updates, optimizer_peak_lr,
            optimizer_param.stop_step, optimizer_param.decay_step,
            optimizer_param.stop_lr)
    for param_group in optimizer.param_groups:
        param_group["lr"] = current_lr
    return current_lr


def build_nep_checkpoint(
        json_file, epoch, model, optimizer, scheduler,
        optimizer_updates=None, warmup_updates=None, lr_progress_epochs=None):
    """Save training state; scheduler metadata is not configuration on resume."""
    return {
        "json_file": json_file,
        "epoch": epoch,
        "state_dict": model.state_dict(),
        "optimizer": optimizer.state_dict(),
        "scheduler": scheduler.state_dict() if scheduler is not None else None,
        "optimizer_updates": optimizer_updates,
        "warmup_updates": warmup_updates,
        "lr_progress_epochs": lr_progress_epochs,
    }


def _get_image_total_charge(image, default_total_charge=0.0):
    charge = getattr(image, "charge", None)
    fragment = getattr(image, "fragment", None)
    if charge is not None:
        charge_array = np.asarray(charge, dtype=float)
        if fragment is not None and charge_array.size == getattr(image, "atom_nums", charge_array.size):
            fragment_array = np.asarray(fragment).reshape(-1)
            charge_array = charge_array.reshape(-1)
            if fragment_array.size == charge_array.size:
                valid_fragment = fragment_array >= 0
                if valid_fragment.any():
                    fragment_charge = charge_array[valid_fragment]
                    fragment_id = fragment_array[valid_fragment]
                    if np.isfinite(fragment_charge).all():
                        total_charge = 0.0
                        for frag in np.unique(fragment_id):
                            total_charge += fragment_charge[fragment_id == frag][0]
                        return float(total_charge)
                    total_charge = np.asarray(getattr(image, "total_charge", default_total_charge), dtype=float).reshape(-1)
                    if total_charge.size and np.isfinite(total_charge[0]):
                        return float(total_charge[0])
                    return float(default_total_charge)
        if charge_array.size == 1 and np.isfinite(charge_array.reshape(-1)[0]):
            return float(charge_array.reshape(-1)[0])
    total_charge = getattr(image, "total_charge", default_total_charge)
    total_charge = np.asarray(total_charge, dtype=float).reshape(-1)
    if total_charge.size and np.isfinite(total_charge[0]):
        return float(total_charge[0])
    return float(default_total_charge)


def _get_fragment_charge_rmse_and_label(image, charge_predict):
    charge_label = getattr(image, "charge", None)
    fragment = getattr(image, "fragment", None)
    atom_nums = getattr(image, "atom_nums", len(charge_predict))
    if charge_label is None or fragment is None:
        return None
    charge_label = np.asarray(charge_label, dtype=float).reshape(-1)
    fragment = np.asarray(fragment).reshape(-1)
    if charge_label.size != atom_nums or fragment.size != atom_nums:
        return None
    valid = (fragment >= 0) & np.isfinite(charge_label)
    if not valid.any():
        return None
    pred_frag_charge = []
    label_frag_charge = []
    for frag in np.unique(fragment[valid]):
        frag_mask = fragment == frag
        valid_frag_mask = frag_mask & valid
        if not valid_frag_mask.any():
            continue
        pred_frag_charge.append(np.sum(charge_predict[frag_mask]))
        label_frag_charge.append(charge_label[valid_frag_mask][0])
    if len(label_frag_charge) == 0:
        return None
    pred_frag_charge = np.asarray(pred_frag_charge)
    label_frag_charge = np.asarray(label_frag_charge)
    return np.sqrt(np.mean((pred_frag_charge - label_frag_charge) ** 2)), charge_label


def _init_nep_txt_calculator(nep_txt_path, device_type="cpu", gpu_id=0, print_info=0):
    if device_type == "cuda":
        torch.cuda.set_device(gpu_id)
        build_backend = "hip" if getattr(torch.version, "hip", None) else "cuda"
        NEP_GPU = importlib.import_module(
            "src.feature.NEP_GPU.build.{}.nep_gpu".format(build_backend)
        ).NEP
        calc_obj = NEP_GPU()
        calc_obj.init_from_file(nep_txt_path, print_info, gpu_id)
    else:
        calc_obj = FindNeigh()
        calc_obj.init_model(nep_txt_path)
    return calc_obj


def _calculate_nep_image_result(idx, image, input_atom_types, calc_obj, kspace_method="ewald"):
    atom_nums = image.atom_nums
    atom_types_struc = image.atom_types_image
    input_atom_types = np.array(input_atom_types)
    atom_types = image.atom_type
    img_max_types = len(input_atom_types)
    try:
        ntypes = len(atom_types)
    except TypeError:
        ntypes = 1

    if hasattr(image, "cartesian") and image.cartesian is False:
        image._set_cartesian()

    if ntypes > img_max_types:
        raise Exception("Error! the atom types in structure file is larger than the max atom types in model!")
    type_maps = np.array(type_map(atom_types_struc, input_atom_types)).reshape(1, -1)

    inference_result = calc_obj.inference(
        list(type_maps[0]),
        list(np.array(image.lattice).transpose(1, 0).reshape(-1)),
        np.array(image.position).transpose(1, 0).reshape(-1),
        kspace_method,
        _get_image_total_charge(image)
    )
    ei_predict, force_predict, virial_predict = inference_result[:3]
    charge_predict = inference_result[3] if len(inference_result) > 3 else []
    bec_predict = inference_result[4] if len(inference_result) > 4 else []

    ei_predict = np.array(ei_predict).reshape(atom_nums)
    etot_predict = np.sum(ei_predict)
    etot_rmse = np.abs(etot_predict - image.Ep)
    etot_atom_rmse = etot_rmse / atom_nums
    ei_rmse = np.sqrt(np.mean((ei_predict - image.atomic_energy) ** 2))
    force_predict = np.array(force_predict).reshape(3, atom_nums).transpose(1, 0)
    force_rmse = np.sqrt(np.mean((force_predict - image.force) ** 2))
    result = {
        "idx": idx,
        "etot_rmse": etot_rmse,
        "etot_atom_rmse": etot_atom_rmse,
        "ei_rmse": ei_rmse,
        "force_rmse": force_rmse,
        "etot_label": image.Ep,
        "etot_predict": etot_predict,
        "ei_label": image.atomic_energy,
        "ei_predict": ei_predict,
        "force_label": image.force,
        "force_predict": force_predict
    }
    virial_predict = np.array(virial_predict)
    if image.virial is not None:
        virial_label = image.virial.flatten()
        virial_rmse = np.sqrt(np.mean((virial_predict[[0,1,2,4,5,8]] - virial_label[[0,1,2,4,5,8]]) ** 2))
        virial_atom_rmse = virial_rmse / atom_nums
    else:
        virial_rmse = -1e6
        virial_atom_rmse = -1e6
        virial_label = np.ones_like(virial_predict) * (-1e6)
    result["virial_rmse"] = virial_rmse
    result["virial_atom_rmse"] = virial_atom_rmse
    result["virial_label"] = virial_label
    result["virial_predict"] = virial_predict

    charge_predict = np.array(charge_predict)
    if charge_predict.size:
        charge_predict = charge_predict.reshape(atom_nums)
        fragment_charge_result = _get_fragment_charge_rmse_and_label(image, charge_predict)
        if fragment_charge_result is not None:
            charge_rmse, charge_label = fragment_charge_result
        else:
            charge_label = getattr(image, "charge", None)
            if charge_label is None:
                charge_label = _get_image_total_charge(image)
            charge_label = np.asarray(charge_label, dtype=float)
            if charge_label.size == atom_nums:
                charge_label = charge_label.reshape(atom_nums)
                charge_rmse = np.sqrt(np.mean((charge_predict - charge_label) ** 2))
            else:
                charge_label = float(charge_label.reshape(-1)[0]) if charge_label.size else _get_image_total_charge(image)
                charge_rmse = np.abs(np.sum(charge_predict) - charge_label)
        result["charge_rmse"] = charge_rmse
        result["charge_label"] = charge_label
        result["charge_predict"] = charge_predict
    else:
        result["charge_rmse"] = -1e6
        result["charge_label"] = np.array([])
        result["charge_predict"] = np.array([])

    bec_predict = np.array(bec_predict)
    if bec_predict.size:
        bec_predict = bec_predict.reshape(9, atom_nums).transpose(1, 0)
        bec_label = getattr(image, "bec", None)
        if bec_label is not None:
            bec_label = np.asarray(bec_label).reshape(-1, 9)
            bec_rmse = np.sqrt(np.mean((bec_predict - bec_label) ** 2))
        else:
            bec_rmse = -1e6
            bec_label = np.ones_like(bec_predict) * (-1e6)
        result["bec_rmse"] = bec_rmse
        result["bec_label"] = bec_label
        result["bec_predict"] = bec_predict
    else:
        result["bec_rmse"] = -1e6
        result["bec_label"] = np.array([])
        result["bec_predict"] = np.array([])

    return result


def _split_indexed_images(indexed_images, worker_count):
    worker_count = max(1, min(worker_count, len(indexed_images)))
    chunks = [[] for _ in range(worker_count)]
    loads = [0 for _ in range(worker_count)]
    for indexed_image in sorted(indexed_images, key=lambda item: getattr(item[1], "atom_nums", 1), reverse=True):
        worker_id = min(range(worker_count), key=lambda item: loads[item])
        chunks[worker_id].append(indexed_image)
        loads[worker_id] += getattr(indexed_image[1], "atom_nums", 1)
    return [chunk for chunk in chunks if chunk]


def _run_nep_txt_inference_worker(nep_txt_path, indexed_images, input_atom_types, device_type="cpu", gpu_id=0, kspace_method="ewald", print_info=0):
    calc_obj = _init_nep_txt_calculator(nep_txt_path, device_type=device_type, gpu_id=gpu_id, print_info=print_info)
    return [
        _calculate_nep_image_result(idx, image, input_atom_types, calc_obj, kspace_method=kspace_method)
        for idx, image in indexed_images
    ]


def _set_data_loader_epoch(loader, epoch):
    batch_sampler = getattr(loader, "batch_sampler", None)
    if hasattr(batch_sampler, "set_epoch"):
        batch_sampler.set_epoch(epoch)
        return
    sampler = getattr(loader, "sampler", None)
    if isinstance(sampler, torch.utils.data.distributed.DistributedSampler):
        sampler.set_epoch(epoch)


def _set_training_loader_epoch(loader, epoch, input_param):
    """Advance the sampler and reject an epoch with no rank-complete work."""
    _set_data_loader_epoch(loader, epoch)
    if input_param.file_paths.format != "lmdb":
        return
    batch_mode, batch_value = parse_lmdb_batch_size(
        input_param.optimizer_param.batch_size
    )
    _require_lmdb_training_batches(
        loader.batch_sampler,
        dataset_size=len(loader.dataset),
        batch_mode=batch_mode,
        batch_value=batch_value,
        world_size=max(int(input_param.world_size), 1),
    )


class nep_network:
    def __init__(self, nep_param:InputParam):
        self.input_param = nep_param
        torch.set_printoptions(precision = 12)

        if self.input_param.seed is not None:
            random.seed(self.input_param.seed)
            torch.manual_seed(self.input_param.seed)

        self.is_rank_0 = True if self.input_param.rank == 0 else False
        device_type = training_device_type(self.input_param)
        self.device = torch.device(device_type)
        if device_type == "cuda":
            # srun may expose only one GPU to a task whose local rank is nonzero.
            device_index = self.input_param.local_rank if torch.cuda.device_count() > 1 else 0
            torch.cuda.set_device(device_index)
            self.device = torch.device("cuda", device_index)
        if self.input_param.world_size > 1:
            backend = training_backend(self.input_param, device_type)
            timeout_seconds = os.environ.get("MATPL_DDP_TIMEOUT_SECONDS")
            init_options = {}
            if timeout_seconds is not None:
                init_options["timeout"] = timedelta(seconds=int(timeout_seconds))
            dist.init_process_group(
                backend=backend,
                init_method=f"tcp://{self.input_param.master_addr}:{self.input_param.master_port}",
                rank=self.input_param.rank,
                world_size=self.input_param.world_size,
                **init_options,
            )
            print(f"Rank {self.input_param.rank}: LocalRank {self.input_param.local_rank}, "
                  f"device {self.device}, backend {backend}")
        else:
            print(f"Using device: {self.device}")

        if self.input_param.precision == "float32":
            self.training_type = torch.float32
        else:
            self.training_type = torch.float64

        self.criterion = nn.MSELoss().to(self.device)

    def _lmdb_loader(self, dataset, batch_sampler, collate_fn, persistent=True):
        loader_options = {
            "dataset": dataset,
            "batch_sampler": batch_sampler,
            "collate_fn": collate_fn,
            "num_workers": self.input_param.workers,
            "pin_memory": self.device.type == "cuda",
        }
        if self.input_param.workers > 0:
            loader_options["prefetch_factor"] = 2
            loader_options["persistent_workers"] = persistent
        return torch.utils.data.DataLoader(**loader_options)

    def _reduce_lmdb_statistics(self, local_statistics):
        atom_type_count = local_statistics.atom_type_count
        sum_values = np.concatenate(
            [
                local_statistics.ata.reshape(-1),
                local_statistics.ate,
                np.asarray(
                    [
                        local_statistics.frame_count,
                        local_statistics.atom_count_sum,
                    ],
                    dtype=np.float64,
                ),
            ]
        )
        sum_tensor = torch.as_tensor(
            sum_values, dtype=torch.float64, device=self.device
        )
        max_tensor = torch.tensor(
            [local_statistics.max_atoms], dtype=torch.int64, device=self.device
        )
        world_size = max(int(self.input_param.world_size), 1)
        if world_size > 1:
            if not dist.is_initialized():
                raise RuntimeError(
                    "distributed LMDB statistics require an initialized process group"
                )
            dist.all_reduce(sum_tensor, op=dist.ReduceOp.SUM)
            dist.all_reduce(max_tensor, op=dist.ReduceOp.MAX)

        reduced = sum_tensor.detach().cpu().numpy()
        matrix_size = atom_type_count * atom_type_count
        statistics = LmdbEnergyStatistics(atom_type_count)
        statistics.ata = reduced[:matrix_size].reshape(
            atom_type_count, atom_type_count
        ).copy()
        statistics.ate = reduced[
            matrix_size:matrix_size + atom_type_count
        ].copy()
        statistics.frame_count = int(round(reduced[-2]))
        statistics.atom_count_sum = int(round(reduced[-1]))
        statistics.max_atoms = int(max_tensor.item())
        return statistics

    def _prepare_lmdb_statistics(self, dataset):
        world_size = max(int(self.input_param.world_size), 1)
        rank = int(self.input_param.rank) if world_size > 1 else 0
        indices = select_stat_indices(
            len(dataset),
            self.input_param.lmdb_stat_frames,
            rank,
            world_size,
            self.input_param.seed,
        )
        local_statistics = LmdbEnergyStatistics(len(dataset.atom_types))
        for index in indices:
            local_statistics.update_from_sample(dataset[index])
        dataset.close()
        statistics = self._reduce_lmdb_statistics(local_statistics)
        if statistics.frame_count == 0:
            raise ValueError("LMDB training data contains no frames")
        dataset.energy_shift = statistics.energy_shift()
        dataset.avg_image_atom = statistics.average_atoms
        dataset.max_atom_nums = statistics.max_atoms
        return indices, statistics

    def _lmdb_natoms(self, dataset):
        cache = LmdbNatomsCache(
            dataset,
            os.path.join(
                self.input_param.file_paths.json_dir, ".matpl_lmdb_cache"
            ),
        )
        world_size = max(int(self.input_param.world_size), 1)
        rank = int(self.input_param.rank) if world_size > 1 else 0
        cache.build_assigned(rank, world_size)
        if world_size > 1:
            dist.barrier()
        cache.load()
        if not hasattr(self, "_lmdb_natoms_caches"):
            self._lmdb_natoms_caches = []
        self._lmdb_natoms_caches.append(cache)
        return cache

    def _lmdb_batch_sampler(self, dataset, batch_mode, batch_value, shuffle):
        world_size = max(int(self.input_param.world_size), 1)
        rank = int(self.input_param.rank) if world_size > 1 else 0
        if batch_mode == "frames":
            return DistributedFrameBatchSampler(
                len(dataset),
                batch_value,
                rank,
                world_size,
                seed=self.input_param.seed,
                shuffle=shuffle,
            )
        natoms = self._lmdb_natoms(dataset) if len(dataset) > 0 else []
        return DistributedAtomBatchSampler(
            natoms,
            batch_value,
            rank,
            world_size,
            seed=self.input_param.seed,
            shuffle=shuffle,
        )

    def _load_lmdb_data(self, fill_ion_bec):
        if self.input_param.precision == "float32":
            raise ValueError(
                "NEP LMDB training requires precision 'float64' because the "
                "current CalcOps descriptor kernel accepts double tensors"
            )
        dtype = (
            torch.float32
            if self.input_param.precision == "float32"
            else torch.float64
        )
        common_dataset_options = {
            "atom_types": self.input_param.atom_type,
            "cutoff_radial": self.input_param.nep_param.cutoff[0],
            "cutoff_angular": self.input_param.nep_param.cutoff[1],
            "dtype": dtype,
            "fill_metal_bec": fill_ion_bec,
            "nonperiodic_vacuum_padding": getattr(
                self.input_param, "nonperiodic_vacuum_padding", None),
        }

        if self.input_param.inference:
            test_dataset = NepLmdbDataset(
                self.input_param.file_paths.test_data_path,
                cal_energy=False,
                train_ei=False,
                **common_dataset_options,
            )
            stat_indices, _ = self._prepare_lmdb_statistics(test_dataset)
            test_sampler = DistributedFrameBatchSampler(
                len(test_dataset), 1, 0, 1, seed=self.input_param.seed, shuffle=False
            )
            test_loader = self._lmdb_loader(
                test_dataset,
                test_sampler,
                variable_length_collate_fn,
            )
            stat_batch_size = max(
                1, calculate_batch(test_dataset.max_atom_nums, 400)
            )
            stat_sampler = torch.utils.data.BatchSampler(
                stat_indices, stat_batch_size, drop_last=False
            )
            stat_loader = self._lmdb_loader(
                test_dataset,
                stat_sampler,
                variable_length_collate_fn_nolimit,
                persistent=False,
            )
            return test_dataset.get_energy_shift(), test_loader, None, stat_loader

        train_dataset = NepLmdbDataset(
            self.input_param.file_paths.train_data_path,
            cal_energy=True,
            train_ei=self.input_param.optimizer_param.train_ei,
            **common_dataset_options,
        )
        valid_dataset = None
        if self.input_param.file_paths.valid_data_path:
            valid_dataset = NepLmdbDataset(
                self.input_param.file_paths.valid_data_path,
                cal_energy=False,
                train_ei=self.input_param.optimizer_param.train_ei,
                **common_dataset_options,
            )
        stat_indices, statistics = self._prepare_lmdb_statistics(train_dataset)
        batch_mode, batch_value = parse_lmdb_batch_size(
            self.input_param.optimizer_param.batch_size
        )
        self._lr_local_batch_size = (
            batch_value
            if batch_mode == "frames"
            else max(1.0, batch_value / statistics.average_atoms)
        )

        train_sampler = self._lmdb_batch_sampler(
            train_dataset,
            batch_mode,
            batch_value,
            self.input_param.data_shuffle,
        )
        _require_lmdb_training_batches(
            train_sampler,
            dataset_size=len(train_dataset),
            batch_mode=batch_mode,
            batch_value=batch_value,
            world_size=max(int(self.input_param.world_size), 1),
        )
        train_loader = self._lmdb_loader(
            train_dataset,
            train_sampler,
            variable_length_collate_fn,
        )
        val_loader = None
        if valid_dataset is not None:
            valid_sampler = self._lmdb_batch_sampler(
                valid_dataset,
                batch_mode,
                batch_value,
                self.input_param.valid_shuffle,
            )
            val_loader = self._lmdb_loader(
                valid_dataset,
                valid_sampler,
                variable_length_collate_fn,
            )

        stat_batch_size = max(1, calculate_batch(statistics.max_atoms, 400))
        stat_sampler = torch.utils.data.BatchSampler(
            stat_indices, stat_batch_size, drop_last=False
        )
        stat_loader = self._lmdb_loader(
            train_dataset,
            stat_sampler,
            variable_length_collate_fn_nolimit,
            persistent=False,
        )
        return train_dataset.get_energy_shift(), train_loader, val_loader, stat_loader

    def load_data(self):
        fill_ion_bec = (
            self.input_param.optimizer_param.train_bec
            and getattr(
                self.input_param.optimizer_param, "train_bec_ion", False)
        )
        if self.input_param.file_paths.format == "lmdb":
            return self._load_lmdb_data(fill_ion_bec)
        if self.input_param.inference:# 只在debug ckpt 推理时启用
            test_dataset = UniDataset(self.input_param.file_paths.test_data_path, 
                                            self.input_param.file_paths.format, 
                                            self.input_param.atom_type,
                                            cutoff_radial = self.input_param.nep_param.cutoff[0],
                                            cutoff_angular= self.input_param.nep_param.cutoff[1],
                                            cal_energy=False,
                                            fill_metal_bec=fill_ion_bec)

            test_sampler = torch.utils.data.distributed.DistributedSampler(
                test_dataset,
                num_replicas=1,
                rank=0,
                shuffle=False
            )

            test_loader = torch.utils.data.DataLoader(
                test_dataset,
                batch_size=1,
                shuffle=False,  # DistributedSampler 控制 shuffle
                sampler=test_sampler,
                collate_fn=variable_length_collate_fn, 
                num_workers=self.input_param.workers,
                drop_last=True,
                pin_memory=self.device.type == "cuda",
                prefetch_factor=2,
                persistent_workers=True
            )
            energy_shift = test_dataset.get_energy_shift()

            forscaler_loader = torch.utils.data.DataLoader(
                test_dataset,
                batch_size=128,
                shuffle=False,  # DistributedSampler 控制 shuffle
                sampler=test_sampler,
                collate_fn=variable_length_collate_fn_nolimit, 
                num_workers=self.input_param.workers,
                drop_last=False,
                pin_memory=self.device.type == "cuda",
                prefetch_factor=2,
                persistent_workers=True
            )

            return energy_shift, test_loader, None, forscaler_loader
        else:
            train_dataset = UniDataset(self.input_param.file_paths.train_data_path, 
                                            self.input_param.file_paths.format, 
                                            self.input_param.atom_type,
                                            cutoff_radial = self.input_param.nep_param.cutoff[0],
                                            cutoff_angular= self.input_param.nep_param.cutoff[1],
                                            cal_energy=True,
                                            fill_metal_bec=fill_ion_bec)

            valid_dataset = UniDataset(self.input_param.file_paths.valid_data_path, 
                                            self.input_param.file_paths.format, 
                                            self.input_param.atom_type,
                                            cutoff_radial = self.input_param.nep_param.cutoff[0],
                                            cutoff_angular= self.input_param.nep_param.cutoff[1],
                                            cal_energy=False,
                                            fill_metal_bec=fill_ion_bec
                                            )
            energy_shift = train_dataset.get_energy_shift()
            # 使用 DistributedSampler
            train_sampler = torch.utils.data.distributed.DistributedSampler(
                train_dataset,
                num_replicas=self.input_param.world_size,
                rank=self.input_param.rank,
                shuffle=self.input_param.data_shuffle
            )
            train_loader = torch.utils.data.DataLoader(
                train_dataset,
                batch_size=self.input_param.optimizer_param.batch_size,
                shuffle=False,  # DistributedSampler 控制 shuffle
                sampler=train_sampler,
                collate_fn=variable_length_collate_fn, 
                num_workers=self.input_param.workers,
                drop_last=True,
                pin_memory=self.device.type == "cuda",
                prefetch_factor=2,
                persistent_workers=True
            )
            max_batch = calculate_batch(train_dataset.max_atom_nums, 400) # 按照最大默认400个近邻取batchsize
            forscaler_loader = torch.utils.data.DataLoader(
                train_dataset,
                batch_size=max_batch,
                shuffle=False,  # DistributedSampler 控制 shuffle
                sampler=train_sampler,
                collate_fn=variable_length_collate_fn_nolimit, 
                num_workers=self.input_param.workers,
                drop_last=False,
                pin_memory=self.device.type == "cuda",
                prefetch_factor=2,
                persistent_workers=True
            )
            valid_sampler = torch.utils.data.distributed.DistributedSampler(
                valid_dataset,
                num_replicas=self.input_param.world_size,
                rank=self.input_param.rank,
                shuffle=False
            )
            val_loader = torch.utils.data.DataLoader(
                valid_dataset,
                batch_size=self.input_param.optimizer_param.batch_size,
                shuffle=False,
                sampler=valid_sampler,
                collate_fn=variable_length_collate_fn,
                num_workers=self.input_param.workers,
                pin_memory=self.device.type == "cuda",
                drop_last=True,
                prefetch_factor=2,
                persistent_workers=True
            )
            return energy_shift, train_loader, val_loader, forscaler_loader
    
    '''
    description:
        if davg, dstd and energy_shift not from load_data, get it from model_load_file no use code
    return {*} 
    author: wuxingxing
    '''
    def load_model_optimizer(self, energy_shift, avg_atom_num=1, iterations=1, q_scaler = None, max_NN_radial = -1, max_NN_angular = -1):
        def _adjust_ckpt_keys(ckpt, new_ckpt):
            keys = list(ckpt['state_dict'].keys())
            new_dict = {}
            
            if 'q_scaler' in keys: # ckpt from single GPU training
                if self.is_rank_0:
                    print("The checkpoint file from single gpu training!")
                for key in keys:
                    if self.input_param.world_size > 1: # current is multi gpus
                        new_dict[f'{module}{key}'] = ckpt['state_dict'][key]
                if self.input_param.world_size == 1: # current is single gpus
                    new_dict = ckpt['state_dict']
                
                new_dict[f'{module}q_scaler'] = torch.tensor(list(ckpt['state_dict']['q_scaler']),  # set q_scaler
                                                    dtype=new_ckpt.state_dict()[f'{module}c_param_2'].dtype, 
                                                    device=new_ckpt.state_dict()[f'{module}c_param_2'].device)
                for key in ["C3B", "C4B", "C5B", "atom_type_device", "max_NN_radial", "max_NN_angular"]:
                    new_dict[f'{module}{key}'] = new_ckpt.state_dict()[f'{module}{key}'] # these parameters are fixed values
                    
            else: # ckpt from multi-train version
                if ("module." in keys[0] and self.input_param.world_size > 1) or ("module." not in keys[0] and self.input_param.world_size == 1): # ckpt from multi-gpu
                    new_dict = ckpt['state_dict']
                else:
                    for key in keys:
                        if "module." in keys[0] and self.input_param.world_size == 1: # ckpt from multi-gpu and current work use single cpu remove the module key
                            new_dict[key.replace("module.", "")] = ckpt['state_dict'][key]
                        else: # ckpt from single train but current is multi training
                            new_dict[f'module.{key}'] = ckpt['state_dict'][key]
            ckpt['state_dict'] = new_dict
            return ckpt

        model = NEP(self.input_param, 
                        energy_shift,
                        q_scaler = q_scaler, 
                        max_NN_radial = max_NN_radial, 
                        max_NN_angular = max_NN_angular,
                        dtype = self.training_type, 
                        device = self.device
                        ).to(self.training_type).to(self.device)
        prepare_fitting_jit(model)
        # 包装模型为 DDP
        if self.input_param.world_size > 1:
            ddp_options = {"find_unused_parameters": True,
                           "broadcast_buffers": False,
                           "gradient_as_bucket_view": True}
            if self.device.type == "cuda":
                ddp_options.update(device_ids=[self.device.index], output_device=self.device.index)
            model = nn.parallel.DistributedDataParallel(model, **ddp_options)
        checkpoint = None
        model_path = None
        allow_periodic_checkpoint_fallback = False
        # inference 用于debug，直接走的nepcpu or nepgpu
        if self.input_param.inference:
            model_path = self.input_param.file_paths.model_load_path
        elif self.input_param.recover_train and self.input_param.file_paths.model_load_path and \
           os.path.exists(self.input_param.file_paths.model_load_path):
            model_path = self.input_param.file_paths.model_load_path
        
        else:
            if self.input_param.nep_param.model_wb is None:
                if self.input_param.file_paths.model_load_path and \
                   os.path.exists(self.input_param.file_paths.model_load_path):
                    model_path = self.input_param.file_paths.model_load_path
                else:
                    model_path = self.input_param.file_paths.model_save_path
                    allow_periodic_checkpoint_fallback = bool(
                        self.input_param.recover_train)
            else:
                model_path = None

        module = 'module.' if self.input_param.world_size > 1 else ''
        if model_path and os.path.isfile(model_path):
            checkpoint, loaded_model_path = load_nep_checkpoint_with_fallback(
                model_path,
                map_location=self.device,
                allow_periodic_fallback=allow_periodic_checkpoint_fallback,
            )
            model_path = loaded_model_path
            checkpoint = _adjust_ckpt_keys(checkpoint, model) # 适配旧版本以及单卡多卡版本
            model.load_state_dict(checkpoint["state_dict"])
            if "epoch" in checkpoint:
                if self.input_param.optimizer_param.reset_epoch and self.input_param.inference is False:
                    if checkpoint["epoch"] != 1:
                        print(f"Rank {self.input_param.rank}: Resetting epoch to 1 from {checkpoint['epoch']}")
                    self.input_param.optimizer_param.start_epoch = 1
                else:
                    self.input_param.optimizer_param.start_epoch = checkpoint["epoch"] + 1
            if self.input_param.world_size > 1:
                print(f"Reload ckpt: Rank {self.input_param.rank}, LocalRank {self.input_param.local_rank}, start_epoch: {self.input_param.optimizer_param.start_epoch}")
                dist.barrier()

        # optimizer, and learning rate scheduler
        scheduler = None
        self.optimizer_peak_lr = None
        if self.input_param.optimizer_param.opt_name in ["ADAM", "ADAMW", "SGD"]:
            self.lr_scale = calculate_lr_scale(
                self.input_param.optimizer_param.scale_lr,
                getattr(
                    self.input_param.optimizer_param,
                    "scale_method",
                    getattr(self.input_param.optimizer_param, "scaling_method", "sqrt"),
                ),
                getattr(
                    self,
                    "_lr_local_batch_size",
                    self.input_param.optimizer_param.batch_size,
                ),
                self.input_param.world_size,
                avg_atom_num,
            )
            self.optimizer_peak_lr = resolve_optimizer_peak_lr(
                self.input_param.optimizer_param.learning_rate,
                self.lr_scale,
            )
            # Always initialize the optimizer and scheduler from the actual
            # peak LR. Warmup temporarily changes only the current optimizer
            # LR, so scheduler.base_lrs remains the true peak value.
            init_lr = self.optimizer_peak_lr

            if self.input_param.optimizer_param.opt_name == "ADAM":
                optimizer = optim.Adam(
                    model.parameters(),
                    lr=init_lr,
                    weight_decay=self.input_param.optimizer_param.lambda_2 or 0
                )
            elif self.input_param.optimizer_param.opt_name == "ADAMW":
                optimizer = optim.AdamW(
                    model.parameters(),
                    lr=init_lr,
                    weight_decay=self.input_param.optimizer_param.lambda_2 or 0
                )
            elif self.input_param.optimizer_param.opt_name == "SGD":
                optimizer = optim.SGD(
                    model.parameters(),
                    lr=init_lr,
                    momentum=self.input_param.optimizer_param.momentum,
                    weight_decay=self.input_param.optimizer_param.weight_decay
                )
            # 初始化学习率调度器
            if self.input_param.optimizer_param.t_0 and self.input_param.optimizer_param.opt_name not in ["LKF", "GKF"]:
                scheduler = optim.lr_scheduler.CosineAnnealingWarmRestarts(
                optimizer,
                T_0=self.input_param.optimizer_param.t_0 * iterations,
                T_mult=self.input_param.optimizer_param.t_mult,
                eta_min=self.input_param.optimizer_param.stop_lr,
                last_epoch=-1
            )
        elif self.input_param.optimizer_param.opt_name == "LKF":
            optimizer = LKFOptimizer(
                model.parameters(),
                self.input_param.optimizer_param.kalman_lambda,
                self.input_param.optimizer_param.kalman_nue,
                self.input_param.optimizer_param.block_size,
                self.input_param.optimizer_param.p0_weight
            )
        elif self.input_param.optimizer_param.opt_name == "GKF":
            optimizer = GKFOptimizer(
                model.parameters(),
                self.input_param.optimizer_param.kalman_lambda,
                self.input_param.optimizer_param.kalman_nue
            )
        else:
            raise Exception("Error: Unsupported optimizer!")

        if checkpoint is not None and not self.input_param.inference:
            optimizer_restored = restore_nep_optimizer_state(
                checkpoint,
                optimizer,
                self.input_param.optimizer_param.reset_epoch,
                allow_optimizer_param_group_mismatch=getattr(
                    self.input_param.nep_param,
                    "fixed_sqrt_epsilon_inf",
                    None) is not None,
            )
            if self.is_rank_0:
                if self.input_param.optimizer_param.reset_epoch:
                    print("reset_epoch=true: using a fresh optimizer and scheduler")
                else:
                    optimizer_message = "restored" if optimizer_restored else "not found; using a fresh optimizer"
                    print(f"NEP optimizer state: {optimizer_message}")

        self.lr_steps_per_epoch = iterations
        if (
                checkpoint is not None
                and not self.input_param.optimizer_param.reset_epoch):
            self.completed_optimizer_updates = checkpoint.get(
                "optimizer_updates")
            if self.completed_optimizer_updates is None:
                # Backward compatibility for checkpoints written before the
                # explicit optimizer-update counter was introduced.
                self.completed_optimizer_updates = (
                    self.input_param.optimizer_param.start_epoch - 1
                ) * iterations
            # Epoch checkpoints retain LR phase when the new GPU count
            # changes the number of optimizer updates per epoch.
            lr_progress_epochs = checkpoint.get("lr_progress_epochs")
            if lr_progress_epochs is None:
                lr_progress_epochs = checkpoint.get("epoch")
            if lr_progress_epochs is None:
                self.completed_lr_updates = self.completed_optimizer_updates
            else:
                self.completed_lr_updates = round(
                    float(lr_progress_epochs) * iterations)
        else:
            self.completed_optimizer_updates = 0
            self.completed_lr_updates = 0
        # warm_epochs is configuration, not saved progress. Recompute it for
        # the current loader, including when batch/mix or world size changes.
        self.warmup_optimizer_updates = (
            (self.input_param.optimizer_param.warmup or 0) * iterations)
        if self.optimizer_peak_lr is not None:
            current_lr = initialize_nep_learning_rate(
                optimizer, scheduler, self.input_param.optimizer_param,
                self.optimizer_peak_lr, self.completed_optimizer_updates,
                self.warmup_optimizer_updates, self.completed_lr_updates)
            if self.is_rank_0:
                print(
                    "NEP learning rate: computed from current configuration; "
                    f"completed_updates={self.completed_optimizer_updates}, "
                    f"lr_progress_updates={self.completed_lr_updates}, "
                    f"warmup_updates={self.warmup_optimizer_updates}, "
                    f"peak_lr={self.optimizer_peak_lr:.8e}, "
                    f"next_lr={current_lr:.8e}")

        return model, optimizer, scheduler


    def reset_lr(self, model, iterations, optimizer, scheduler):
        # Warmup must not recreate Adam and discard its accumulated moments.
        # The scheduler was initialized from optimizer_peak_lr and was not
        # stepped during warmup, so only restore the optimizer's current LR.
        for param_group in optimizer.param_groups:
            param_group["lr"] = self.optimizer_peak_lr
        return optimizer, scheduler

    def train(self):
        energy_shift, train_loader, val_loader, forscaler_loader = self.load_data()
        if len(train_loader) < 1:
            print(f"ERROR! The training set size {len(train_loader)} is too small, please adjust the number of GPU or batch_size: training_set_size >= batch_size * gpu_nums")
        max_NN_radial, min_NN_radial, max_NN_angular, min_NN_angular, q_scaler = None, None, None, None, None
        # max_NN 训练集计算，之后如果存在nep.txt，取最大值作为max_nn,用于模型初始化。初始化后，如果存在ckpt文件（recover）,则更新为ckpt中的值。 
    
        # print(f"======= rank {self.input_param.rank} len forscaler_loader {len(forscaler_loader)} ======")
        neighbor_scaler = (
            _calculate_lmdb_neighbor_scaler
            if self.input_param.file_paths.format == "lmdb"
            else calculate_neighbor_scaler
        )
        local_global_max, local_global_min, local_max_NN_radial, local_min_NN_radial, local_max_NN_angular, local_min_NN_angular = neighbor_scaler(
                    forscaler_loader,
                    self.input_param.nep_param.n_max[0],      # model.n_max_radial,
                    self.input_param.nep_param.basis_size[0], # model.n_base_radial,
                    self.input_param.nep_param.n_max[1],      # model.n_max_angular,
                    self.input_param.nep_param.basis_size[1], # model.n_base_angular,
                    self.input_param.nep_param.l_max[0],      # model.l_max_3b,
                    self.input_param.nep_param.l_max[1],      # model.l_max_4b,
                    self.input_param.nep_param.l_max[2],      # model.l_max_5b,
                    self.device,
                    num_workers=self.input_param.workers)
        if self.input_param.world_size > 1:
            # 汇总 global_max
            local_global_max_tensor = local_global_max.clone().detach().to(self.device)
            dist.all_reduce(local_global_max_tensor, op=dist.ReduceOp.MAX)
            global_max = local_global_max_tensor
            
            # 汇总 global_min
            local_global_min_tensor = local_global_min.clone().detach().to(self.device)
            dist.all_reduce(local_global_min_tensor, op=dist.ReduceOp.MIN)
            global_min = local_global_min_tensor
            
            # 汇总 max_NN_radial
            max_radial_tensor = torch.tensor([local_max_NN_radial], dtype=torch.int64, device=self.device)
            dist.all_reduce(max_radial_tensor, op=dist.ReduceOp.MAX)
            max_NN_radial = max_radial_tensor.item()
            
            # 汇总 max_NN_angular
            max_angular_tensor = torch.tensor([local_max_NN_angular], dtype=torch.int64, device=self.device)
            dist.all_reduce(max_angular_tensor, op=dist.ReduceOp.MAX)
            max_NN_angular = max_angular_tensor.item()
        else:
            # 单卡情况
            global_max = local_global_max
            global_min = local_global_min
            max_NN_radial = local_max_NN_radial
            max_NN_angular = local_max_NN_angular
            # 计算最终的 q_scaler
        if self.input_param.nep_param.q_scaler is None:
            q_scaler = 1.0 / (global_max - global_min)
            q_scaler = q_scaler.tolist()
        else:
            # 如果提供了预定义的 q_scaler
            q_scaler = self.input_param.nep_param.q_scaler
            if self.input_param.nep_param.max_nn_from_txt:
                max_NN_radial  = max(self.input_param.nep_param.max_NN_radial, max_NN_radial)
                max_NN_angular = max(self.input_param.nep_param.max_NN_angular, max_NN_angular)

        # print(f"INIT: Rank: {self.input_param.rank}, LocalRank: {self.input_param.local_rank},  Max neighbor numbers: radial={max_NN_radial}, angular={max_NN_angular}, scaler[-1]:{q_scaler[-1]} lendata {len(train_loader)}")
        if self.input_param.world_size > 1:
            dist.barrier()

        model, optimizer, scheduler = self.load_model_optimizer(energy_shift, 
                                                                avg_atom_num=train_loader.dataset.avg_image_atom,
                                                                iterations=len(train_loader), 
                                                                q_scaler = q_scaler, 
                                                                max_NN_radial = max_NN_radial, 
                                                                max_NN_angular = max_NN_angular)

        if self.is_rank_0 and not os.path.exists(self.input_param.file_paths.model_store_dir):
            os.makedirs(self.input_param.file_paths.model_store_dir)
        if self.input_param.world_size > 1:
            dist.barrier()

        train_lists = ["epoch", "loss"]
        valid_lists = ["epoch", "loss"]
        
        if self.input_param.optimizer_param.lambda_1 is not None:
            train_lists.append("Loss_l1")
        if self.input_param.optimizer_param.lambda_2 is not None:
            train_lists.append("Loss_l2")

        if self.input_param.optimizer_param.train_energy:
            train_lists.append("RMSE_Etot(eV/atom)")
            valid_lists.append("RMSE_Etot(eV/atom)")
        if self.input_param.optimizer_param.train_ei:
            train_lists.append("RMSE_Ei")
            valid_lists.append("RMSE_Ei")
        if self.input_param.optimizer_param.train_egroup:
            train_lists.append("RMSE_Egroup")
            valid_lists.append("RMSE_Egroup")
        if self.input_param.optimizer_param.train_force:
            train_lists.append("RMSE_F(eV/Å)")
            valid_lists.append("RMSE_F(eV/Å)")
        if self.input_param.optimizer_param.train_charge:
            train_lists.append("RMSE_charge")
            valid_lists.append("RMSE_charge")
        if self.input_param.optimizer_param.train_bec:
            train_lists.append("RMSE_BEC")
            valid_lists.append("RMSE_BEC")
        if self.input_param.optimizer_param.train_virial:
            train_lists.append("RMSE_virial(eV/atom)")
            valid_lists.append("RMSE_virial(eV/atom)")
        if self.input_param.optimizer_param.opt_name == "LKF" or self.input_param.optimizer_param.opt_name == "GKF":
            train_lists.extend(["time(s)"])
        else:
            train_lists.extend(["last_lr_used", "time(s)"])

        train_print_width = {
            "epoch": 5,
            "loss": 18,
            "RMSE_Etot(eV)": 18,
            "RMSE_Etot(eV/atom)": 21,
            "RMSE_Ei": 18,
            "RMSE_Egroup": 18,
            "RMSE_F(eV/Å)": 21,
            "RMSE_charge": 18,
            "RMSE_BEC": 18,
            "RMSE_virial(eV)": 18,
            "RMSE_virial(eV/atom)": 23,
            "Loss_l1": 18,
            "Loss_l2": 18,
            "last_lr_used": 18,
            "time(s)": 15,
        }

        train_format = "".join(["%{}s".format(train_print_width[i]) for i in train_lists])
        valid_format = "".join(["%{}s".format(train_print_width[i]) for i in valid_lists])
        train_log = os.path.join(self.input_param.file_paths.model_store_dir, "epoch_train.dat")
        valid_log = os.path.join(self.input_param.file_paths.model_store_dir, "epoch_valid.dat")
        if self.is_rank_0:
            write_mode = "a" if os.path.exists(train_log) else "w"
            with _open_nep_log(train_log, write_mode) as f_train_log:
                if write_mode == "w":
                    f_train_log.write("# %s\n" % (train_format % tuple(train_lists)))
            if val_loader and len(val_loader) > 0:
                with _open_nep_log(valid_log, write_mode) as f_valid_log:
                    if write_mode == "w":
                        f_valid_log.write("# %s\n" % (valid_format % tuple(valid_lists)))

        for epoch in range(self.input_param.optimizer_param.start_epoch, self.input_param.optimizer_param.epochs + 1):
            time_start = time.time()
            # 设置 sampler 的 epoch 以确保 shuffle 一致
            _set_training_loader_epoch(
                train_loader, epoch, self.input_param
            )

            if self.input_param.optimizer_param.opt_name == "LKF" or self.input_param.optimizer_param.opt_name == "GKF":
                loss, loss_Etot, loss_Etot_per_atom, loss_Force, loss_Ei, loss_egroup, loss_virial, loss_virial_per_atom, loss_charge, loss_bec, loss_l1, loss_l2 = train_KF(
                    train_loader, model, self.criterion, optimizer, epoch, self.device, self.input_param
                )
            else:
                loss, loss_Etot, loss_Etot_per_atom, loss_Force, loss_Ei, loss_egroup, loss_virial, loss_virial_per_atom, loss_charge, loss_bec, last_lr_used, loss_l1, loss_l2, completed_epoch_updates = train(
                    train_loader, model, self.criterion, optimizer, scheduler, epoch,
                        self.optimizer_peak_lr,
                        self.completed_optimizer_updates,
                        self.warmup_optimizer_updates,
                        self.device,
                        self.input_param,
                        lr_completed_updates=self.completed_lr_updates,
                )
                self.completed_optimizer_updates += completed_epoch_updates
                self.completed_lr_updates += completed_epoch_updates

            time_end = time.time()
            # self.convert_to_gpumd(model)

            # evaluate on validation set
            if val_loader and len(val_loader) > 0:
                vld_loss, vld_loss_Etot, vld_loss_Etot_per_atom, vld_loss_Force, vld_loss_Ei, val_loss_egroup, val_loss_virial, val_loss_virial_per_atom, val_loss_charge, val_loss_bec = valid(
                    val_loader, model, self.criterion, self.device, self.input_param
                )

            if self.is_rank_0:
                with _open_nep_log(train_log, "a") as f_train_log:
                    train_log_line = f"{epoch:5d}{loss:20.10e}"
                    if self.input_param.optimizer_param.lambda_1:
                        train_log_line += f"{loss_l1:18.10e}"
                    if self.input_param.optimizer_param.lambda_2:
                        train_log_line += f"{loss_l2:18.10e}"
                    if self.input_param.optimizer_param.train_energy:
                        train_log_line += f"{loss_Etot_per_atom:21.10e}"
                    if self.input_param.optimizer_param.train_ei:
                        train_log_line += f"{loss_Ei:18.10e}"
                    if self.input_param.optimizer_param.train_egroup:
                        train_log_line += f"{loss_egroup:18.10e}"
                    if self.input_param.optimizer_param.train_force:
                        train_log_line += f"{loss_Force:21.10e}"
                    if self.input_param.optimizer_param.train_charge:
                        train_log_line += f"{loss_charge:18.10e}"
                    if self.input_param.optimizer_param.train_bec:
                        train_log_line += f"{loss_bec:18.10e}"
                    if self.input_param.optimizer_param.train_virial:
                        train_log_line += f"{loss_virial_per_atom:23.10e}"
                    if self.input_param.optimizer_param.opt_name == "LKF" or self.input_param.optimizer_param.opt_name == "GKF":
                        train_log_line += "%15.4f" % (time_end - time_start)
                    else:
                        train_log_line += f"{last_lr_used:18.10e}{(time_end - time_start):15.4f}"
                    f_train_log.write(f"{train_log_line}\n")

                if val_loader and len(val_loader) > 0:
                    with _open_nep_log(valid_log, "a") as f_valid_log:
                        valid_log_line = f"{epoch:5d}{vld_loss:20.10e}"
                        if self.input_param.optimizer_param.train_energy:
                            valid_log_line += f"{vld_loss_Etot_per_atom:21.10e}"
                        if self.input_param.optimizer_param.train_ei:
                            valid_log_line += f"{vld_loss_Ei:18.10e}"
                        if self.input_param.optimizer_param.train_egroup:
                            valid_log_line += f"{val_loss_egroup:18.10e}"
                        if self.input_param.optimizer_param.train_force:
                            valid_log_line += f"{vld_loss_Force:21.10e}"
                        if self.input_param.optimizer_param.train_charge:
                            valid_log_line += f"{val_loss_charge:18.10e}"
                        if self.input_param.optimizer_param.train_bec:
                            valid_log_line += f"{val_loss_bec:18.10e}"
                        if self.input_param.optimizer_param.train_virial:
                            valid_log_line += f"{val_loss_virial_per_atom:23.10e}"
                        f_valid_log.write(f"{valid_log_line}\n")
            # 保存检查点
            if self.is_rank_0:
                checkpoint_dict = build_nep_checkpoint(
                    self.input_param.to_dict(),
                    epoch,
                    model,
                    optimizer,
                    scheduler,
                    self.completed_optimizer_updates,
                    self.warmup_optimizer_updates,
                    lr_progress_epochs=(
                        self.completed_lr_updates / self.lr_steps_per_epoch),
                )
                save_checkpoint(
                    checkpoint_dict,
                    self.input_param.file_paths.model_name,
                    self.input_param.file_paths.model_store_dir,
                )
                self.convert_to_gpumd()

                if self.input_param.optimizer_param.t_0 is not None and \
                    is_epoch_before_restart(self.input_param.optimizer_param.t_0, self.input_param.optimizer_param.t_mult, epoch):
                    save_checkpoint(checkpoint_dict,
                                    f'epoch_{epoch}_{self.input_param.file_paths.model_name}',
                                    self.input_param.file_paths.model_store_dir,
                                    )
                    self.convert_to_gpumd(prefix=f"epoch_{epoch}_")

        # 清理 DDP 环境
        if self.input_param.world_size > 1:
            dist.destroy_process_group()
            
    '''
    description: 
        delete nep.in file, this file not used
    param {*} self
    param {NEP} model
    param {str} save_dir
    return {*}
    author: wuxingxing
    '''
    def convert_to_gpumd(self, prefix=""):
        ckpt_path = os.path.join(self.input_param.file_paths.model_store_dir, self.input_param.file_paths.model_name)
        # extract parameters
        nep_content, model_atom_type, atom_names = extract_model(ckpt_path)
        first_line = nep_content.splitlines()[0] if nep_content else ""
        nep_file_name = "nep4.txt" if first_line.startswith("nep4") else "nep5.txt"
        save_nep_txt_path = os.path.join(self.input_param.file_paths.model_store_dir, f"{prefix}{nep_file_name}")
        with open(save_nep_txt_path, 'w') as wf:
                wf.writelines(nep_content)

    # mulit cpu, code has error
    def process_image(self, idx, image, calc_obj=None, kspace_method="ewald"):
        global calc
        if calc_obj is None:
            calc_obj = calc
        return _calculate_nep_image_result(idx, image, self.input_param.atom_type, calc_obj, kspace_method=kspace_method)

    def multi_cpus_nep_inference(self, nep_txt_path, kspace_method="ewald"):
        time0 = time.time()
        images = NepTestData(self.input_param).image_list
        indexed_images = list(enumerate(images))
        results = []
        if len(indexed_images) == 0:
            raise Exception("Error! No images found for NEP test inference.")

        if self.device.type == "cuda" and torch.cuda.is_available():
            gpu_count = min(torch.cuda.device_count(), len(indexed_images))
            print("The GPUs: {}".format(gpu_count))
            chunks = _split_indexed_images(indexed_images, gpu_count)
            if gpu_count == 1:
                results = _run_nep_txt_inference_worker(
                    nep_txt_path,
                    chunks[0],
                    self.input_param.atom_type,
                    device_type="cuda",
                    gpu_id=0,
                    kspace_method=kspace_method,
                    print_info=1
                )
            else:
                mp_context = multiprocessing.get_context("spawn")
                with concurrent.futures.ProcessPoolExecutor(max_workers=gpu_count, mp_context=mp_context) as executor:
                    futures = [
                        executor.submit(
                            _run_nep_txt_inference_worker,
                            nep_txt_path,
                            chunk,
                            self.input_param.atom_type,
                            "cuda",
                            gpu_id,
                            kspace_method,
                            1 if gpu_id == 0 else 0
                        )
                        for gpu_id, chunk in enumerate(chunks)
                    ]
                    for future in concurrent.futures.as_completed(futures):
                        results.extend(future.result())
        else:
            cpu_count = multiprocessing.cpu_count()
            print("The CPUs: {}".format(cpu_count))
            global calc
            calc = FindNeigh()
            calc.init_model(nep_txt_path)
            if cpu_count == 1:
                for idx, image in indexed_images:
                    results.append(self.process_image(idx, image, kspace_method=kspace_method))
            else:
                with concurrent.futures.ProcessPoolExecutor(max_workers=cpu_count) as executor:
                    futures = [
                        executor.submit(self.process_image, idx, image, None, kspace_method)
                        for idx, image in indexed_images
                    ]
                    results = [future.result() for future in concurrent.futures.as_completed(futures)]
        # Collecting results
        etot_rmse, etot_atom_rmse, ei_rmse, force_rmse = [], [], [], []
        etot_label_list, etot_predict_list = [], []
        ei_label_list, ei_predict_list = [], []
        force_label_list, force_predict_list = [], []
        virial_rmse, virial_atom_rmse = [], []
        virial_label_list, virial_predict_list = [], []
        charge_label_list, charge_predict_list, charge_rmse_list = [], [], []
        bec_label_list, bec_predict_list = [], []
        atom_num_list = []
        virial_index = [0, 1, 2, 4, 5, 8]
        results = sorted(results, key=lambda x: x['idx'])
        has_charge = any(np.asarray(result["charge_predict"]).size for result in results)
        has_bec = any(np.asarray(result["bec_predict"]).size for result in results)
        for result in results:
            etot_rmse.append(result["etot_rmse"])
            etot_atom_rmse.append(result["etot_atom_rmse"])
            ei_rmse.append(result["ei_rmse"])
            force_rmse.append(result["force_rmse"])
            etot_label_list.append(result["etot_label"])
            etot_predict_list.append(result["etot_predict"])
            ei_label_list.append(result["ei_label"])
            ei_predict_list.append(result["ei_predict"])
            force_label_list.append(result["force_label"])
            force_predict_list.append(result["force_predict"])
            atom_num_list.append(images[result["idx"]].atom_nums)
            
            if result["virial_atom_rmse"] > -1e6:
                virial_rmse.append(result["virial_rmse"])
                virial_atom_rmse.append(result["virial_atom_rmse"])
            virial_label_list.append(result["virial_label"][virial_index])
            virial_predict_list.append(result["virial_predict"][virial_index])
            if has_charge:
                charge_label_list.append(result["charge_label"])
                charge_predict_list.append(result["charge_predict"])
                if result["charge_rmse"] > -1e6:
                    charge_rmse_list.append(result["charge_rmse"])
            if has_bec:
                bec_label_list.append(result["bec_label"])
                bec_predict_list.append(result["bec_predict"])

        inference_path = self.input_param.file_paths.test_dir
        if os.path.exists(inference_path) is False:
            os.makedirs(inference_path)

        # Saving results
        write_arrays_to_file(os.path.join(inference_path, "image_atom_nums.txt"), atom_num_list)
        write_arrays_to_file(os.path.join(inference_path, "dft_total_energy.txt"), etot_label_list)
        write_arrays_to_file(os.path.join(inference_path, "inference_total_energy.txt"), etot_predict_list)
        write_arrays_to_file(os.path.join(inference_path, "dft_force.txt"), force_label_list)
        write_arrays_to_file(os.path.join(inference_path, "inference_force.txt"), force_predict_list)
        write_arrays_to_file(os.path.join(inference_path, "dft_atomic_energy.txt"), ei_label_list)
        write_arrays_to_file(os.path.join(inference_path, "inference_atomic_energy.txt"), ei_predict_list)

        write_arrays_to_file(os.path.join(inference_path, "dft_virial.txt"), virial_label_list, head_line="#\txx\txy\txz\tyy\tyz\tzz")
        write_arrays_to_file(os.path.join(inference_path, "inference_virial.txt"), virial_predict_list, head_line="#\txx\txy\txz\tyy\tyz\tzz")
        if has_charge:
            write_arrays_to_file(os.path.join(inference_path, "dft_charge.txt"), charge_label_list)
            write_arrays_to_file(os.path.join(inference_path, "inference_charge.txt"), charge_predict_list)
        if has_bec:
            write_arrays_to_file(os.path.join(inference_path, "dft_bec.txt"), bec_label_list, head_line="#\txx\txy\txz\tyx\tyy\tyz\tzx\tzy\tzz")
            write_arrays_to_file(os.path.join(inference_path, "inference_bec.txt"), bec_predict_list, head_line="#\txx\txy\txz\tyx\tyy\tyz\tzx\tzy\tzz")

        rmse_E, rmse_F, rmse_V, e_r2, f_r2, v_r2, plot_rmse_charge, charge_r2, rmse_bec, bec_r2 = inference_plot(inference_path, return_extra=True)
        rmse_charge = np.mean(charge_rmse_list) if len(charge_rmse_list) else plot_rmse_charge
        inference_cout = ""
        inference_cout += "For {} images: \n".format(len(images))
        inference_cout += "Average RMSE of Etot per atom: {} R2: {}\n".format(rmse_E, e_r2)
        inference_cout += "Average RMSE of Force: {} R2: {}\n".format(rmse_F, f_r2)
        if rmse_charge is not None:
            inference_cout += "Average RMSE of Charge: {} R2: {}\n".format(rmse_charge, charge_r2)
        if rmse_bec is not None:
            inference_cout += "Average RMSE of BEC: {} R2: {}\n".format(rmse_bec, bec_r2)
        inference_cout += "Average RMSE of Virial per atom: {} R2: {}\n".format(rmse_V, v_r2)
        inference_cout += "\nMore details can be found under the file directory:\n{}\n".format(os.path.realpath(self.input_param.file_paths.test_dir))
        print(inference_cout)
        with open(os.path.join(inference_path, "inference_summary.txt"), 'w') as wf:
            wf.writelines(inference_cout)

        time2 = time.time()
        print("The test work finished, cost time {} s".format(time2 - time0))

    '''
    description: 
    has been replaced by multi_process_nep_inference
    param {*} self
    return {*}
    author: wuxingxing
    '''
    def inference(self):
        # do inference
        self.input_param.world_size
        energy_shift, train_loader, val_loader, forscaler_loader = self.load_data()
        neighbor_scaler = (
            _calculate_lmdb_neighbor_scaler
            if self.input_param.file_paths.format == "lmdb"
            else calculate_neighbor_scaler
        )
        local_global_max, local_global_min, local_max_NN_radial, local_min_NN_radial, local_max_NN_angular, local_min_NN_angular = neighbor_scaler(
                    forscaler_loader,
                    self.input_param.nep_param.n_max[0],      # model.n_max_radial,
                    self.input_param.nep_param.basis_size[0], # model.n_base_radial,
                    self.input_param.nep_param.n_max[1],      # model.n_max_angular,
                    self.input_param.nep_param.basis_size[1], # model.n_base_angular,
                    self.input_param.nep_param.l_max[0],      # model.l_max_3b,
                    self.input_param.nep_param.l_max[1],      # model.l_max_4b,
                    self.input_param.nep_param.l_max[2],      # model.l_max_5b,
                    self.device,
                    num_workers=self.input_param.workers)

        # model.max_NN_radial  = max(model.max_NN_radial, max_NN_radial) # for single gpu
        # model.max_NN_angular = max(model.max_NN_angular, max_NN_angular)
        q_scaler = 1.0 / (local_global_max - local_global_min)
        model, optimizer,_ = self.load_model_optimizer(energy_shift, 
                                                    avg_atom_num=1, 
                                                    iterations=len(train_loader), 
                                                    q_scaler = q_scaler, 
                                                    max_NN_radial = local_max_NN_radial, 
                                                    max_NN_angular = local_max_NN_angular)


        start = time.time()
        (
            res_pd, etot_label_list, etot_predict_list, ei_label_list, ei_predict_list,
            force_label_list, force_predict_list, virial_label_list, virial_predict_list,
            charge_label_list, charge_predict_list, charge_rmse_list, bec_label_list, bec_predict_list
        ) = predict(train_loader, model, self.criterion, self.device, self.input_param)
        end = time.time()
        print("fitting time:", end - start, 's')

        inference_path = self.input_param.file_paths.test_dir
        if os.path.exists(inference_path) is False:
            os.makedirs(inference_path)
        write_arrays_to_file(os.path.join(inference_path, "image_atom_nums.txt"), [int(len(_)/3) for _ in force_predict_list])
        write_arrays_to_file(os.path.join(inference_path, "dft_total_energy.txt"), etot_label_list)
        write_arrays_to_file(os.path.join(inference_path, "inference_total_energy.txt"), etot_predict_list)
        # for force
        write_arrays_to_file(os.path.join(inference_path, "dft_force.txt"), [_.reshape(-1,3) for _ in force_label_list])
        write_arrays_to_file(os.path.join(inference_path, "inference_force.txt"), [_.reshape(-1,3) for _ in force_predict_list])
        # ei
        write_arrays_to_file(os.path.join(inference_path, "dft_atomic_energy.txt"), ei_label_list)
        write_arrays_to_file(os.path.join(inference_path, "inference_atomic_energy.txt"), ei_predict_list)

        write_arrays_to_file(os.path.join(inference_path, "dft_virial.txt"), virial_label_list, head_line="#\txx\txy\txz\tyy\tyz\tzz")
        write_arrays_to_file(os.path.join(inference_path, "inference_virial.txt"), virial_predict_list, head_line="#\txx\txy\txz\tyy\tyz\tzz")
        has_charge = any(np.asarray(charge_predict).size for charge_predict in charge_predict_list)
        has_bec = any(np.asarray(bec_predict).size for bec_predict in bec_predict_list)
        if has_charge:
            write_arrays_to_file(os.path.join(inference_path, "dft_charge.txt"), charge_label_list)
            write_arrays_to_file(os.path.join(inference_path, "inference_charge.txt"), charge_predict_list)
        if has_bec:
            write_arrays_to_file(os.path.join(inference_path, "dft_bec.txt"), bec_label_list, head_line="#\txx\txy\txz\tyx\tyy\tyz\tzx\tzy\tzz")
            write_arrays_to_file(os.path.join(inference_path, "inference_bec.txt"), bec_predict_list, head_line="#\txx\txy\txz\tyx\tyy\tyz\tzx\tzy\tzz")

        # res_pd.to_csv(os.path.join(inference_path, "inference_loss.csv"))

        rmse_E, rmse_F, rmse_V, e_r2, f_r2, v_r2, plot_rmse_charge, charge_r2, rmse_bec, bec_r2 = inference_plot(inference_path, return_extra=True)
        rmse_charge = np.mean(charge_rmse_list) if len(charge_rmse_list) else plot_rmse_charge

        inference_cout = ""
        inference_cout += "For {} images: \n".format(res_pd.shape[0])
        inference_cout += "Average RMSE of Etot per atom: {} R2: {}\n".format(rmse_E, e_r2)
        inference_cout += "Average RMSE of Force: {} R2: {}\n".format(rmse_F, f_r2)
        if rmse_charge is not None:
            inference_cout += "Average RMSE of Charge: {} R2: {}\n".format(rmse_charge, charge_r2)
        if rmse_bec is not None:
            inference_cout += "Average RMSE of BEC: {} R2: {}\n".format(rmse_bec, bec_r2)
        inference_cout += "Average RMSE of Virial per atom: {} R2: {}\n".format(rmse_V, v_r2)
        inference_cout += "\nMore details can be found under the file directory:\n{}\n".format(os.path.realpath(self.input_param.file_paths.test_dir))
        print(inference_cout)
        with open(os.path.join(inference_path, "inference_summary.txt"), 'w') as wf:
            wf.writelines(inference_cout)
