/*
    Copyright 2017 Zheyong Fan, Ville Vierimaa, Mikko Ervasti, and Ari Harju
    This file is part of GPUMD.
    GPUMD is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    GPUMD is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with GPUMD.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "common.cuh"
#include "nep_utilities.cuh"
#include "nep_utilities_mb_secondc.cuh"

static __global__ void find_angular_gardc_small_box(
  const int N,
  const double* grad_second,
  const double* g_d12,
  const int64_t* g_NL,
  const double* de_dfeat,
  const double* dsnlm_dc, //[i, J, nbase, 24]
  const double* g_sum_fxyz,
  const int64_t* g_type,
  const double * coeff3,
  double * dfeat_c3,
  const double rc_angular,
  const double rcinv_angular,
  const int atom_nums,
  const int neigh_num,
  const int max_3b,
  const int base_3b,
  const int num_types,
  const int num_types_sq,
  const int L_max3,
  const int L_max4,
  const int L_max5,
  const int feat_2b_nums,
  const int feat_3b_nums // 3b + 4b + 5b
  )
{
  // int total_elements = batch_size * atom_nums * neigh_num;
  // int elem_idx = threadIdx.x + blockIdx.x * blockDim.x; // 网格中的元素索引
  // if elem_idx >= total_elements return;

  // int batch_idx = elem_idx / (atom_nums * neigh_num);
  // int remaining = elem_idx % (atom_nums * neigh_num);
  // int n1 = remaining / neigh_num;
  // int il = remaining % neigh_num;

  int n1 = blockIdx.x * blockDim.x + threadIdx.x;
  if (n1 < N) {
    int g_sum_start = n1 * max_3b * NUM_OF_ABC;
    int r12_start_idx =  n1 * neigh_num * 4;
    int dc_start_idx = n1 * num_types * max_3b * base_3b;
    int de_start = n1 * (feat_3b_nums + feat_2b_nums);// dE/dq
    int dsnlm_start_idx = n1 * num_types * base_3b * NUM_OF_ABC;
    int neigh_start_idx = n1 * neigh_num;
    double Fp[MAX_DIM_ANGULAR] = {0.0};
    double sum_fxyz[NUM_OF_ABC * MAX_NUM_N];
    int b3_nums = max_3b * L_max3;
    int dd = 0;
    // if (n1 == 0) {
    //   for (int nn=0; nn < 108; nn++) {//all
    //     printf("grad_out_angluar[b0][%d][:] = ", nn);
    //     // printf("grad[%d + %d]=%f\n", de_start, feat_2b_nums + nn, de_dfeat[de_start + feat_2b_nums + nn]);
    //     for (int jj = 0; jj < 25; jj++) {
    //       printf("%f  ", de_dfeat[nn*25 + jj]);
    //     }
    //     printf("\n");
    //   }
    // }
    for (int nn=0; nn < max_3b; ++nn) {
      for (int ll = 0; ll < L_max3; ++ll) {
        Fp[dd] = de_dfeat[de_start + feat_2b_nums + ll * max_3b + nn];// i -> nmax_3b*l_max+2?
        // 0 5 10 15
        // 1 6 11 16
        // 2 7 12 17
        // 3 8 13 18
        // 4 9 14 19 the feature order is L*n_max
        // if (n1==0){
        //   printf("3b Fp[%d] = %f from de_dfeat[%d + %d] = %f\n", dd, Fp[dd], de_start,  feat_2b_nums + ll * max_3b + nn, de_dfeat[de_start +  feat_2b_nums + ll * max_3b + nn]);
        // }
        dd++;
      }
    }
    if (L_max4 > 0) {
      for (int ll = 0; ll < max_3b; ++ll) {
        Fp[b3_nums + ll] = de_dfeat[de_start + feat_2b_nums + b3_nums + ll];
        // if (n1==0){
        //   printf("4b Fp[%d + %d] = %f from de_dfeat[%d + %d] = %f\n",
        //   b3_nums, ll, Fp[b3_nums + ll], de_start,  feat_2b_nums + b3_nums + ll, de_dfeat[de_start + feat_2b_nums + b3_nums + ll]);
        // }
      }
    }
    if (L_max5 > 0) {
      for (int ll = 0; ll < max_3b; ++ll) {
        Fp[b3_nums + max_3b + ll] = de_dfeat[de_start + feat_2b_nums + b3_nums + max_3b + ll];
        // if (n1==0){
        //   printf("5b Fp[%d + %d] = %f from de_dfeat[%d + %d] = %f\n",
        //   b3_nums, max_3b + ll, Fp[b3_nums + max_3b + ll], de_start, feat_2b_nums + b3_nums + max_3b + ll, de_dfeat[de_start + feat_2b_nums + b3_nums + max_3b + ll]);
        // }
      }
    }

    for (int d = 0; d < max_3b * NUM_OF_ABC; ++d) {
      sum_fxyz[d] = g_sum_fxyz[g_sum_start + d]; // g_sum is [N, n_max, 24]
    }

    // Fp[MAX_DIM_ANGULAR] = {1.0};

    int t1 = g_type[n1];
    int c3_start_idx = t1 * num_types * max_3b * base_3b;
    for (int i1 = 0; i1 < neigh_num; ++i1) {
      int n2 = g_NL[neigh_start_idx + i1];
      if (n2 < 0) break;
      int t2 = g_type[n2];
      int rij_idx = r12_start_idx + i1*4;
      // int dsnlm_idx = dsnlm_start_idx + t2 * base_3b * NUM_OF_ABC;
      double d12 = g_d12[rij_idx];
      if (d12 > rc_angular) break;
      double r12[3] = {g_d12[rij_idx+1], g_d12[rij_idx+2], g_d12[rij_idx+3]};
      double scd_r12[4] = {grad_second[rij_idx],grad_second[rij_idx+1],grad_second[rij_idx+2],grad_second[rij_idx+3]};// [r x y z]
      // double scd_r12[4] = {1.0};// [r x y z]

      // if(n1==0 and i1 == 0) {
      //   printf("=====scdr12======%f %f %f %f ========\n",scd_r12[0], scd_r12[1], scd_r12[2], scd_r12[3]);
      // }
      double f12[4] = {0.0};

      double fc12, fcp12;
      find_fc_and_fcp(rc_angular, rcinv_angular, d12, fc12, fcp12);

      double fn12[MAX_NUM_N];
      double fnp12[MAX_NUM_N];
      find_fn_and_fnp(
        base_3b, rcinv_angular, d12, fc12, fcp12, fn12, fnp12);

      int c_I_J_idx = c3_start_idx + t2 * max_3b * base_3b;
      // double s[NUM_OF_ABC*6] = {0.0}; //[sij/(rij_^L), blm, blm/drij, blm/dx, blm/dy, blm/dz]
      double blm[NUM_OF_ABC] = {0.0};
      double rij_blm[NUM_OF_ABC]= {0.0};
      double dblm_x[NUM_OF_ABC] = {0.0};
      double dblm_y[NUM_OF_ABC] = {0.0};
      double dblm_z[NUM_OF_ABC] = {0.0};
      double dblm_r[NUM_OF_ABC] = {0.0};
      scd_accumulate_blm_rij(d12, r12[0], r12[1], r12[2],
          blm, rij_blm, dblm_x, dblm_y, dblm_z, dblm_r);
      for (int n = 0; n < max_3b; ++n) {
        double gn12 = 0.0;
        double gnp12 = 0.0;
        for (int k = 0; k < base_3b; ++k) {
          int c_index = c_I_J_idx + n * base_3b + k;
          gn12 += fn12[k] * coeff3[c_index];
          gnp12 += fnp12[k] * coeff3[c_index];
        }
        // Process one element type at a time so the per-thread scratch
        // space does not grow with the number of model element types.
        for (int j = 0; j < num_types; ++j) {
          double f12k[MAX_NUM_N * 4] = {0.0};
          bool same_type = (t2 == j);
          if (L_max5 > 0) {
            scd_accumulate_f12_with_5body(
              n, d12, r12, gn12, gnp12, Fp, dsnlm_dc, sum_fxyz,
                blm, rij_blm, dblm_x, dblm_y, dblm_z, dblm_r,
                f12, f12k, scd_r12, fn12, fnp12,
                j, num_types, L_max3,
                max_3b, base_3b, dc_start_idx, dsnlm_start_idx, n1, i1, same_type);
          } else if (L_max4 > 0) {
            scd_accumulate_f12_with_4body(
              n, d12, r12, gn12, gnp12, Fp, dsnlm_dc, sum_fxyz,
                blm, rij_blm, dblm_x, dblm_y, dblm_z, dblm_r,
                f12, f12k, scd_r12, fn12, fnp12,
                j, num_types, L_max3,
                max_3b, base_3b, dc_start_idx, dsnlm_start_idx, n1, i1, same_type);
          } else {
            scd_accumulate_f12(
              n, d12, r12, gn12, gnp12, Fp, dsnlm_dc, sum_fxyz,
                blm, rij_blm, dblm_x, dblm_y, dblm_z, dblm_r,
                f12, f12k, scd_r12, fn12, fnp12,
                j, num_types, L_max3,
                max_3b, base_3b, dc_start_idx, dsnlm_start_idx, n1, i1, same_type);
          }
          for (int k = 0; k < base_3b; ++k){
            int dc_id = dc_start_idx + j * max_3b * base_3b + n*base_3b + k;
            int k_id = k * 4;
            dfeat_c3[dc_id] += (f12k[k_id] + f12k[k_id+1] + f12k[k_id+2] + f12k[k_id+3]);
            // if (n1 == 0){
            //   printf("n1=%d t1=%d n2=%d t2=%d n=%d k=%d dc=%f frxyz = %f %f %f %f\n",n1, t1, i1, t2, n, k,
            //     (f12k[k_id] + f12k[k_id+1] + f12k[k_id+2] + f12k[k_id+3]), f12k[k_id], f12k[k_id+1], f12k[k_id+2], f12k[k_id+3]);
            //   }
          }
        }
        //add f12k [k, 4] -> c[atomI, J_type, nmax, k, 4] -> c[atomI, J_type, nmax, k]
        // 是否把4 在scd时候直接给累加起来？ 还是单独加？
      }
    }
  }
}


static __global__ void find_angular_gardc_neigh(
  const int N,
  const double* grad_second,
  const double* g_d12,
  const int64_t* g_NL,
  const double* de_dfeat,
  const double* dsnlm_dc, //[i, J, nbase, 24]
  const double* g_sum_fxyz,
  const int64_t* g_type,
  const double * coeff3,
  double * dfeat_c3,
  const double rc_angular,
  const double rcinv_angular,
  const int atom_nums,
  const int neigh_num,
  const int max_3b,
  const int base_3b,
  const int num_types,
  const int num_types_sq,
  const int L_max3,
  const int L_max4,
  const int L_max5,
  const int feat_2b_nums,
  const int feat_3b_nums // 3b + 4b + 5b
  )
{
  // int total_elements = batch_size * atom_nums * neigh_num;
  int elem_idx = threadIdx.x + blockIdx.x * blockDim.x; // 网格中的元素索引
  if (elem_idx >= N) return;

  int n1 = elem_idx / neigh_num;
  int i1 = elem_idx % neigh_num;

  int neigh_start_idx = n1 * neigh_num;

  int t1 = g_type[n1];
  int n2 = g_NL[neigh_start_idx + i1];
  if (n2 < 0) return;
  int t2 = g_type[n2];

    int g_sum_start = n1 * max_3b * NUM_OF_ABC;
    int r12_start_idx =  n1 * neigh_num * 4;
    int dc_start_idx = n1 * neigh_num * num_types * max_3b * base_3b + i1 * num_types * max_3b * base_3b;
    int de_start = n1 * (feat_3b_nums + feat_2b_nums);// dE/dq
    int dsnlm_start_idx = n1 * num_types * base_3b * NUM_OF_ABC;

    double Fp[MAX_DIM_ANGULAR] = {0.0};
    double sum_fxyz[NUM_OF_ABC * MAX_NUM_N];
    int b3_nums = max_3b * L_max3;
    int dd = 0;

    for (int nn=0; nn < max_3b; ++nn) {
      for (int ll = 0; ll < L_max3; ++ll) {
        Fp[dd] = de_dfeat[de_start + feat_2b_nums + ll * max_3b + nn];// i -> nmax_3b*l_max+2?
        // 0 5 10 15
        // 1 6 11 16
        // 2 7 12 17
        // 3 8 13 18
        // 4 9 14 19 the feature order is L*n_max
        // if (n1==0){
        //   printf("3b Fp[%d] = %f from de_dfeat[%d + %d] = %f\n", dd, Fp[dd], de_start,  feat_2b_nums + ll * max_3b + nn, de_dfeat[de_start +  feat_2b_nums + ll * max_3b + nn]);
        // }
        dd++;
      }
    }
    if (L_max4 > 0) {
      for (int ll = 0; ll < max_3b; ++ll) {
        Fp[b3_nums + ll] = de_dfeat[de_start + feat_2b_nums + b3_nums + ll];
        // if (n1==0){
        //   printf("4b Fp[%d + %d] = %f from de_dfeat[%d + %d] = %f\n",
        //   b3_nums, ll, Fp[b3_nums + ll], de_start,  feat_2b_nums + b3_nums + ll, de_dfeat[de_start + feat_2b_nums + b3_nums + ll]);
        // }
      }
    }
    if (L_max5 > 0) {
      for (int ll = 0; ll < max_3b; ++ll) {
        Fp[b3_nums + max_3b + ll] = de_dfeat[de_start + feat_2b_nums + b3_nums + max_3b + ll];
        // if (n1==0){
        //   printf("5b Fp[%d + %d] = %f from de_dfeat[%d + %d] = %f\n",
        //   b3_nums, max_3b + ll, Fp[b3_nums + max_3b + ll], de_start, feat_2b_nums + b3_nums + max_3b + ll, de_dfeat[de_start + feat_2b_nums + b3_nums + max_3b + ll]);
        // }
      }
    }

    for (int d = 0; d < max_3b * NUM_OF_ABC; ++d) {
      sum_fxyz[d] = g_sum_fxyz[g_sum_start + d]; // g_sum is [N, n_max, 24]
    }

    int c3_start_idx = t1 * num_types * max_3b * base_3b;

    int rij_idx = r12_start_idx + i1*4;
    // int dsnlm_idx = dsnlm_start_idx + t2 * base_3b * NUM_OF_ABC;
    double d12 = g_d12[rij_idx];
    if (d12 > rc_angular) return;
    double r12[3] = {g_d12[rij_idx+1], g_d12[rij_idx+2], g_d12[rij_idx+3]};
    double scd_r12[4] = {grad_second[rij_idx],grad_second[rij_idx+1],grad_second[rij_idx+2],grad_second[rij_idx+3]};// [r x y z]
    double f12[4] = {0.0};
    double fc12, fcp12;
    find_fc_and_fcp(rc_angular, rcinv_angular, d12, fc12, fcp12);

    double fn12[MAX_NUM_N];
    double fnp12[MAX_NUM_N];
    find_fn_and_fnp(
      base_3b, rcinv_angular, d12, fc12, fcp12, fn12, fnp12);

    int c_I_J_idx = c3_start_idx + t2 * max_3b * base_3b;
    // double s[NUM_OF_ABC*6] = {0.0}; //[sij/(rij_^L), blm, blm/drij, blm/dx, blm/dy, blm/dz]
    double blm[NUM_OF_ABC] = {0.0};
    double rij_blm[NUM_OF_ABC]= {0.0};
    double dblm_x[NUM_OF_ABC] = {0.0};
    double dblm_y[NUM_OF_ABC] = {0.0};
    double dblm_z[NUM_OF_ABC] = {0.0};
    double dblm_r[NUM_OF_ABC] = {0.0};
    scd_accumulate_blm_rij(d12, r12[0], r12[1], r12[2],
        blm, rij_blm, dblm_x, dblm_y, dblm_z, dblm_r);
    for (int n = 0; n < max_3b; ++n) {
      double gn12 = 0.0;
      double gnp12 = 0.0;
      for (int k = 0; k < base_3b; ++k) {
        int c_index = c_I_J_idx + n * base_3b + k;
        gn12 += fn12[k] * coeff3[c_index];
        gnp12 += fnp12[k] * coeff3[c_index];
      }
      // Process one element type at a time so the per-thread scratch
      // space does not grow with the number of model element types.
      for (int j = 0; j < num_types; ++j) {
        double f12k[MAX_NUM_N * 4] = {0.0};
        bool same_type = (t2 == j);
        if (L_max5 > 0) {
          scd_accumulate_f12_with_5body(
            n, d12, r12, gn12, gnp12, Fp, dsnlm_dc, sum_fxyz,
              blm, rij_blm, dblm_x, dblm_y, dblm_z, dblm_r,
              f12, f12k, scd_r12, fn12, fnp12,
              j, num_types, L_max3,
              max_3b, base_3b, dc_start_idx, dsnlm_start_idx, n1, i1, same_type);
        } else if (L_max4 > 0) {
          scd_accumulate_f12_with_4body(
            n, d12, r12, gn12, gnp12, Fp, dsnlm_dc, sum_fxyz,
              blm, rij_blm, dblm_x, dblm_y, dblm_z, dblm_r,
              f12, f12k, scd_r12, fn12, fnp12,
              j, num_types, L_max3,
              max_3b, base_3b, dc_start_idx, dsnlm_start_idx, n1, i1, same_type);
        } else {
          scd_accumulate_f12(
            n, d12, r12, gn12, gnp12, Fp, dsnlm_dc, sum_fxyz,
              blm, rij_blm, dblm_x, dblm_y, dblm_z, dblm_r,
              f12, f12k, scd_r12, fn12, fnp12,
              j, num_types, L_max3,
              max_3b, base_3b, dc_start_idx, dsnlm_start_idx, n1, i1, same_type);
        }
        for (int k = 0; k < base_3b; ++k){
          int dc_id = dc_start_idx + j * max_3b * base_3b + n*base_3b + k;
          int k_id = k * 4;
          dfeat_c3[dc_id] += (f12k[k_id] + f12k[k_id+1] + f12k[k_id+2] + f12k[k_id+3]);
          // if (n1 == 0){
          //   printf("n1=%d t1=%d n2=%d t2=%d n=%d k=%d dc=%f frxyz = %f %f %f %f\n",n1, t1, i1, t2, n, k,
          //     (f12k[k_id] + f12k[k_id+1] + f12k[k_id+2] + f12k[k_id+3]), f12k[k_id], f12k[k_id+1], f12k[k_id+2], f12k[k_id+3]);
          //   }
        }
      }
      //add f12k [k, 4] -> c[atomI, J_type, nmax, k, 4] -> c[atomI, J_type, nmax, k]
      // 是否把4 在scd时候直接给累加起来？ 还是单独加？
    }
}


// 移除f12k中的多余空间，同时要调整子函数，确保写入数据的索引从0开始。
static __global__ void find_angular_gardc_neigh_optimized(
  const int N,
  const double* grad_second,
  const double* g_d12,
  const int64_t* g_NL,
  const double* de_dfeat,
  const double* dsnlm_dc, //[i, J, nbase, 24]
  const double* g_sum_fxyz,
  const int64_t* g_type,
  const double * coeff3,
  double * dfeat_c3,
  const double rc_angular,
  const double rcinv_angular,
  const int atom_nums,
  const int neigh_num,
  const int max_3b,
  const int base_3b,
  const int num_types,
  const int num_types_sq,
  const int L_max3,
  const int L_max4,
  const int L_max5,
  const int feat_2b_nums,
  const int feat_3b_nums // 3b + 4b + 5b
  )
{
  int elem_idx = threadIdx.x + blockIdx.x * blockDim.x; // 网格中的元素索引
  if (elem_idx >= N) return;

  int n1 = elem_idx / neigh_num;
  int i1 = elem_idx % neigh_num;

  int neigh_start_idx = n1 * neigh_num;

  int t1 = g_type[n1];
  int n2 = g_NL[neigh_start_idx + i1];
  if (n2 < 0) return;
  int t2 = g_type[n2];

    int g_sum_start = n1 * max_3b * NUM_OF_ABC;
    int r12_start_idx =  n1 * neigh_num * 4;
    int dc_start_idx = n1 * neigh_num * num_types * max_3b * base_3b + i1 * num_types * max_3b * base_3b;
    int de_start = n1 * (feat_3b_nums + feat_2b_nums);// dE/dq
    int dsnlm_start_idx = n1 * num_types * base_3b * NUM_OF_ABC;

    double Fp[MAX_DIM_ANGULAR] = {0.0};
    double sum_fxyz[NUM_OF_ABC * MAX_NUM_N];
    int b3_nums = max_3b * L_max3;
    int dd = 0;

    for (int nn=0; nn < max_3b; ++nn) {
      for (int ll = 0; ll < L_max3; ++ll) {
        Fp[dd] = de_dfeat[de_start + feat_2b_nums + ll * max_3b + nn];// i -> nmax_3b*l_max+2?
        dd++;
      }
    }
    if (L_max4 > 0) {
      for (int ll = 0; ll < max_3b; ++ll) {
        Fp[b3_nums + ll] = de_dfeat[de_start + feat_2b_nums + b3_nums + ll];
      }
    }
    if (L_max5 > 0) {
      for (int ll = 0; ll < max_3b; ++ll) {
        Fp[b3_nums + max_3b + ll] = de_dfeat[de_start + feat_2b_nums + b3_nums + max_3b + ll];
      }
    }

    for (int d = 0; d < max_3b * NUM_OF_ABC; ++d) {
      sum_fxyz[d] = g_sum_fxyz[g_sum_start + d]; // g_sum is [N, n_max, 24]
    }

    int c3_start_idx = t1 * num_types * max_3b * base_3b;

    int rij_idx = r12_start_idx + i1*4;
    double d12 = g_d12[rij_idx];
    if (d12 > rc_angular) return;
    double r12[3] = {g_d12[rij_idx+1], g_d12[rij_idx+2], g_d12[rij_idx+3]};
    double scd_r12[4] = {grad_second[rij_idx],grad_second[rij_idx+1],grad_second[rij_idx+2],grad_second[rij_idx+3]};// [r x y z]
    double f12[4] = {0.0};
    double fc12, fcp12;
    find_fc_and_fcp(rc_angular, rcinv_angular, d12, fc12, fcp12);

    double fn12[MAX_NUM_N];
    double fnp12[MAX_NUM_N];
    find_fn_and_fnp(
      base_3b, rcinv_angular, d12, fc12, fcp12, fn12, fnp12);

    int c_I_J_idx = c3_start_idx + t2 * max_3b * base_3b;
    double blm[NUM_OF_ABC] = {0.0};
    double rij_blm[NUM_OF_ABC]= {0.0};
    double dblm_x[NUM_OF_ABC] = {0.0};
    double dblm_y[NUM_OF_ABC] = {0.0};
    double dblm_z[NUM_OF_ABC] = {0.0};
    double dblm_r[NUM_OF_ABC] = {0.0};
    scd_accumulate_blm_rij(d12, r12[0], r12[1], r12[2],
        blm, rij_blm, dblm_x, dblm_y, dblm_z, dblm_r);
    for (int n = 0; n < max_3b; ++n) {
      double gn12 = 0.0;
      double gnp12 = 0.0;
      for (int k = 0; k < base_3b; ++k) {
        int c_index = c_I_J_idx + n * base_3b + k;
        gn12 += fn12[k] * coeff3[c_index];
        gnp12 += fnp12[k] * coeff3[c_index];
      }
      // double f12d[MAX_LMAX * 4] = {0.0}; // dfeat/drij [nl+n+n, 4]
      // Reuse one fixed-size f12k buffer for each element type.
      for (int j = 0; j < num_types; ++j) {
        double f12k[MAX_NUM_N * 4] = {0.0}; // (20*4)*8=640 Bytes
        bool same_type = (t2 == j);
        if (L_max5 > 0) {
          scd_accumulate_f12_with_5body(
            n, d12, r12, gn12, gnp12, Fp, dsnlm_dc, sum_fxyz,
              blm, rij_blm, dblm_x, dblm_y, dblm_z, dblm_r,
              f12, f12k, scd_r12, fn12, fnp12,
              j, num_types, L_max3,
              max_3b, base_3b, dc_start_idx, dsnlm_start_idx, n1, i1, same_type);
        } else if (L_max4 > 0) {
          scd_accumulate_f12_with_4body(
            n, d12, r12, gn12, gnp12, Fp, dsnlm_dc, sum_fxyz,
              blm, rij_blm, dblm_x, dblm_y, dblm_z, dblm_r,
              f12, f12k, scd_r12, fn12, fnp12,
              j, num_types, L_max3,
              max_3b, base_3b, dc_start_idx, dsnlm_start_idx, n1, i1, same_type);
        } else {
          scd_accumulate_f12(
            n, d12, r12, gn12, gnp12, Fp, dsnlm_dc, sum_fxyz,
              blm, rij_blm, dblm_x, dblm_y, dblm_z, dblm_r,
              f12, f12k, scd_r12, fn12, fnp12,
              j, num_types, L_max3,
              max_3b, base_3b, dc_start_idx, dsnlm_start_idx, n1, i1, same_type);
        }
        for (int k = 0; k < base_3b; ++k){
          int dc_id = dc_start_idx + j * max_3b * base_3b + n*base_3b + k;
          // int k_id = j * base_3b * 4 + k * 4;
          int k_id = k * 4;
          dfeat_c3[dc_id] += (f12k[k_id] + f12k[k_id+1] + f12k[k_id+2] + f12k[k_id+3]);
        }
      }
    }
}


// 优化 f12k 的基础上，进一步优化。
// 每个 block 处理一个原子，Fp 和 sum_fxyz 移入 shmem。
// USE_LDS_REDUCE keeps one center-atom C3 row in LDS.  AOT specializations
// provide every descriptor dimension as a template argument; the all-zero
// default remains the runtime-generic path.
template <bool USE_LDS_REDUCE, int FIXED_BASE_3B = 0,
          int FIXED_MAX_3B = 0, int FIXED_NUM_TYPES = 0,
          int FIXED_LMAX_3 = 0, int FIXED_LMAX_4 = 0,
          int FIXED_LMAX_5 = 0>
static __global__ void find_angular_gardc_neigh_optimized_2(
  const int N,
  const double* grad_second,
  const double* g_d12,
  const int64_t* g_NL,
  const double* de_dfeat,
  const double* dsnlm_dc, //[i, J, nbase, 24]
  const double* g_sum_fxyz,
  const int64_t* g_type,
  const double * coeff3,
  double * dfeat_c3,
  const double rc_angular,
  const double rcinv_angular,
  const int atom_nums,
  const int neigh_num,
  const int max_3b,
  const int base_3b,
  const int num_types,
  const int num_types_sq,
  const int L_max3,
  const int L_max4,
  const int L_max5,
  const int feat_2b_nums,
  const int feat_3b_nums // 3b + 4b + 5b
  )
{
  int n1 = blockIdx.x;
  if (n1 >= N) return;

  constexpr bool kFixedShape = FIXED_BASE_3B > 0 && FIXED_MAX_3B > 0 &&
      FIXED_NUM_TYPES > 0;
  constexpr int kSharedMax3b =
      kFixedShape ? FIXED_MAX_3B : MAX_NUM_N;
  constexpr int kSharedFp = kFixedShape
      ? FIXED_MAX_3B * (FIXED_LMAX_3 + (FIXED_LMAX_4 > 0 ? 1 : 0) +
          (FIXED_LMAX_5 > 0 ? 1 : 0))
      : MAX_DIM_ANGULAR;
  constexpr int kRadialScratch =
      kFixedShape ? FIXED_BASE_3B : MAX_NUM_N;
  const int shape_base_3b = kFixedShape ? FIXED_BASE_3B : base_3b;
  const int shape_max_3b = kFixedShape ? FIXED_MAX_3B : max_3b;
  const int shape_num_types = kFixedShape ? FIXED_NUM_TYPES : num_types;
  const int shape_lmax_3 = kFixedShape ? FIXED_LMAX_3 : L_max3;
  const int shape_lmax_4 = kFixedShape ? FIXED_LMAX_4 : L_max4;
  const int shape_lmax_5 = kFixedShape ? FIXED_LMAX_5 : L_max5;

  double* shm_dfeat_c3 = nullptr;
  if constexpr (USE_LDS_REDUCE) {
    if constexpr (kFixedShape) {
      __shared__ double fixed_shm_dfeat_c3[
          FIXED_NUM_TYPES * FIXED_MAX_3B * FIXED_BASE_3B];
      shm_dfeat_c3 = fixed_shm_dfeat_c3;
    } else {
      extern __shared__ double dynamic_shm_dfeat_c3[];
      shm_dfeat_c3 = dynamic_shm_dfeat_c3;
    }
  }

  // Block 共享存储
  __shared__ double shm_sum_fxyz[NUM_OF_ABC * kSharedMax3b];
  __shared__ double shm_Fp[kSharedFp];

  int neigh_start_idx = n1 * neigh_num;
  int t1 = g_type[n1];

  int g_sum_start = n1 * shape_max_3b * NUM_OF_ABC;
  int r12_start_idx =  n1 * neigh_num * 4;
  int de_start = n1 * (feat_3b_nums + feat_2b_nums);// dE/dq
  int dsnlm_start_idx = n1 * shape_num_types * shape_base_3b * NUM_OF_ABC;
  int c3_start_idx = t1 * shape_num_types * shape_max_3b * shape_base_3b;
  int c3_elements = shape_num_types * shape_max_3b * shape_base_3b;

  if constexpr (USE_LDS_REDUCE) {
    for (int k = threadIdx.x; k < c3_elements; k += blockDim.x) {
      shm_dfeat_c3[k] = 0.0;
    }
  }

  // 加载 sum_fxyz 到 shared memory
  int total_s_elements = shape_max_3b * NUM_OF_ABC;
  for (int k = threadIdx.x; k < total_s_elements; k += blockDim.x) {
    shm_sum_fxyz[k] = g_sum_fxyz[g_sum_start + k]; // g_sum is [N, n_max, 24]
  }

  // 加载 Fp 到 shared memory
  int b3_nums = shape_max_3b * shape_lmax_3;
  int total_Fp_elements = b3_nums + (shape_lmax_4 > 0 ? shape_max_3b : 0) + (shape_lmax_5 > 0 ? shape_max_3b : 0);

  for (int k = threadIdx.x; k < total_Fp_elements; k += blockDim.x) {
    shm_Fp[k] = 0.0;
  }
  // Higher-body values are loaded by different lanes from those
  // that zeroed their slots; finish zeroing across all waves first.
  __syncthreads();

  for (int k = threadIdx.x; k < b3_nums; k += blockDim.x) {
    int nn = k / shape_lmax_3;
    int ll = k % shape_lmax_3;
    shm_Fp[k] = de_dfeat[de_start + feat_2b_nums + ll * shape_max_3b + nn];
  }
  if (shape_lmax_4 > 0) {
    for (int k = threadIdx.x; k < shape_max_3b; k += blockDim.x) {
      shm_Fp[b3_nums + k] = de_dfeat[de_start + feat_2b_nums + b3_nums + k];
    }
  }
  if (shape_lmax_5 > 0) {
    for (int k = threadIdx.x; k < shape_max_3b; k += blockDim.x) {
      shm_Fp[b3_nums + shape_max_3b + k] = de_dfeat[de_start + feat_2b_nums + b3_nums + shape_max_3b + k];
    }
  }

  __syncthreads();

  for (int i1 = threadIdx.x; i1 < neigh_num; i1 += blockDim.x) {
    int n2 = g_NL[neigh_start_idx + i1];
    if (n2 < 0) continue;
    int t2 = g_type[n2];

    // Accumulate neighbors directly into the center-atom row. This avoids
    // materializing the O(N*neighbors*T*n*b) temporary used by the legacy
    // aggregate path below.
    int dc_start_idx = n1 * shape_num_types * shape_max_3b * shape_base_3b;
    int rij_idx = r12_start_idx + i1*4;
    double d12 = g_d12[rij_idx];
    if (d12 > rc_angular) continue;
    double r12[3] = {g_d12[rij_idx+1], g_d12[rij_idx+2], g_d12[rij_idx+3]};
    double scd_r12[4] = {grad_second[rij_idx],grad_second[rij_idx+1],grad_second[rij_idx+2],grad_second[rij_idx+3]};// [r x y z]
    double f12[4] = {0.0};
    double fc12, fcp12;
    find_fc_and_fcp(rc_angular, rcinv_angular, d12, fc12, fcp12);

    double fn12[kRadialScratch];
    double fnp12[kRadialScratch];
    find_fn_and_fnp(
      shape_base_3b, rcinv_angular, d12, fc12, fcp12, fn12, fnp12);

    int c_I_J_idx = c3_start_idx + t2 * shape_max_3b * shape_base_3b;
    double blm[NUM_OF_ABC] = {0.0};     // 24*8=192 Bytes
    double rij_blm[NUM_OF_ABC]= {0.0};  // 24*8=192 Bytes
    double dblm_x[NUM_OF_ABC] = {0.0};  // 24*8=192 Bytes
    double dblm_y[NUM_OF_ABC] = {0.0};  // 24*8=192 Bytes
    double dblm_z[NUM_OF_ABC] = {0.0};  // 24*8=192 Bytes
    double dblm_r[NUM_OF_ABC] = {0.0};  // 24*8=192 Bytes
    scd_accumulate_blm_rij(d12, r12[0], r12[1], r12[2],
        blm, rij_blm, dblm_x, dblm_y, dblm_z, dblm_r);
    for (int n = 0; n < shape_max_3b; ++n) {
      double gn12 = 0.0;
      double gnp12 = 0.0;
      for (int k = 0; k < shape_base_3b; ++k) {
        int c_index = c_I_J_idx + n * shape_base_3b + k;
        gn12 += fn12[k] * coeff3[c_index];
        gnp12 += fnp12[k] * coeff3[c_index];
      }
      // min (1*20*4)*8=640 Bytes, max (20*20*4)*8=12800 Bytes
      // Reuse one fixed-size f12k buffer for each element type.
      for (int j = 0; j < shape_num_types; ++j) {
        double f12k[MAX_NUM_N * 4] = {0.0}; // (20*4)*8=640 Bytes
        bool same_type = (t2 == j);
        if (shape_lmax_5 > 0) {
          scd_accumulate_f12_with_5body(
            n, d12, r12, gn12, gnp12, shm_Fp, dsnlm_dc, shm_sum_fxyz,
              blm, rij_blm, dblm_x, dblm_y, dblm_z, dblm_r,
              f12, f12k, scd_r12, fn12, fnp12,
              j, shape_num_types, shape_lmax_3,
              shape_max_3b, shape_base_3b, dc_start_idx, dsnlm_start_idx, n1, i1, same_type);
        } else if (shape_lmax_4 > 0) {
          scd_accumulate_f12_with_4body(
            n, d12, r12, gn12, gnp12, shm_Fp, dsnlm_dc, shm_sum_fxyz,
              blm, rij_blm, dblm_x, dblm_y, dblm_z, dblm_r,
              f12, f12k, scd_r12, fn12, fnp12,
              j, shape_num_types, shape_lmax_3,
              shape_max_3b, shape_base_3b, dc_start_idx, dsnlm_start_idx, n1, i1, same_type);
        } else {
          scd_accumulate_f12(
            n, d12, r12, gn12, gnp12, shm_Fp, dsnlm_dc, shm_sum_fxyz,
              blm, rij_blm, dblm_x, dblm_y, dblm_z, dblm_r,
              f12, f12k, scd_r12, fn12, fnp12,
              j, shape_num_types, shape_lmax_3,
              shape_max_3b, shape_base_3b, dc_start_idx, dsnlm_start_idx, n1, i1, same_type);
        }
        for (int k = 0; k < shape_base_3b; ++k){
          int dc_offset = j * shape_max_3b * shape_base_3b + n * shape_base_3b + k;
          // int k_id = j * base_3b * 4 + k * 4;
          int k_id = k * 4;
          double contribution =
              f12k[k_id] + f12k[k_id + 1] + f12k[k_id + 2] + f12k[k_id + 3];
          if constexpr (USE_LDS_REDUCE) {
            atomicAdd(&shm_dfeat_c3[dc_offset], contribution);
          } else {
            atomicAdd(&dfeat_c3[dc_start_idx + dc_offset], contribution);
          }
        }
      }
    }
  }

  if constexpr (USE_LDS_REDUCE) {
    __syncthreads();
    int output_start_idx = n1 * c3_elements;
    for (int k = threadIdx.x; k < c3_elements; k += blockDim.x) {
      dfeat_c3[output_start_idx + k] = shm_dfeat_c3[k];
    }
  }
}


static __global__ void aggregate_dfeat_c3(
  const int64_t* g_NL,
  const int64_t* g_type,
  const double* dfeat_c3,
  double* tmp_dfeat_c3,
  const int N,
  const int atom_nums,
  const int neigh_num,
  const int num_types,
  const int max_3b,
  const int base_3b
  )
{
  int n1 = blockIdx.x * blockDim.x + threadIdx.x;
  if (n1 < N) {
    int tmp_start_idx = n1 * num_types * max_3b * base_3b;
    int dc_start_idx = n1 * neigh_num * num_types * max_3b * base_3b;
    int neigh_start_idx = n1 * neigh_num;
    // int t1 = g_type[n1];
    for (int i1 = 0; i1 < neigh_num; ++i1) {
      int n2 = g_NL[neigh_start_idx + i1];
      if (n2 < 0) break;
      // int t2 = g_type[n2];
      int dc_idx = dc_start_idx + i1 * num_types * max_3b * base_3b;
      for (int j = 0; j < num_types; ++j){
        for (int n = 0; n < max_3b; ++n) {
          for (int k = 0; k < base_3b; ++k){
            int dc_id = dc_idx + j * max_3b * base_3b + n*base_3b + k;
            int tmp_dc_id = tmp_start_idx + j * max_3b * base_3b + n*base_3b + k;
            tmp_dfeat_c3[tmp_dc_id] += dfeat_c3[dc_id];
          }
        }
      }
    }
  }
}

// 每个线程处理一个(atom, neighbor)对，将dfeat_c3中的梯度累加到tmp_dfeat_c3中
static __global__ void aggregate_dfeat_c3_optimized(
  const int64_t* g_NL,
  const int64_t* g_type,
  const double* dfeat_c3,
  double* tmp_dfeat_c3,
  const int N,
  const int atom_nums,
  const int neigh_num,
  const int num_types,
  const int max_3b,
  const int base_3b
  )
{
  int global_idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (global_idx >= N * neigh_num) return;

  int n1 = global_idx / neigh_num;
  int i1 = global_idx % neigh_num;

  int neigh_start_idx = n1 * neigh_num;
  int n2 = g_NL[neigh_start_idx + i1];
  if (n2 < 0) return;

  int tmp_start_idx = n1 * num_types * max_3b * base_3b;
  int dc_idx = n1 * neigh_num * num_types * max_3b * base_3b + i1 * num_types * max_3b * base_3b;

  for (int j = 0; j < num_types; ++j){
    for (int n = 0; n < max_3b; ++n) {
      for (int k = 0; k < base_3b; ++k){
        int dc_id = dc_idx + j * max_3b * base_3b + n*base_3b + k;
        int tmp_dc_id = tmp_start_idx + j * max_3b * base_3b + n*base_3b + k;
        atomicAdd(&tmp_dfeat_c3[tmp_dc_id], dfeat_c3[dc_id]);
      }
    }
  }
}
